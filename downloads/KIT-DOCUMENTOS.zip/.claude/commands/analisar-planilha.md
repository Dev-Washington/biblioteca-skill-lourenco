---
description: Analisa uma planilha — inspeciona a estrutura real antes de calcular
---

Arquivo: $ARGUMENTS

1. **Abra e olhe antes de qualquer coisa** — skill `xlsx`. Se o usuário não informou
   o caminho, peça agora.

   Levante e mostre ao usuário: quantas abas, quantas linhas por aba, onde está o
   cabeçalho de verdade (raramente é a linha 1), que colunas existem e de que tipo.

2. **Aponte o que está sujo antes de calcular.** Isso vem primeiro, não depois:
   - célula mesclada
   - número guardado como texto
   - data em formato misto
   - linha de total ou subtotal no meio dos dados
   - célula vazia versus zero
   - espaço em branco no fim de texto usado como chave

   Cada um desses quebra agregação silenciosamente. Diga quais existem e como
   pretende tratar cada um. **Confirme com o usuário antes de seguir.**

3. **Analise** — skill `excel-analysis`: agregação, tabela dinâmica, gráfico.

4. **Mostre o resultado**, não só descreva. Primeiras linhas da saída, totais,
   contagem de registros processados versus descartados.

5. **Nunca sobrescreva o arquivo original.** Escreva em arquivo novo, ou confirme
   explicitamente.

Se algum número não puder ser extraído, diga qual célula e por quê. Não preencha
com estimativa.
