---
description: Digitaliza um documento com OCR — do pré-processamento à validação
---

Documento: $ARGUMENTS

Use o time de OCR nesta ordem. Diga qual agent está usando em cada etapa.

1. **Olhe a imagem primeiro.** Resolução, inclinação, sombra, contraste. Se a
   qualidade for ruim, diga ao usuário **agora** — OCR de imagem ruim dá resultado
   ruim por mais agents que você use. O ideal é 300 dpi, reto, bem iluminado.

2. **Pré-processe** — agent `ocr-preprocessing-optimizer`: endireitar, contraste,
   remover ruído.

3. **Reconheça** — agent `visual-analysis-ocr`.

4. **Entenda a estrutura** — agent `document-structure-analyzer`: títulos, tabelas,
   colunas, ordem de leitura. Documento com duas colunas lido em linha reta vira
   texto embaralhado — é o erro mais comum.

5. **Formate** — agent `markdown-syntax-formatter`.

6. **Valide** — agent `text-comparison-validator`. **Esta etapa não é opcional.**
   Compare o texto extraído com o original e liste o que divergiu.

7. **Corrija** — agent `ocr-grammar-fixer`, depois agent `ocr-quality-assurance`.

Ao entregar, informe **explicitamente**:
- o que foi reconhecido com confiança
- o que ficou duvidoso, e onde
- o que não deu para ler

Nunca apresente saída de OCR como transcrição fiel. Número, data e nome próprio são
onde o OCR mais erra — sinalize cada um que não deu para conferir.
