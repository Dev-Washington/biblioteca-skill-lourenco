---
description: Mostra o que este kit tem e o que se aplica ao seu arquivo
---

Leia `CLAUDE.md` na raiz e apresente, em português:

1. Verifique o que existe **de fato**: `ls .claude/skills` · `ls .claude/agents` ·
   `cat .mcp.json`. Não liste nada que não esteja lá.

2. Resuma por formato: Word, Excel/planilha, PDF, PowerPoint, e o fluxo de OCR.

3. Se o usuário passou um arquivo ou assunto ($ARGUMENTS), diga o que se aplica.
   Se passou um caminho de arquivo, **abra e olhe** antes de recomendar. Se não
   passou nada, pergunte com que arquivo ele está trabalhando e o que precisa fazer.

Seja direto.
