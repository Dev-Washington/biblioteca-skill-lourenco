# Kit Documentos — Word, Excel, PDF, PowerPoint e OCR

**11 skills e 7 agents** em `.claude/`, para trabalhar com arquivos de
escritório e digitalização.

Fonte: [aitmpl.com](https://aitmpl.com/).

---

## Roteamento

| Assunto da tarefa | Use |
|---|---|
| Criar, ler ou editar **Word** (.docx) | skill `docx` |
| Criar, ler ou editar **planilha** (.xlsx) | skill `xlsx`, skill `spreadsheet` |
| Analisar Excel: tabela dinâmica, gráfico, análise | skill `excel-analysis` |
| Criar ou editar **PowerPoint** (.pptx) | skill `pptx` |
| **PDF** em produção: formulário, tabela, lote, validação | skill `pdf-processing-pro` |
| **PDF**: ler, extrair texto/tabela, juntar, dividir | skill `pdf-anthropic` |
| Converter qualquer formato para Markdown | MCP `markitdown` (opcional, exige Docker) |
| Markdown do Obsidian: wikilink, embed, callout | skill `obsidian-markdown` |
| Escrever e-mail profissional | skill `email-composer` |
| Comunicado interno | skill `internal-comms` |
| Aplicar cores e tipografia de marca | skill `brand-guidelines` |

### Digitalizar documento (OCR) — na ordem
| Etapa | Agent |
|---|---|
| 1. Melhorar a imagem antes do OCR | `ocr-preprocessing-optimizer` |
| 2. Reconhecer o texto | `visual-analysis-ocr` |
| 3. Entender a estrutura (títulos, tabelas, colunas) | `document-structure-analyzer` |
| 4. Formatar em markdown | `markdown-syntax-formatter` |
| 5. Comparar com o original e achar erro | `text-comparison-validator` |
| 6. Corrigir gramática | `ocr-grammar-fixer` |
| 7. Conferência final | `ocr-quality-assurance` |

---

## MCPs

Nenhum MCP está ativo. `markitdown` (exige imagem Docker) e `filesystem` (exige
configurar o caminho permitido) estão em `.mcp.optional.json`. As skills funcionam
sem eles — leem e escrevem arquivo pelas ferramentas normais. Se recomendar um MCP,
diga que precisa de preparo.

## Regras

**Leia o arquivo antes de agir.** Planilha e PDF quase nunca têm a estrutura que o
usuário descreve. Abra, veja as primeiras linhas, confirme onde estão os cabeçalhos
e se há abas ou páginas escondidas. Só então proponha o que fazer.

**Nunca sobrescreva o original.** Escreva em arquivo novo, ou confirme
explicitamente com o usuário antes de substituir. Documento sobrescrito por engano
não tem desfazer.

**Diga quando o dado está sujo.** Célula mesclada, data em formato misto, número
guardado como texto, linha de total no meio dos dados — isso quebra qualquer
análise. Aponte antes de calcular, não depois.

**OCR não é exato.** Sempre passe pelo `text-comparison-validator` e diga ao usuário
qual foi a taxa de confiança. Apresentar texto de OCR como se fosse transcrição
fiel é o erro mais caro deste kit.

**Dependências Python.** As skills usam `python-docx`, `openpyxl`, `pypdf` e
similares. Se faltar, o erro pode ser silencioso — verifique antes de afirmar que
funcionou.

## Convenções

- Declare qual skill/agent está usando.
- Mostre o resultado, não só descreva. Se gerou planilha, mostre as primeiras linhas.
- Não invente número. Se a extração falhou numa célula, diga qual.
