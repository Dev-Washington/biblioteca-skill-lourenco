# Kit Documentos — Word, Excel, PDF, PowerPoint e OCR

**11 skills, 7 agents e 3 commands** para trabalhar com arquivos de
escritório e digitalização.

Origem: [aitmpl.com](https://aitmpl.com/) · **20 componentes, 10.671 downloads somados.**

---

## Por que este kit

Nenhum dos kits de desenvolvimento toca arquivo de escritório — e é onde a maior
parte do trabalho real acontece. Planilha bagunçada que precisa virar relatório, PDF
escaneado do qual você precisa extrair uma tabela, apresentação para montar.

Quatro skills deste kit estão entre as **20 mais baixadas do catálogo inteiro**:
`docx` (1.664), `pdf-processing-pro` (1.540), `pptx` (1.269), `xlsx` (1.170).

É o kit menos técnico da coleção e o mais usado no dia a dia.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-documentos`.

Ou instale num projeto existente:

```bash
./install.sh /caminho/do/seu/projeto
./check.sh
```

### Windows (PowerShell)

```powershell
.\install.ps1 C:\caminho\do\seu\projeto
```

Se o Windows bloquear a execução do script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Isso libera só a sessão atual — não altera a política da máquina.

### macOS e Linux

```bash
chmod +x install.sh check.sh    # só na primeira vez
./install.sh /caminho/do/seu/projeto
./check.sh
```

O `install.ps1` também roda no macOS e no Linux, se você tiver PowerShell 7+.

---

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-documentos [arquivo]` | Mostra o que tem; se passar um arquivo, abre e olha antes de recomendar |
| `/analisar-planilha [arquivo]` | Inspeciona a estrutura real, aponta o dado sujo, depois calcula |
| `/digitalizar [documento]` | OCR completo: pré-processar → reconhecer → estruturar → validar |

O `/analisar-planilha` faz o que quase nenhuma análise automática faz: **aponta
célula mesclada, número como texto, data em formato misto e linha de total no meio
dos dados antes de calcular** — e pede confirmação. Esses quatro quebram agregação
em silêncio.

---

## O que está instalado

**Formatos** — `docx` (1.664), `pdf-processing-pro` (1.540), `pptx` (1.269),
`xlsx` (1.170), `excel-analysis` (783), `pdf-anthropic` (490),
`obsidian-markdown` (124), `spreadsheet` (52).

**Comunicação** — `email-composer` (471), `brand-guidelines` (264),
`internal-comms` (90).

**Time de OCR (7 agents)** — `document-structure-analyzer` (297),
`markdown-syntax-formatter` (294), `visual-analysis-ocr` (230),
`text-comparison-validator` (167), `ocr-preprocessing-optimizer` (165),
`ocr-quality-assurance` (164), `ocr-grammar-fixer` (149).

`text-comparison-validator` é a peça que falta na maioria dos fluxos de OCR: compara
o texto extraído com o original e mostra o que o reconhecimento errou.

Detalhe e justificativa: [KIT-DOCUMENTOS.md](KIT-DOCUMENTOS.md).

---

## MCPs

Nenhum funciona sem preparo — os dois ficam em `.mcp.optional.json`:

| Servidor | O que faz | O que precisa |
|---|---|---|
| `markitdown` (385) | Converte PDF, Word, Excel, imagem e áudio para Markdown | imagem Docker `markitdown-mcp:latest` construída localmente |
| `filesystem` (903) | Acesso a diretórios com permissão configurável | trocar `/path/to/allowed/files` pelo seu caminho |

> **Configure o escopo do `filesystem`.** Ele dá ao Claude leitura e escrita nos
> diretórios listados — aponte para a pasta do projeto, nunca para a raiz do disco.

As skills funcionam sem os MCPs: elas leem e escrevem arquivo pelas ferramentas
normais. Os MCPs são conveniência, não requisito.

---

## Limitações

1. **As skills rodam Python por baixo** (`python-docx`, `openpyxl`, `pypdf`). Se a
   biblioteca não estiver instalada, pode falhar de forma pouco óbvia.

2. **OCR depende da imagem, não do modelo.** Documento torto, com sombra ou baixa
   resolução dá resultado ruim mesmo com os 7 agents. Escaneie a 300 dpi, reto.
   Número, data e nome próprio são onde o OCR mais erra.

3. **`brand-guidelines` aplica a marca da Anthropic**, não a sua. Serve como
   estrutura — troque cores e fontes antes de usar.

4. **Há 4 skills de PDF no catálogo com descrição quase idêntica.** Instalei as duas
   mais baixadas. Se conflitarem, prefira `pdf-processing-pro`.

---

## Arquivos

```
KIT-DOCUMENTOS/
├── CLAUDE.md            contexto automático: roteamento e regras
├── README.md            este arquivo
├── KIT-DOCUMENTOS.md    análise do catálogo
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/
    ├── skills/  11    ├── agents/  7    └── commands/  3
```
