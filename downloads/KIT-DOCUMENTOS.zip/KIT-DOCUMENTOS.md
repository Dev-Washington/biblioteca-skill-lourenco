# Kit Documentos — Word, Excel, PDF, PowerPoint e OCR

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**20 componentes · 10.671 downloads somados.** O kit menos técnico e o mais usado no
dia a dia.

---

## 1. Por que este kit

Nenhum dos kits de desenvolvimento toca arquivo de escritório. E é onde a maior
parte do trabalho real acontece: planilha bagunçada que precisa virar relatório,
PDF escaneado do qual você precisa extrair uma tabela, apresentação para montar,
contrato para ler.

A categoria `document-processing` tem 18 skills e **4 delas estão entre as 20 mais
baixadas do catálogo inteiro**: `docx` (1.664), `pdf-processing-pro` (1.540),
`pptx` (1.269), `xlsx` (1.170).

---

## 2. Componentes

### Formatos de escritório
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `document-processing/docx` | skill | Criar, ler, editar e manipular Word | 1.664 |
| `document-processing/pdf-processing-pro` | skill | PDF em produção: formulários, tabelas, OCR, validação, lote | 1.540 |
| `document-processing/pptx` | skill | PowerPoint como entrada ou saída | 1.269 |
| `document-processing/xlsx` | skill | Planilha como entrada ou saída principal | 1.170 |
| `document-processing/pdf-anthropic` | skill | Ler, extrair texto e tabela, juntar e dividir PDF | 490 |
| `document-processing/spreadsheet` | skill | Planilha genérica | 52 |
| `enterprise-communication/excel-analysis` | skill | Analisar Excel, tabela dinâmica, gráfico | 783 |

Há **quatro skills de PDF** no catálogo (`pdf-processing-pro`, `pdf-anthropic`,
`pdf-processing`, `pdf`) com descrições quase idênticas. Instalei as duas mais
baixadas — `pdf-processing-pro` para o caso de produção, `pdf-anthropic` para
leitura e extração simples.

### Comunicação
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `enterprise-communication/email-composer` | skill | E-mail profissional: negócio, técnico, formal | 471 |
| `enterprise-communication/brand-guidelines` | skill | Aplica cores e tipografia de marca a qualquer artefato | 264 |
| `enterprise-communication/internal-comms` | skill | Comunicação interna | 90 |
| `document-processing/obsidian-markdown` | skill | Markdown do Obsidian: wikilinks, embeds, callouts | 124 |

### Time de OCR — 7 agents
`document-structure-analyzer` (297) · `markdown-syntax-formatter` (294) ·
`visual-analysis-ocr` (230) · `text-comparison-validator` (167) ·
`ocr-preprocessing-optimizer` (165) · `ocr-quality-assurance` (164) ·
`ocr-grammar-fixer` (149)

Fluxo completo de digitalização: pré-processar a imagem → OCR → analisar estrutura →
formatar em markdown → validar contra o original → corrigir gramática → QA.

`text-comparison-validator` é a peça que falta na maioria dos fluxos de OCR: compara
o texto extraído com o original para achar o que o reconhecimento errou.

### MCPs
`devtools/markitdown` (385) — converte PDF, Word, Excel, imagem e áudio para
Markdown; **exige imagem Docker construída localmente**. `filesystem/filesystem-access`
(903) — acesso a diretório; **vem com o caminho `/path/to/allowed/files` como
placeholder**. Nenhum dos dois roda sem preparo, então ambos ficam em
`.mcp.optional.json`. As skills funcionam sem eles.

---

## 3. Ressalvas honestas

1. **Skills de documento geralmente rodam scripts Python** (`python-docx`,
   `openpyxl`, `pypdf`). Se as bibliotecas não estiverem instaladas, a skill não
   funciona — e o erro pode não ser óbvio. Rode `./check.sh` para ver o que falta.

2. **OCR de qualidade depende da imagem, não do modelo.** Documento torto, com
   sombra ou baixa resolução vai dar resultado ruim mesmo com o time completo de 7
   agents. `ocr-preprocessing-optimizer` ajuda, mas não faz milagre — escaneie a
   300 dpi, reto.

3. **`brand-guidelines` aplica a marca da Anthropic**, não a sua. Serve como
   estrutura de referência; troque as cores e fontes pelas suas antes de usar.

4. **Quatro skills de PDF com descrição quase igual** é sinal de duplicação no
   catálogo. Se as duas instaladas conflitarem, prefira `pdf-processing-pro`.

5. **`filesystem-access` dá ao Claude acesso de leitura e escrita a diretórios.**
   Configure o escopo mínimo — não aponte para a raiz do seu disco.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --skill document-processing/docx --yes
npx claude-code-templates@latest --skill document-processing/xlsx --yes
npx claude-code-templates@latest --skill document-processing/pptx --yes
npx claude-code-templates@latest --skill document-processing/pdf-processing-pro --yes
npx claude-code-templates@latest --skill enterprise-communication/excel-analysis --yes
npx claude-code-templates@latest --mcp devtools/markitdown --yes
```
