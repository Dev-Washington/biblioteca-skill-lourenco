#!/usr/bin/env bash
# Verifica se o kit está completo e quais ferramentas externas faltam.
cd "$(dirname "${BASH_SOURCE[0]}")"
ok=0; fail=0
chk(){ if [ -e "$2" ]; then ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }

echo "== Skills do catálogo (30) =="
for s in frontend-design ui-ux-pro-max ui-design-system premium-web-design web-design-guidelines \
  theme-factory tailwind-patterns scroll-experience 3d-web-experience algorithmic-art \
  interactive-portfolio claude-d3js-skill slack-gif-creator canvas-design imagegen \
  accessibility-auditor figma figma-implement-design remotion remotion-best-practices \
  motion-canvas copywriting page-cro react-best-practices web-performance-optimization \
  tailwind-design-system shadcn nextjs-app-router-patterns astro roier-seo; do
  chk "skill $s" ".claude/skills/$s/SKILL.md"; done

echo "== Skill própria do kit =="
chk "web-motion/SKILL.md" ".claude/skills/web-motion/SKILL.md"
for r in escolha-tecnica receitas produto-imagem performance acessibilidade; do
  chk "web-motion/referencias/$r.md" ".claude/skills/web-motion/referencias/$r.md"; done

echo "== Agents (4) =="
for a in frontend-developer ui-ux-designer ui-designer web-accessibility-checker; do
  chk "agent $a" ".claude/agents/$a.md"; done

echo "== Commands =="
for c in kit-motion landing animar-produto revisar-motion; do chk "/$c" ".claude/commands/$c.md"; done

echo "== Config =="
chk "CLAUDE.md" "CLAUDE.md"; chk ".mcp.json" ".mcp.json"; chk ".mcp.optional.json" ".mcp.optional.json"
node -e 'JSON.parse(require("fs").readFileSync(".mcp.json","utf8"))' 2>/dev/null \
  && echo "  .mcp.json: JSON válido" || { echo "  .mcp.json: INVÁLIDO"; fail=$((fail+1)); }

echo
echo "  total: $(ls .claude/skills 2>/dev/null | wc -l | tr -d ' ') skills, \
$(ls .claude/agents 2>/dev/null | wc -l | tr -d ' ') agents, \
$(ls .claude/commands 2>/dev/null | wc -l | tr -d ' ') commands"

echo
echo "== Ferramentas externas =="
dep(){ if command -v "$1" >/dev/null 2>&1; then echo "  ok       $1 — $2"; else echo "  ausente  $1 — $2 ($3)"; fi; }
dep node "necessário para tudo"                    "https://nodejs.org"
dep npx  "roda os MCPs"                            "vem com o node"
echo "  -- opcionais --"
if [ -d "/Applications/Google Chrome.app" ] || command -v google-chrome >/dev/null 2>&1; then
  echo "  ok       Chrome — MCP chrome-devtools"
else
  echo "  ausente  Chrome — MCP chrome-devtools (instale o Google Chrome)"
fi
[ -n "${OPENAI_API_KEY:-}" ] && echo "  ok       OPENAI_API_KEY — skill imagegen" \
  || echo "  ausente  OPENAI_API_KEY — skill imagegen (necessária para remoção de fundo)"

echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
