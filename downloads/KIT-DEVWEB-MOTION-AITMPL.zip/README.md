# Kit DevWeb + Motion — sites e landing pages com animação

**31 skills, 4 agents, 4 commands e 4 MCPs** para construir sites e landing pages
com animação. Tudo já instalado nesta pasta — não precisa rodar `npx`.

30 skills vêm do [aitmpl.com](https://aitmpl.com/). A skill **`web-motion` foi
escrita para este kit**, porque o catálogo não tem nenhuma skill de animação web.

---

## O que você precisa saber antes

**O catálogo do aitmpl.com não tem skill de animação.** Varri as 872 skills por
`gsap`, `framer`, `motion`, `lottie`, `keyframe`, `easing`, `parallax` e mais 8
termos. A skill mais baixada do catálogo inteiro — `frontend-design`, 12.382
downloads — não menciona nenhuma biblioteca de animação. `scroll-experience` tem
8 KB e cita GSAP uma vez. E **nenhum componente do catálogo menciona
`prefers-reduced-motion`**, que é requisito WCAG e questão de saúde.

Por isso `web-motion` existe: 6 arquivos, 56 KB, escritos para este kit. É a peça
que faz o resto funcionar para o que você pediu.

---

## Como usar

### Opção A — trabalhar dentro desta pasta

```bash
claude
```
Rode `/kit-motion` para ver o que está disponível.

### Opção B — instalar num projeto existente

```bash
./install.sh /caminho/do/seu/projeto
```

### Windows (PowerShell)

```powershell
.\install.ps1 C:\caminho\do\seu\projeto
```

Se o Windows bloquear a execução do script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Isso libera só a sessão atual — não altera a política da máquina.

### macOS e Linux

```bash
chmod +x install.sh check.sh    # só na primeira vez
./install.sh /caminho/do/seu/projeto
./check.sh
```

O `install.ps1` também roda no macOS e no Linux, se você tiver PowerShell 7+.

Não sobrescreve nada. `CLAUDE.md` existente ganha `@import`; `.mcp.json` é mesclado
preservando o que já era seu. Rodar duas vezes não duplica.

### Conferir

```bash
./check.sh
```

---

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-motion [assunto]` | Mostra o que está instalado e o que se aplica ao seu caso |
| `/landing [descrição]` | Landing page completa: copy → visual → página estática → animação → verificação |
| `/animar-produto [imagem]` | Anima a imagem de produto anexada — escolhe a técnica olhando a imagem real |
| `/revisar-motion [alvo]` | Audita as animações do projeto: performance, acessibilidade, propósito |

`/landing` impõe uma ordem que a maioria das IAs erra: **copy antes de layout, e
página estática completa antes de qualquer animação.** Animação é camada, não
estrutura.

---

## A skill `web-motion`

```
.claude/skills/web-motion/
├── SKILL.md                        árvore de decisão, as 3 regras, valores de easing
└── referencias/
    ├── escolha-tecnica.md          CSS · WAAPI · IntersectionObserver · GSAP ·
    │                               Motion · scroll-driven · View Transitions ·
    │                               Lottie · Three.js — com código e quando usar
    ├── receitas.md                 reveal, stagger, hero por linha, tilt 3D,
    │                               marquee, sheen, contador, skeleton, accordion,
    │                               transição de página
    ├── produto-imagem.md           5 casos mapeados para animar produto anexado
    ├── performance.md              pipeline do navegador, will-change, layout
    │                               thrash, imagens, como medir, peso das libs
    └── acessibilidade.md           prefers-reduced-motion feito direito, foco,
                                    teclado, leitor de tela
```

As três regras que ela impõe:

1. **Anime só `transform` e `opacity`.** O compositor resolve as duas na GPU. Todas
   as outras forçam layout ou paint a cada frame — é a diferença entre 60 fps e
   20 fps num celular médio.
2. **`prefers-reduced-motion` sempre.** E reduzir significa trocar movimento por
   fade, não desligar o feedback.
3. **Nunca deixe conteúdo dependendo de JS para ficar visível.** Se o observer não
   disparar, o texto some para sempre. Já derrubou landing page em produção.

---

## Animar a imagem do produto

O caso que você pediu tem um fluxo dedicado em `referencias/produto-imagem.md`.
A técnica é escolhida **olhando a imagem**, não por padrão:

| O que você tem | O que dá para fazer |
|---|---|
| PNG recortado | Tilt 3D no ponteiro, float com sombra acompanhando, sheen, reveal `clip-path` |
| Foto com fundo | Ken Burns, ou remove o fundo antes (skill `imagegen`) |
| Camadas separadas | Parallax real — o efeito mais convincente |
| Vários ângulos | Spin 360 por arraste |
| Modelo `.glb` | Three.js / R3F (skill `3d-web-experience`) |

O detalhe que vende a ilusão do float: **a sombra encolhe quando o produto sobe.**
Está no arquivo, com código.

---

## O que está instalado

**Landing page e design** — `frontend-design` (12.382), `ui-ux-pro-max` (6.790),
`ui-design-system` (4.209), `premium-web-design` (206), `theme-factory` (957),
`tailwind-patterns` (656), `web-design-guidelines` (481), `copywriting` (923),
`page-cro` (97).

`premium-web-design` é a descoberta subestimada do catálogo: só 206 downloads, mas
60 KB de conteúdo, e dispara exatamente quando o usuário reclama de "cara de IA" ou
pede qualidade de agência.

**Animação e experiência** — **`web-motion`** (própria), `3d-web-experience` (971),
`scroll-experience` (468), `algorithmic-art` (358), `interactive-portfolio` (135),
`claude-d3js-skill` (113), `slack-gif-creator` (71).

**Imagem** — `canvas-design` (2.626), `imagegen` (78).

**Stack** — `react-best-practices` (3.272), `web-performance-optimization` (806),
`tailwind-design-system` (117), `shadcn` (107), `nextjs-app-router-patterns` (79),
`astro` (34), `roier-seo` (125).

**Acessibilidade** — `accessibility-auditor` (187), agent
`web-accessibility-checker` (350).

**Figma** — `figma` (186), `figma-implement-design` (165).

**Vídeo** (se o entregável for vídeo, não página) — `remotion` (226),
`remotion-best-practices` (108), `motion-canvas` (66).

**Agents** — `frontend-developer` (10.867), `ui-ux-designer` (7.029),
`ui-designer` (420), `web-accessibility-checker` (350).

Lista completa com justificativa: [KIT-DEVWEB-MOTION-AITMPL.md](KIT-DEVWEB-MOTION-AITMPL.md).

---

## MCPs

### Ativos — `.mcp.json`

| Servidor | O que faz | Requisitos |
|---|---|---|
| `chrome-devtools` | Automação + **performance trace**. Confirma 60 fps medindo | Chrome instalado |
| `playwright` | Abre a página, screenshot, executa JS | nenhum |

São o que permite a IA **ver a animação rodando** em vez de entregar no escuro.
Sem eles, ela deve dizer que não conseguiu verificar — está instruída a isso no
`CLAUDE.md`.

### Opcionais — `.mcp.optional.json`

| Servidor | Requisitos |
|---|---|
| `context7` | Chave de API — puxa a doc atual de GSAP, Motion, Three.js da fonte |
| `figma-dev-mode` | App desktop do Figma rodando local (porta 3845) |

`context7` vale a pena se você usa GSAP ou Motion: evita a IA trabalhar de memória
sobre APIs que mudam de versão.

---

## Limitações — leia antes de confiar

1. **Não existe skill de animação no catálogo.** É a razão de `web-motion` existir.
   Se alguém disser que instalou GSAP "do aitmpl.com", não instalou.

2. **`premium-web-design` gera React (.jsx).** Se seu projeto é HTML puro ou Astro,
   você vai precisar traduzir. A skill não avisa isso.

3. **`imagegen` exige chave paga da OpenAI.** Sem `OPENAI_API_KEY`, não funciona —
   inclusive a remoção de fundo. O `check.sh` verifica se a variável existe.

4. **Popularidade desigual.** `astro` (34 downloads na origem), `slack-gif-creator`
   (71), `imagegen` (78) e `page-cro` (97) são pouco usados, provavelmente pouco
   testados. Já `frontend-design` (12.382) e `frontend-developer` (10.867) são os
   mais baixados do catálogo inteiro.

5. **View Transitions e scroll-driven CSS têm suporte parcial.** Progressive
   enhancement sempre — `@supports` e checagem de `document.startViewTransition`.
   Nunca como fundação.

6. **Animação bonita não é animação boa.** Se o LCP passa de 2,5 s ou o scroll trava
   no celular, está errada por definição — por mais bonita que esteja no seu monitor.
   Por isso `/revisar-motion` mede antes de aprovar.

---

## Arquivos

```
KIT-DEVWEB-MOTION-AITMPL/
├── CLAUDE.md                     contexto automático: roteamento e regras de animação
├── README.md                     este arquivo
├── KIT-DEVWEB-MOTION-AITMPL.md   análise do catálogo que originou a seleção
├── install.sh                    instala em outro projeto
├── check.sh                      verifica instalação e ferramentas
├── .mcp.json                     MCPs prontos (chrome-devtools, playwright)
├── .mcp.optional.json            MCPs que precisam de setup
└── .claude/
    ├── skills/                   31 skills (30 do catálogo + web-motion)
    ├── agents/                   4 agents
    └── commands/                 /kit-motion /landing /animar-produto /revisar-motion
```

## Atualizar um componente

```bash
npx claude-code-templates@latest --skill <categoria>/<nome> --yes
```

Rode a partir desta pasta. A API do GitHub limita a 60 requisições/hora sem
autenticação — instalar 30 skills de uma vez estoura o limite e falha com HTTP 403.
Este kit foi instalado clonando o repositório, que não passa pela API REST.

**Não atualize `web-motion` por esse comando** — ela não está no catálogo e seria
sobrescrita ou removida.
