# Escolha da técnica

Da mais simples para a mais pesada. Só suba de nível quando a anterior não resolver.

---

## 1. CSS transition — o padrão

Resolve a maioria dos casos: hover, focus, toggle de classe.

```css
.card {
  transition: transform 220ms cubic-bezier(0.16, 1, 0.32, 1),
              box-shadow 220ms cubic-bezier(0.16, 1, 0.32, 1);
}
.card:hover { transform: translateY(-4px); box-shadow: 0 12px 32px rgb(0 0 0 / 0.12); }
```

**Liste as propriedades.** `transition: all` faz o navegador observar todas —
inclusive as que você nunca anima — e causa transições acidentais quando outra
regra muda algo.

Limite: não anima entrada/saída do DOM. Elemento que acabou de ser inserido não
transiciona a partir do estado inicial sem um reflow forçado.

---

## 2. CSS @keyframes — loop e sequência sem interação

```css
@keyframes float {
  0%, 100% { transform: translateY(0); }
  50%      { transform: translateY(-8px); }
}
.produto { animation: float 4s ease-in-out infinite; }
```

Para animação de entrada única, `animation-fill-mode: both` mantém o estado final:

```css
@keyframes reveal-up {
  from { opacity: 0; transform: translateY(20px); }
  to   { opacity: 1; transform: none; }
}
.reveal { animation: reveal-up 520ms cubic-bezier(0.16, 1, 0.32, 1) both; }
```

---

## 3. Web Animations API — controle via JS, sem biblioteca

Mesma performance do CSS, com play/pause/reverse/seek. Suporte universal.

```js
const anim = el.animate(
  [ { opacity: 0, transform: 'translateY(20px)' },
    { opacity: 1, transform: 'none' } ],
  { duration: 520, easing: 'cubic-bezier(0.16, 1, 0.32, 1)', fill: 'both' }
);

anim.pause();
anim.reverse();
anim.finished.then(() => el.style.willChange = 'auto');
```

Útil para stagger sem escrever CSS por índice:

```js
items.forEach((el, i) => {
  el.animate(
    [{ opacity: 0, transform: 'translateY(16px)' }, { opacity: 1, transform: 'none' }],
    { duration: 480, delay: i * 60, easing: 'cubic-bezier(0.16,1,0.32,1)', fill: 'both' }
  );
});
```

---

## 4. IntersectionObserver — reveal ao entrar na viewport

**Não instale biblioteca para isso.** São 12 linhas e é a forma correta.

```js
const io = new IntersectionObserver((entries) => {
  for (const e of entries) {
    if (!e.isIntersecting) continue;
    e.target.classList.add('is-visible');
    io.unobserve(e.target);          // revela uma vez só
  }
}, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });

document.querySelectorAll('.reveal').forEach(el => io.observe(el));
```

`rootMargin` negativo no fim faz o reveal disparar um pouco antes do elemento
encostar na borda — parece mais natural que disparar exatamente no limite.

Lembre do fallback sem JS (ver seção 3.3 do SKILL.md).

---

## 5. GSAP + ScrollTrigger — timeline e scroll com controle fino

Vale o peso quando você precisa de: sequência longa com sobreposição, scrub
amarrado ao scroll, pin de seção, ou controle preciso de progresso.

```js
import gsap from 'gsap';
import ScrollTrigger from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);

// timeline com sobreposição
const tl = gsap.timeline({ defaults: { ease: 'power3.out', duration: 0.6 } });
tl.from('.hero-title', { y: 40, opacity: 0 })
  .from('.hero-sub',   { y: 24, opacity: 0 }, '-=0.35')   // começa antes da anterior acabar
  .from('.hero-cta',   { y: 16, opacity: 0 }, '-=0.3');

// scrub: progresso amarrado ao scroll
gsap.to('.produto', {
  scrollTrigger: { trigger: '.secao', start: 'top bottom', end: 'bottom top', scrub: 1 },
  rotate: 360,
  ease: 'none',
});
```

`scrub: 1` adiciona 1s de suavização — sem isso, o movimento gruda no scroll e
fica áspero.

Respeite reduced motion — GSAP tem API própria:

```js
ScrollTrigger.matchMedia({
  '(prefers-reduced-motion: no-preference)': () => { /* animações aqui */ },
});
```

**Antes de instalar GSAP, confirme que CSS + IntersectionObserver não resolvem.**
Para fade e reveal, não resolvem melhor — só pesam mais.

---

## 6. Motion / Framer Motion — React com entrada e saída

O que CSS não resolve: animar um elemento que está sendo **removido** da árvore.

```jsx
import { motion, AnimatePresence } from 'motion/react';

<AnimatePresence>
  {aberto && (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 8 }}
      transition={{ duration: 0.24, ease: [0.16, 1, 0.32, 1] }}
    >
      {conteudo}
    </motion.div>
  )}
</AnimatePresence>
```

`layoutId` faz transição contínua entre dois elementos diferentes — item de grid
que vira detalhe, por exemplo:

```jsx
<motion.img layoutId={`produto-${id}`} src={src} />
```

Hook nativo para reduced motion:

```jsx
import { useReducedMotion } from 'motion/react';
const reduzir = useReducedMotion();
<motion.div animate={{ y: reduzir ? 0 : -20, opacity: 1 }} />
```

> O pacote foi renomeado: `framer-motion` → `motion` (import `motion/react`).
> Projetos existentes ainda usam `framer-motion` e funcionam. Confirme a versão do
> projeto antes de escrever o import — use o MCP `context7` se precisar da API atual.

---

## 7. Scroll-driven animations em CSS puro

Sem JS, sem biblioteca. Suporte ainda parcial (Chromium e Safari recentes) —
**sempre** como progressive enhancement.

```css
@supports (animation-timeline: view()) {
  @media (prefers-reduced-motion: no-preference) {
    .reveal {
      animation: reveal-up linear both;
      animation-timeline: view();
      animation-range: entry 10% cover 35%;
    }
  }
}
```

`view()` = progresso do elemento cruzando a viewport.
`scroll()` = progresso do scroll do container.

---

## 8. View Transitions — entre estados e páginas

```js
if (document.startViewTransition) {
  document.startViewTransition(() => atualizarDOM());
} else {
  atualizarDOM();   // fallback obrigatório
}
```

Elementos que devem ter continuidade recebem nome:

```css
.produto-hero { view-transition-name: produto; }
```

O nome precisa ser **único na página** — dois elementos com o mesmo
`view-transition-name` fazem a transição falhar silenciosamente.

Entre documentos (navegação real de página), em Chromium recente:

```css
@view-transition { navigation: auto; }
```

---

## 9. Lottie — vetor complexo feito por designer

Quando a animação veio do After Effects. Use `dotlottie-web` (mais leve que o
player clássico) e sirva `.lottie` em vez de `.json`.

Um Lottie de 500 KB é pior que a animação CSS que ele substitui. Peça ao designer
para simplificar antes de aceitar o arquivo.

---

## 10. Three.js / React Three Fiber

Cena 3D, produto rotacionável, material e luz. Use a skill `3d-web-experience`.

Custo real: o bundle passa de 150 KB e o primeiro render é caro. Em landing page,
carregue sob demanda (`dynamic import`) e mostre a imagem estática antes.
