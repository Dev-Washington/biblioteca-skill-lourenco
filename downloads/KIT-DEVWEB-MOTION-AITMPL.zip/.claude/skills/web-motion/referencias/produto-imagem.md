# Animar imagem de produto anexada

Cenário: o usuário anexou a foto de um produto e quer ver esse produto animado no site.

---

## Passo 1 — Olhe a imagem antes de decidir

Use a ferramenta **Read** na imagem. Não escolha a técnica no escuro. O que
determina tudo:

| Pergunta | Por que importa |
|---|---|
| Tem fundo, ou é PNG recortado? | Com fundo, só dá Ken Burns. Recortado, abre tilt, float, parallax |
| É foto ou render? | Render costuma ter fundo limpo e aguenta escala; foto tem ruído e granula |
| Qual o ângulo? | Frontal aguenta tilt leve. Já em perspectiva, tilt fica estranho |
| Quantas imagens? | Várias em ângulos diferentes → spin 360 |
| Qual a resolução? | Abaixo de ~1200 px de largura, evite scale acima de 1.1 — borra |
| Onde fica na página? | Hero pede entrada forte. Meio de página pede scroll-driven |

**Pergunte ao usuário o que o produto é e que sensação ele quer** — leveza, solidez,
precisão, luxo. Isso muda mais o resultado do que qualquer escolha técnica. Um
tênis quer float e leveza; uma furadeira quer peso e estabilidade.

## Passo 2 — Prepare a imagem

Antes de animar. Uma imagem pesada anula qualquer ganho de performance.

```bash
# AVIF com fallback WebP
npx @squoosh/cli --avif '{"cqLevel":33}' produto.png
npx @squoosh/cli --webp '{"quality":82}' produto.png
```

```html
<picture>
  <source srcset="produto.avif" type="image/avif">
  <source srcset="produto.webp" type="image/webp">
  <img src="produto.png" alt="Descrição real do produto"
       width="1200" height="1200"
       fetchpriority="high" decoding="async">
</picture>
```

`width` e `height` são obrigatórios — sem eles a página salta quando a imagem
carrega (CLS), e o salto arruína qualquer animação de entrada.

Para remover o fundo, use a skill `imagegen` (OpenAI Image API faz background
removal) ou peça o PNG recortado ao usuário. **Recorte manual bem-feito ganha de
recorte automático** em produto com borda complexa — cabelo, transparência, malha.

---

## Caso A — PNG recortado (o melhor cenário)

### A.1 Entrada no hero: reveal com escala

```css
.produto-hero {
  animation: produto-entra 900ms cubic-bezier(0.16, 1, 0.32, 1) both;
}
@keyframes produto-entra {
  from { opacity: 0; transform: translateY(28px) scale(0.94); }
  to   { opacity: 1; transform: none; }
}
```

Escala **subindo** para 1 (de 0.94), nunca partindo de 1.2 para baixo — reduzir
uma imagem raster a partir de escala maior mostra os pixels.

### A.2 Float idle — dá vida sem pedir atenção

```css
@keyframes flutuar {
  0%, 100% { transform: translateY(0) rotate(0deg); }
  50%      { transform: translateY(-10px) rotate(0.6deg); }
}
.produto-hero { animation: flutuar 5s ease-in-out infinite; }
```

Combine com a sombra, senão parece recorte colado:

```css
@keyframes sombra {
  0%, 100% { transform: scaleX(1);    opacity: 0.28; }
  50%      { transform: scaleX(0.88); opacity: 0.18; }
}
.produto-sombra {
  animation: sombra 5s ease-in-out infinite;
  filter: blur(18px);
}
```

A sombra encolhe quando o produto sobe. É esse detalhe que vende a ilusão.

> Entrada e float são duas animações no mesmo elemento. Ou use elementos aninhados
> (um para cada), ou encadeie via `animationend` — duas `animation` na mesma
> propriedade `transform` se sobrescrevem.

### A.3 Tilt 3D no ponteiro

Ver `receitas.md` → "Tilt 3D no ponteiro". Para produto, mantenha `MAX` entre 8° e
12°. Acima disso a perspectiva denuncia que é uma imagem plana.

Ganho grande por uma linha — mova a sombra na direção oposta:

```js
alvo.style.setProperty('--sombra-x', `${px * -20}px`);
```

### A.4 Reveal com clip-path — o produto "se materializa"

```css
@keyframes revelar {
  from { clip-path: inset(0 0 100% 0); }
  to   { clip-path: inset(0 0 0 0); }
}
.produto { animation: revelar 800ms cubic-bezier(0.65, 0, 0.35, 1) both; }
```

`clip-path` é acelerado na maioria dos navegadores modernos, mas não é tão barato
quanto `transform`. Em hero único, sem problema; numa grade de 30 produtos, meça.

---

## Caso B — Foto com fundo: Ken Burns

Zoom e pan lentos. Funciona porque não exige recorte.

```css
.kb { overflow: hidden; }
.kb img {
  width: 100%;
  animation: ken-burns 18s ease-in-out infinite alternate;
  transform-origin: 60% 40%;              /* aponte para o produto, não para o centro */
}
@keyframes ken-burns {
  from { transform: scale(1)    translate(0, 0); }
  to   { transform: scale(1.10) translate(-1.5%, -1%); }
}
```

Regras: escala máxima 1.12 (acima disso borra), duração acima de 15 s (rápido
parece nervoso), `alternate` para não ter corte seco no reinício.

---

## Caso C — Camadas separadas: parallax real

O efeito mais convincente, e o que mais dá trabalho. Precisa de produto, sombra e
fundo em arquivos separados.

```css
.palco { position: relative; perspective: 1000px; }
.camada { position: absolute; inset: 0; will-change: transform; }
```

```js
const palco = document.querySelector('.palco');
const camadas = [...palco.querySelectorAll('.camada')];   // fundo → frente
let raf;

palco.addEventListener('pointermove', (e) => {
  cancelAnimationFrame(raf);
  raf = requestAnimationFrame(() => {
    const r = palco.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width  - 0.5;
    const py = (e.clientY - r.top)  / r.height - 0.5;
    camadas.forEach((c, i) => {
      const f = (i + 1) * 8;                              // frente move mais
      c.style.transform = `translate3d(${px * f}px, ${py * f}px, 0)`;
    });
  });
});
```

O `requestAnimationFrame` não é opcional: `pointermove` dispara dezenas de vezes
por segundo e escrever `transform` direto no handler causa jank.

---

## Caso D — Várias fotos em ângulo: spin 360

```js
const quadros = [...document.querySelectorAll('.spin img')];
let atual = 0, arrastando = false, x0 = 0;

const mostrar = (i) => {
  quadros[atual].hidden = true;
  atual = ((i % quadros.length) + quadros.length) % quadros.length;
  quadros[atual].hidden = false;
};

const palco = document.querySelector('.spin');
palco.addEventListener('pointerdown', (e) => { arrastando = true; x0 = e.clientX; palco.setPointerCapture(e.pointerId); });
palco.addEventListener('pointerup',   () => { arrastando = false; });
palco.addEventListener('pointermove', (e) => {
  if (!arrastando) return;
  const d = e.clientX - x0;
  if (Math.abs(d) < 6) return;                 // limiar: evita trocar no clique
  mostrar(atual + Math.sign(d));
  x0 = e.clientX;
});
```

Pré-carregue **todos** os quadros antes de habilitar o arraste, senão o giro
engasga no primeiro loop:

```js
await Promise.all(quadros.map(img => img.decode().catch(() => {})));
palco.dataset.pronto = '';
```

Entre 24 e 36 quadros dá um giro fluido. Menos que 16 fica em saltos. Sirva todos
em AVIF — 36 PNGs de 500 KB são 18 MB.

---

## Caso E — Modelo 3D (.glb)

Use a skill `3d-web-experience` (Three.js / React Three Fiber).

Em landing page, carregue sob demanda:

```js
const alvo = document.querySelector('#palco-3d');
new IntersectionObserver(async ([e], obs) => {
  if (!e.isIntersecting) return;
  obs.disconnect();
  const { montarCena } = await import('./cena-3d.js');   // só baixa aqui
  montarCena(alvo);
}, { rootMargin: '200px' }).observe(alvo);
```

Mostre a imagem estática enquanto o 3D não montou. Quem nunca rolar até lá não
baixa 150 KB de Three.js.

---

## Scroll-driven — produto reagindo ao scroll

```js
gsap.to('.produto', {
  scrollTrigger: { trigger: '.secao-produto', start: 'top 80%', end: 'bottom 20%', scrub: 1 },
  rotateY: 25, scale: 1.08, ease: 'none',
});
```

Em CSS puro, com progressive enhancement:

```css
@supports (animation-timeline: view()) {
  @media (prefers-reduced-motion: no-preference) {
    .produto { animation: girar linear both; animation-timeline: view(); animation-range: entry 20% cover 60%; }
  }
}
@keyframes girar { to { transform: rotateY(20deg) scale(1.06); } }
```

---

## Checklist antes de entregar

- [ ] Imagem em AVIF/WebP com fallback, `width`/`height` no `<img>`
- [ ] `alt` descreve o produto de verdade — não é "imagem do produto"
- [ ] `fetchpriority="high"` se está no hero
- [ ] Só `transform` e `opacity` animando (exceto `clip-path` pontual)
- [ ] `prefers-reduced-motion` reduz a movimento mínimo, sem esconder o produto
- [ ] Tilt e parallax desligados em touch (`pointer: coarse`)
- [ ] Sombra acompanha o movimento, se houver
- [ ] Verificado no browser via MCP `chrome-devtools`/`playwright` — screenshot antes e depois do scroll
- [ ] 60 fps com CPU em throttle 4×
