# Acessibilidade em animação

## prefers-reduced-motion

Reflete uma configuração do sistema operacional do usuário. Quem ativa costuma ter
motivo médico: distúrbio vestibular, enxaqueca vestibular, epilepsia fotossensível.
Parallax e movimento amplo causam náusea real nessas pessoas.

É requisito WCAG 2.3.3 (Animation from Interactions, nível AAA) e toca o 2.2.2
(Pause, Stop, Hide, nível A) quando a animação é automática e dura mais de 5 s.

### Piso mínimo

```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

Cole isso no reset. Garante que nada quebra. Mas é o piso.

### O certo: substituir, não desligar

Reduzir movimento **não é** remover a animação. O usuário ainda precisa perceber
que algo mudou — só não pode se deslocar pela tela.

Troque translação por fade:

```css
.reveal {
  opacity: 0;
  transform: translateY(24px);
  transition: opacity 520ms var(--ease-out), transform 520ms var(--ease-out);
}
.reveal.is-visible { opacity: 1; transform: none; }

@media (prefers-reduced-motion: reduce) {
  .reveal { transform: none; transition: opacity 200ms linear; }
  .reveal.is-visible { opacity: 1; }
}
```

Movimento sumiu, feedback continua.

### Em JavaScript

```js
const mq = matchMedia('(prefers-reduced-motion: reduce)');

function configurar() {
  if (mq.matches) { /* estado final direto, sem animar */ }
  else            { /* animação completa */ }
}
configurar();
mq.addEventListener('change', configurar);   // o usuário pode mudar com a página aberta
```

### Em GSAP

```js
ScrollTrigger.matchMedia({
  '(prefers-reduced-motion: no-preference)': () => { /* parallax, scrub, pin */ },
  '(prefers-reduced-motion: reduce)':        () => { /* nada, ou só fade */ },
});
```

### Em Motion / Framer Motion

```jsx
import { useReducedMotion } from 'motion/react';
const reduzir = useReducedMotion();
<motion.div
  initial={{ opacity: 0, y: reduzir ? 0 : 20 }}
  animate={{ opacity: 1, y: 0 }}
  transition={{ duration: reduzir ? 0.15 : 0.5 }}
/>
```

---

## O que evitar sempre

| Padrão | Problema |
|---|---|
| Flash acima de 3×/s | Risco de convulsão fotossensível. WCAG 2.3.1, nível A |
| Parallax de tela cheia sem opção de desligar | Náusea vestibular |
| Carrossel com autoplay sem pausa | WCAG 2.2.2 exige pausar/parar/esconder |
| `scroll-behavior: smooth` global | Desorienta em salto longo; ignora reduced motion se não for tratado |
| Scroll sequestrado (scrolljacking) | Quebra teclado, quebra trackpad, causa enjoo |
| Animação que atrasa conteúdo essencial | Texto que só aparece depois de 2 s de animação |

## Foco e teclado

Animação não pode quebrar navegação por teclado.

```css
:focus-visible { outline: 2px solid currentColor; outline-offset: 3px; }
```

- Nunca `outline: none` sem substituto visível.
- Elemento animado com `opacity: 0` continua focável — o usuário de teclado
  "some" dentro de conteúdo invisível. Use `visibility: hidden` ou `inert`:

```css
.painel[hidden-anim] { opacity: 0; visibility: hidden; }
```

```html
<div class="painel" inert>…</div>
```

- Após transição de página, mova o foco para o `<h1>` da nova view. Sem isso o
  leitor de tela continua no ponto antigo.

## Movimento e leitor de tela

Conteúdo que aparece por animação precisa ser anunciado:

```html
<div role="status" aria-live="polite">3 itens adicionados</div>
```

Elemento puramente decorativo em movimento deve ser escondido da árvore de
acessibilidade:

```html
<div class="particulas" aria-hidden="true"></div>
```

## Checklist

- [ ] Bloco de `prefers-reduced-motion` no reset
- [ ] Animações importantes têm variante reduzida (fade), não só desligada
- [ ] Nada pisca mais de 3× por segundo
- [ ] Carrossel/autoplay tem controle de pausa
- [ ] `:focus-visible` visível em tudo que é focável
- [ ] Elemento invisível por animação não é focável (`inert`/`visibility`)
- [ ] Foco reposicionado após transição de rota
- [ ] Decoração animada com `aria-hidden="true"`
- [ ] Testado com teclado, do início ao fim da página
