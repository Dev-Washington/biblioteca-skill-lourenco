# Performance de animação

## O pipeline do navegador

Cada frame pode passar por até quatro etapas. Quanto menos, melhor:

```
JavaScript → Style → Layout → Paint → Composite
```

- Animar `width`, `height`, `top`, `left`, `margin`, `padding` → **Layout**.
  O navegador recalcula a posição de tudo. Caro.
- Animar `color`, `background`, `box-shadow`, `border-radius` → **Paint**.
  Repinta pixels. Médio.
- Animar `transform` e `opacity` → **Composite** apenas.
  A GPU move uma textura pronta. Barato.

Por isso a regra: `transform` e `opacity`. Não é preferência de estilo — é a
diferença entre 60 fps e 20 fps num celular médio.

## Equivalências

| Não anime | Anime |
|---|---|
| `left: 100px` | `transform: translateX(100px)` |
| `width: 200px` | `transform: scaleX(2)` |
| `top` + `left` | `transform: translate3d(x, y, 0)` |
| `display: none` ↔ `block` | `opacity` + `visibility` + `pointer-events` |
| `box-shadow` crescendo | camada `::after` com sombra pronta, animando `opacity` |
| `height: auto` | `grid-template-rows: 0fr → 1fr` |

O truque da sombra vale destacar: `box-shadow` animado repinta a cada frame.
Duas sombras em pseudo-elementos, alternando `opacity`, ficam idênticas e custam nada.

## will-change

Promete ao navegador que algo vai mudar, para ele preparar uma camada.

```css
.card:hover { will-change: transform; }   /* prepara no hover */
.card       { will-change: auto; }        /* solta o resto do tempo */
```

Em JS, solte ao terminar:

```js
el.style.willChange = 'transform';
anim.finished.then(() => { el.style.willChange = 'auto'; });
```

**Nunca deixe `will-change` estático em muitos elementos.** Cada um vira uma camada
de composição com memória de GPU própria. Em 50 cards, você criou 50 texturas e
deixou o site mais lento do que sem otimização nenhuma.

## Handlers de scroll e pointer

Nunca escreva estilo direto no handler:

```js
// ruim — dispara dezenas de vezes por segundo
window.addEventListener('scroll', () => { el.style.transform = `translateY(${scrollY * 0.3}px)`; });

// bom — no máximo um por frame
let pendente = false;
window.addEventListener('scroll', () => {
  if (pendente) return;
  pendente = true;
  requestAnimationFrame(() => { el.style.transform = `translateY(${scrollY * 0.3}px)`; pendente = false; });
}, { passive: true });
```

`{ passive: true }` diz ao navegador que você não vai chamar `preventDefault()`,
liberando o scroll para rolar sem esperar seu código.

Para detectar entrada na viewport, `IntersectionObserver` é melhor que `scroll` —
roda fora da thread principal.

## Layout thrash

Ler uma propriedade geométrica depois de escrever força recálculo síncrono:

```js
// ruim: lê → escreve → lê → escreve, cada leitura força layout
items.forEach(el => { el.style.height = el.offsetHeight * 2 + 'px'; });

// bom: lê tudo, depois escreve tudo
const alturas = items.map(el => el.offsetHeight);
items.forEach((el, i) => { el.style.height = alturas[i] * 2 + 'px'; });
```

Forçam layout ao serem lidos: `offsetTop/Left/Width/Height`, `clientWidth/Height`,
`scrollTop/Height`, `getBoundingClientRect()`, `getComputedStyle()`.

## Imagens

A animação quase nunca é o gargalo — a imagem é.

- **AVIF** primeiro, **WebP** como fallback, formato original por último.
- `width` e `height` sempre no `<img>`. Sem eles, CLS.
- `loading="lazy"` fora do hero. **Nunca** no hero — atrasa o LCP.
- `fetchpriority="high"` na imagem do hero.
- `decoding="async"` para não bloquear.
- `srcset` + `sizes` para não servir 2400 px a um celular.

```html
<img src="hero.avif" alt="..." width="1600" height="900"
     srcset="hero-800.avif 800w, hero-1600.avif 1600w, hero-2400.avif 2400w"
     sizes="(max-width: 768px) 100vw, 1200px"
     fetchpriority="high" decoding="async">
```

## Fontes

Animação que começa antes da fonte carregar causa salto:

```css
@font-face { font-family: 'Sans'; src: url(...); font-display: swap; }
```

```js
document.fonts.ready.then(() => document.documentElement.classList.add('fontes-ok'));
```

E dispare as animações de texto só com `.fontes-ok` presente.

## Como medir

**No DevTools:**
1. Performance → CPU throttle 4× (ou 6× para simular celular fraco)
2. Grave durante a animação
3. Procure: frames longos (barra vermelha), "Layout" e "Recalculate Style" repetidos
4. Rendering → "Frame Rendering Stats" mostra fps ao vivo
5. Rendering → "Paint flashing" mostra em verde o que está repintando. Durante uma
   animação bem-feita, quase nada pisca.

**Via MCP `chrome-devtools`**, você consegue gravar o trace e ler o resultado sem
sair da conversa. Use — é a diferença entre achar que está a 60 fps e saber.

**Alvos:** 60 fps (16,7 ms por frame). Nenhuma long task acima de 50 ms durante a
animação. LCP abaixo de 2,5 s. CLS abaixo de 0,1.

## Custo das bibliotecas

Antes de instalar, compare com o que você ganha (valores aproximados, minificado+gzip):

| Biblioteca | Peso aproximado |
|---|---|
| Nada (CSS + IntersectionObserver) | 0 |
| Motion (`motion/react`) | ~18–35 KB, varia com o que importa |
| GSAP core | ~25 KB |
| GSAP + ScrollTrigger | ~40 KB |
| Lottie (dotlottie-web) | ~40 KB + o arquivo da animação |
| Three.js | 150 KB+ |

Confirme o número atual antes de citar ao usuário — versões mudam. Para fade,
reveal e stagger, CSS puro entrega o mesmo resultado com 0 KB.
