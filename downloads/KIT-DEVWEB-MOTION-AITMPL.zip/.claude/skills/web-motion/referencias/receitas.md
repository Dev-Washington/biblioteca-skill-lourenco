# Receitas

Padrões prontos. Todos assumem estes tokens no `:root`:

```css
:root {
  --ease-out:    cubic-bezier(0.16, 1, 0.32, 1);
  --ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);
  --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  --dur-fast: 160ms;
  --dur-base: 280ms;
  --dur-slow: 520ms;
}
```

E que o bloco de `prefers-reduced-motion` de `acessibilidade.md` está aplicado.

---

## Reveal ao entrar na viewport

```css
.reveal { opacity: 1; }                     /* sem JS: visível */
.js-ready .reveal {
  opacity: 0;
  transform: translateY(20px);
  transition: opacity var(--dur-slow) var(--ease-out),
              transform var(--dur-slow) var(--ease-out);
}
.js-ready .reveal.is-visible { opacity: 1; transform: none; }
```

```js
document.documentElement.classList.add('js-ready');
const io = new IntersectionObserver((es) => {
  for (const e of es) if (e.isIntersecting) { e.target.classList.add('is-visible'); io.unobserve(e.target); }
}, { threshold: 0.15, rootMargin: '0px 0px -10% 0px' });
document.querySelectorAll('.reveal').forEach(el => io.observe(el));
```

## Stagger — lista entrando em sequência

```css
.js-ready .stagger > * {
  opacity: 0; transform: translateY(16px);
  transition: opacity var(--dur-base) var(--ease-out),
              transform var(--dur-base) var(--ease-out);
  transition-delay: calc(var(--i, 0) * 60ms);
}
.js-ready .stagger.is-visible > * { opacity: 1; transform: none; }
```

```js
document.querySelectorAll('.stagger').forEach(g =>
  [...g.children].forEach((el, i) => el.style.setProperty('--i', i)));
```

60 ms entre itens. Acima de 8 itens, reduza para 30–40 ms ou o último demora demais.

## Hero — título por linha

```css
.hero-linha { display: block; overflow: hidden; }
.hero-linha > span {
  display: block;
  transform: translateY(100%);
  animation: subir var(--dur-slow) var(--ease-out) both;
  animation-delay: calc(var(--i) * 80ms);
}
@keyframes subir { to { transform: none; } }
```

O `overflow: hidden` no pai faz o texto surgir "de dentro" da linha. É o efeito de
hero mais usado em site premium e custa duas regras.

Espere a fonte carregar, senão o texto salta:

```js
document.fonts.ready.then(() => document.body.classList.add('fontes-ok'));
```

## Botão com feedback

```css
.btn {
  transition: transform var(--dur-fast) var(--ease-out),
              background-color var(--dur-fast) linear;
}
.btn:hover  { transform: translateY(-2px); }
.btn:active { transform: translateY(0) scale(0.98); transition-duration: 80ms; }
.btn:focus-visible { outline: 2px solid currentColor; outline-offset: 3px; }
```

`:active` mais curto que `:hover` — o clique precisa parecer instantâneo.
Nunca remova o `:focus-visible`: quem navega por teclado depende dele.

## Tilt 3D no ponteiro

```css
.tilt-palco { perspective: 900px; }
.tilt {
  transition: transform var(--dur-base) var(--ease-out);
  transform: rotateX(var(--rx, 0deg)) rotateY(var(--ry, 0deg));
  will-change: transform;
}
```

```js
const palco = document.querySelector('.tilt-palco');
const alvo  = palco.querySelector('.tilt');
const MAX = 10;

palco.addEventListener('pointermove', (e) => {
  const r = palco.getBoundingClientRect();
  const px = (e.clientX - r.left) / r.width  - 0.5;
  const py = (e.clientY - r.top)  / r.height - 0.5;
  alvo.style.setProperty('--ry', `${px *  MAX * 2}deg`);
  alvo.style.setProperty('--rx', `${py * -MAX * 2}deg`);
});
palco.addEventListener('pointerleave', () => {
  alvo.style.setProperty('--rx', '0deg');
  alvo.style.setProperty('--ry', '0deg');
});
```

Só em ponteiro fino — em touch não faz sentido e atrapalha o scroll:

```js
if (window.matchMedia('(pointer: fine)').matches) { /* liga o tilt */ }
```

## Marquee infinito

```css
.marquee { overflow: hidden; display: flex; gap: 3rem; }
.marquee > * { flex: 0 0 auto; animation: correr 28s linear infinite; }
@keyframes correr { to { transform: translateX(-100%); } }
.marquee:hover > * { animation-play-state: paused; }
```

Duplique o conteúdo no HTML (duas cópias idênticas) — sem isso aparece um vão
quando a primeira sai da tela.

## Sheen — brilho passando

```css
.sheen { position: relative; overflow: hidden; }
.sheen::after {
  content: '';
  position: absolute; inset: 0;
  background: linear-gradient(105deg, transparent 40%, rgb(255 255 255 / 0.35) 50%, transparent 60%);
  transform: translateX(-100%);
  transition: transform 700ms var(--ease-in-out);
}
.sheen:hover::after { transform: translateX(100%); }
```

## Contador

```js
function contar(el, ate, ms = 1400) {
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) { el.textContent = ate; return; }
  const t0 = performance.now();
  const passo = (t) => {
    const p = Math.min((t - t0) / ms, 1);
    const eased = 1 - Math.pow(1 - p, 3);          // ease-out cubic
    el.textContent = Math.round(ate * eased).toLocaleString('pt-BR');
    if (p < 1) requestAnimationFrame(passo);
  };
  requestAnimationFrame(passo);
}
```

Reserve a largura antes de animar (`min-width` ou `font-variant-numeric: tabular-nums`)
ou o layout treme a cada dígito.

## Skeleton

```css
.skeleton {
  background: linear-gradient(90deg, #eee 25%, #f5f5f5 37%, #eee 63%);
  background-size: 400% 100%;
  animation: skeleton 1.4s ease infinite;
}
@keyframes skeleton { from { background-position: 100% 50%; } to { background-position: 0 50%; } }
```

O skeleton precisa ter o **tamanho do conteúdo real**. Se mudar de tamanho quando
o conteúdo chega, você trocou espera por salto de layout — piorou.

## Accordion com altura automática

`height: auto` não é animável. Use grid:

```css
.painel { display: grid; grid-template-rows: 0fr; transition: grid-template-rows var(--dur-base) var(--ease-in-out); }
.painel[data-aberto] { grid-template-rows: 1fr; }
.painel > div { overflow: hidden; }
```

## Transição de página

```js
if (document.startViewTransition && !matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.startViewTransition(() => renderizar(rota));
} else {
  renderizar(rota);
}
```

```css
::view-transition-old(root) { animation: 140ms var(--ease-in-out) both sair; }
::view-transition-new(root) { animation: 240ms var(--ease-out)    both entrar; }
@keyframes sair   { to   { opacity: 0; } }
@keyframes entrar { from { opacity: 0; transform: translateY(8px); } }
```
