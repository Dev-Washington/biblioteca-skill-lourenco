---
name: web-motion
description: Animação e motion design para web — transições CSS, keyframes, Web Animations API, GSAP/ScrollTrigger, Motion (Framer Motion), scroll-driven animations, View Transitions, animação de imagem de produto e microinterações. Use ao construir landing page, site, hero section, reveal on scroll, parallax, hover, carrossel, loader, transição de página, ou ao animar uma imagem de produto anexada. Também para diagnosticar animação travada, jank, ou queda de performance causada por animação.
allowed-tools: Read, Write, Edit, Glob, Grep, Bash
---

# Web Motion

Animação na web tem uma regra que decide quase tudo: **o navegador anima
`transform` e `opacity` de graça; qualquer outra propriedade custa caro.** Comece
por aí e a maior parte dos problemas de performance nunca acontece.

Esta skill existe porque o catálogo do aitmpl.com **não tem** uma skill de
animação web. `scroll-experience` e `3d-web-experience` cobrem cenários
específicos e citam GSAP de passagem; `frontend-design` não menciona animação.
Nenhuma delas trata `prefers-reduced-motion`. Este arquivo preenche essa lacuna.

---

## 1. Antes de animar, pergunte para quê

Toda animação precisa de uma função. Se você não consegue dizer qual, não anime.
As quatro funções legítimas:

| Função | Exemplo | Duração típica |
|---|---|---|
| **Feedback** — confirmar que a ação registrou | botão afunda no clique, campo treme no erro | 100–200 ms |
| **Orientação** — mostrar de onde veio / para onde foi | modal cresce do botão, item entra na lista | 200–400 ms |
| **Continuidade** — manter contexto entre estados | transição de página, item de grid vira detalhe | 300–600 ms |
| **Atenção** — dirigir o olho para o que importa | reveal do headline, número contando | 400–800 ms |

"Ficar bonito" não está na lista. Movimento sem função é ruído — e em landing
page, ruído custa conversão.

**Regra de duração:** quanto maior o elemento, mais lenta a animação. Um ícone a
150 ms parece responsivo; um modal a 150 ms parece um susto.

---

## 2. Escolha da técnica

Sempre a opção mais simples que resolve. Subir de nível só quando a anterior não dá conta.

```
Estado A → estado B, disparado por hover/focus/classe?
  └─ CSS transition                          ← comece aqui, 80% dos casos

Loop contínuo sem interação? (pulse, marquee, spinner)
  └─ CSS @keyframes

Precisa controlar/pausar/reverter via JS, sem lib?
  └─ Web Animations API (element.animate)

Sequência complexa, timeline, ou scroll-driven com controle fino?
  └─ GSAP + ScrollTrigger

React, e o elemento entra/sai da árvore? (mount/unmount, lista, modal)
  └─ Motion (framer-motion) — resolve exit animation, que CSS não resolve

Reveal simples ao entrar na viewport?
  └─ IntersectionObserver + classe CSS      ← não instale lib para isso

3D, produto rotacionável, cena com luz e material?
  └─ Three.js / React Three Fiber           → skill 3d-web-experience

Animação vetorial complexa feita por designer?
  └─ Lottie (dotLottie player)

Transição entre páginas/rotas?
  └─ View Transitions API
```

Detalhes de cada uma, com código: `referencias/escolha-tecnica.md`.

**Não instale GSAP para fazer um fade-in.** A biblioteca inteira custa mais que a
animação vale. Peso importa em landing page — é a primeira coisa que o usuário baixa.

---

## 3. As três regras que não se negociam

### 3.1 Anime só `transform` e `opacity`

Essas duas o compositor resolve na GPU, sem recalcular layout nem repintar.
Qualquer outra propriedade força o navegador a refazer trabalho a cada frame.

| Em vez de | Use |
|---|---|
| `left`, `top`, `margin` | `transform: translate()` |
| `width`, `height` | `transform: scale()` |
| `visibility` + `display` | `opacity` + `pointer-events` |

`filter` e `backdrop-filter` são acelerados na maioria dos navegadores, mas caros
em área grande — meça antes de usar em tela cheia.

### 3.2 Respeite `prefers-reduced-motion`

Não é opcional. Para quem tem distúrbio vestibular, parallax e movimento amplo
causam náusea real. É também requisito WCAG 2.3.3.

```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

Esse bloco é o piso, não o teto. **Reduzir não é desligar.** O ideal é substituir
movimento por fade: o usuário ainda percebe a mudança de estado, sem deslocamento.
Ver `referencias/acessibilidade.md`.

### 3.3 Nunca anime a partir de `opacity: 0` sem fallback

Se o JS falhar, não carregar, ou o IntersectionObserver não disparar, o conteúdo
fica **invisível para sempre**. Já derrubou landing page inteira em produção.

Faça o estado inicial depender de JS ter rodado:

```css
/* sem JS: tudo visível — o padrão seguro */
.reveal { opacity: 1; }

/* com JS: esconde e deixa o observer revelar */
.js-ready .reveal { opacity: 0; transform: translateY(16px); }
.js-ready .reveal.is-visible { opacity: 1; transform: none; }
```

```js
document.documentElement.classList.add('js-ready');
```

---

## 4. Valores que separam amador de profissional

O que faz uma animação parecer cara não é a complexidade — é o easing e o timing.

**Easing.** `ease` e `linear` denunciam o padrão do navegador. Use curvas com intenção:

```css
--ease-out:   cubic-bezier(0.16, 1, 0.32, 1);    /* entrada: rápido e assenta */
--ease-in-out: cubic-bezier(0.65, 0, 0.35, 1);   /* movimento entre dois pontos */
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);/* passa do ponto e volta */
```

- Elemento **entrando** → `ease-out`. Chega rápido, desacelera.
- Elemento **saindo** → `ease-in`, e mais curto que a entrada. Saída não merece espera.
- Movimento **contínuo** → `linear` é correto (marquee, spinner).

**Stagger.** Vários elementos entrando juntos parecem um bloco. Escalone 40–80 ms
entre eles e o olho lê a sequência. Mais que 100 ms começa a arrastar.

**Distância.** Reveal de 16–24 px parece intencional. 100 px parece que a página
está quebrada.

Receitas prontas — reveal, stagger, hover, marquee, contador, loader, transição de
página: `referencias/receitas.md`.

---

## 5. Animar imagem de produto

Cenário: o usuário anexou a imagem de um produto e quer o produto animado no site.

**Primeiro, olhe a imagem de verdade** com a ferramenta Read antes de decidir. O
que determina a técnica: tem fundo removido? é uma foto ou um render? o produto é
frontal ou tem perspectiva? há mais de um ângulo?

| O que você tem | O que dá para fazer |
|---|---|
| Uma foto, fundo removido (PNG) | Tilt 3D no ponteiro, float idle, sheen, reveal com `clip-path` |
| Uma foto, com fundo | Ken Burns (zoom/pan lento), ou remova o fundo antes — skill `imagegen` |
| Várias fotos do mesmo produto em ângulos | Spin 360 controlado por drag ou scroll |
| Camadas separadas (produto, sombra, fundo) | Parallax real entre camadas — o efeito mais convincente |
| Modelo 3D (.glb) | Three.js / R3F — skill `3d-web-experience` |

Workflow completo, com código para cada caso: `referencias/produto-imagem.md`.

**Peso da imagem importa mais que a animação.** Um PNG de 4 MB animado com 60 fps
ainda é uma landing page ruim. Converta para AVIF/WebP, sirva `srcset`, e use
`fetchpriority="high"` no hero. Ver `referencias/performance.md`.

---

## 6. Verifique a animação rodando — não entregue no escuro

Animação é a coisa mais fácil de errar sem perceber e a mais fácil de conferir.
Se o MCP `chrome-devtools` ou `playwright` estiver disponível, **use**:

1. Suba o dev server.
2. Abra a página, tire screenshot, role a página, tire de novo.
3. Confirme que o reveal disparou, que nada ficou invisível, que não há scroll horizontal.
4. Com `chrome-devtools`, grave um performance trace e confirme que não há long
   task nem layout thrash durante a animação.

Se **não** houver MCP de browser disponível, diga isso ao usuário em vez de
afirmar que está funcionando. "Implementei, não consegui verificar visualmente" é
uma resposta honesta; "ficou ótimo" sem ter visto não é.

**Teste obrigatório antes de considerar pronto:**

- [ ] Roda a 60 fps num throttle de 4× no DevTools
- [ ] `prefers-reduced-motion: reduce` ativado — a página continua usável e legível
- [ ] JS desabilitado — o conteúdo aparece
- [ ] Sem scroll horizontal em 360 px de largura
- [ ] Nada anima antes da fonte carregar (evita salto de layout)

---

## 7. Diagnóstico — animação travando

| Sintoma | Causa provável | Correção |
|---|---|---|
| Trava só no primeiro disparo | Imagem/fonte carregando junto | Pré-carregue; anime depois do `load` |
| Trava sempre, em tudo | Animando `width`/`top`/`margin` | Troque por `transform` |
| Trava só no scroll | Handler de `scroll` sem throttle | `IntersectionObserver`, ou `requestAnimationFrame` |
| Trava só no mobile | Sombra/blur grande em área grande | Reduza raio, ou pré-renderize |
| Pisca no fim da animação | Mudança de camada de composição | `will-change` durante, remova depois |
| Fica lento com o tempo | `will-change` permanente em muitos nós | `will-change` é temporário, não decoração |

`will-change` é uma promessa cara ao navegador. Aplique antes de animar, remova
ao terminar. Deixar em CSS estático em dezenas de elementos consome memória de GPU
e piora o que tentava melhorar.

Método e ferramentas de medição: `referencias/performance.md`.

---

## 8. Suporte de navegador

Verifique antes de usar como base — estas datas mudam:

| Recurso | Situação |
|---|---|
| CSS transitions / keyframes / WAAPI | Universal |
| `IntersectionObserver` | Universal |
| `prefers-reduced-motion` | Universal |
| View Transitions (mesma página) | Chrome/Edge e Safari recentes; Firefox atrás |
| View Transitions entre documentos | Só Chromium recente |
| Scroll-driven (`animation-timeline`) | Chromium e Safari recentes; Firefox atrás de flag |

As duas últimas linhas são **progressive enhancement**: envolva em
`@supports (animation-timeline: view())` ou `if (document.startViewTransition)`, e
garanta que a página funciona sem elas. Nunca as use como fundação.

Quando precisar do estado atual de suporte ou da API de uma versão específica de
GSAP/Motion, use o MCP `context7` — ele puxa a documentação da fonte, em vez de
você trabalhar de memória.

---

## Referências

- `referencias/escolha-tecnica.md` — cada técnica com código e quando usar
- `referencias/receitas.md` — padrões prontos para copiar
- `referencias/produto-imagem.md` — animar imagem de produto anexada
- `referencias/performance.md` — medir, otimizar, imagens
- `referencias/acessibilidade.md` — reduced motion feito direito
