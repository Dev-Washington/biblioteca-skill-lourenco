# Kit DevWeb + Motion — sites e landing pages com animação

Este projeto tem **31 skills, 4 agents e 4 MCPs** instalados em `.claude/`, para
construir sites e landing pages com animação.

30 skills vêm do [aitmpl.com](https://aitmpl.com/). A skill **`web-motion` foi
escrita para este kit** porque o catálogo não tem nenhuma skill de animação web.

---

## Regra central

**`web-motion` é a skill de referência para qualquer animação.** As skills de
design do catálogo (`frontend-design`, `premium-web-design`, `scroll-experience`)
dão repertório visual e enquadramento, mas são rasas em mecânica de animação e
**nenhuma delas trata `prefers-reduced-motion`**.

Sempre que a tarefa envolver movimento — reveal, hover, parallax, scroll, transição,
loader, animação de produto — consulte `web-motion` **antes** de escrever código.

As três regras que ela impõe e que você não deve quebrar:

1. **Anime só `transform` e `opacity`.** Qualquer outra propriedade força layout ou
   paint a cada frame.
2. **`prefers-reduced-motion` sempre.** Não é opcional — é WCAG e é saúde.
   Reduzir significa trocar movimento por fade, não desligar o feedback.
3. **Nunca deixe conteúdo dependendo de JS para ficar visível.** Se o observer não
   disparar, o texto some para sempre. O estado padrão é visível.

---

## Roteamento — qual usar para quê

### Animação e movimento
| Assunto da tarefa | Use |
|---|---|
| Qualquer animação: escolher técnica, easing, duração, performance | skill `web-motion` |
| Receitas prontas: reveal, stagger, hover, marquee, contador, accordion | `web-motion/referencias/receitas.md` |
| **Animar imagem de produto anexada** | `web-motion/referencias/produto-imagem.md` |
| Animação travando, jank, queda de fps | `web-motion/referencias/performance.md` |
| Reduced motion, foco, leitor de tela | `web-motion/referencias/acessibilidade.md` |
| Parallax narrativo, scroll cinemático, storytelling | skill `scroll-experience` + `web-motion` |
| 3D, produto rotacionável, WebGL, configurador | skill `3d-web-experience` |
| Arte generativa, partículas, p5.js | skill `algorithmic-art` |
| Visualização de dados animada | skill `claude-d3js-skill` |
| GIF animado | skill `slack-gif-creator` |

### Construir a página
| Assunto da tarefa | Use |
|---|---|
| Interface production-grade, componentes, páginas | skill `frontend-design` |
| **Landing page que precisa parecer cara / nível Awwwards** | skill `premium-web-design` |
| Estilos, paletas, pares de fontes, escolha visual | skill `ui-ux-pro-max` |
| Design tokens, componentes, handoff | skill `ui-design-system`, skill `tailwind-design-system` |
| Tema pronto para landing HTML | skill `theme-factory` |
| Tailwind v4, container queries | skill `tailwind-patterns` |
| Componentes shadcn/ui | skill `shadcn` |
| Next.js App Router, Server Components | skill `nextjs-app-router-patterns` |
| Site de conteúdo, zero JS por padrão | skill `astro` |
| Portfólio | skill `interactive-portfolio` |
| Construir feature completa, front-end multi-framework | agent `frontend-developer` |
| Design system, biblioteca de componentes | agent `ui-designer` |

### Conteúdo e conversão
| Assunto da tarefa | Use |
|---|---|
| Copy de homepage, landing, pricing | skill `copywriting` |
| Aumentar conversão da página | skill `page-cro` |
| Imagem, arte, poster, PNG/PDF | skill `canvas-design` |
| Gerar/editar imagem, **remover fundo** (precisa chave OpenAI) | skill `imagegen` |

### Qualidade
| Assunto da tarefa | Use |
|---|---|
| Core Web Vitals, LCP, bundle, cache | skill `web-performance-optimization` |
| Performance de React, re-render, waterfall | skill `react-best-practices` |
| Review de UI contra Web Interface Guidelines | skill `web-design-guidelines` |
| WCAG, ARIA, design inclusivo | skill `accessibility-auditor`, agent `web-accessibility-checker` |
| Review de UI/UX, usabilidade | agent `ui-ux-designer` |
| Lighthouse/PageSpeed com correção | skill `roier-seo` |

### Figma e vídeo
| Assunto da tarefa | Use |
|---|---|
| Buscar design, assets e variáveis do Figma | skill `figma` |
| Traduzir nó do Figma em código 1:1 | skill `figma-implement-design` |
| Entregável é **vídeo**, não página | skills `remotion`, `remotion-best-practices`, `motion-canvas` |

---

## Verifique a animação — não entregue no escuro

`.mcp.json` traz **chrome-devtools** e **playwright** ativos. Anime, suba o dev
server, abra, tire screenshot, role, tire de novo. Com `chrome-devtools`, grave um
performance trace e confirme os 60 fps.

Se nenhum MCP de browser estiver disponível, **diga isso** em vez de afirmar que
funcionou. "Implementei, não consegui verificar visualmente" é honesto. "Ficou
ótimo" sem ter visto, não.

Antes de considerar pronto:

- [ ] 60 fps com CPU em throttle 4×
- [ ] `prefers-reduced-motion: reduce` — página continua usável
- [ ] Sem JS — o conteúdo aparece
- [ ] Sem scroll horizontal em 360 px
- [ ] Nada anima antes da fonte carregar

---

## Quando o usuário anexar imagem de produto

1. **Leia a imagem** com a ferramenta Read antes de decidir. Fundo removido ou não?
   Foto ou render? Quantos ângulos?
2. **Pergunte que sensação o produto deve passar** — leveza, solidez, precisão,
   luxo. Isso muda mais o resultado que a escolha da técnica.
3. Siga `web-motion/referencias/produto-imagem.md` — há um caso mapeado para cada
   situação (PNG recortado, foto com fundo, camadas, múltiplos ângulos, .glb).
4. **Otimize a imagem antes de animar.** Um PNG de 4 MB animado a 60 fps continua
   sendo uma landing page ruim.

---

## Lacunas conhecidas — não invente que existe

- **Não há skill de GSAP, Framer Motion ou Lottie no catálogo.** O que existe está
  em `web-motion`, escrita para este kit. Não diga que veio do aitmpl.com.
- `premium-web-design` **gera React (.jsx)**. Se o projeto é HTML puro ou Astro,
  avise que vai precisar de tradução.
- `imagegen` exige chave paga da OpenAI. Sem chave, não funciona — não prometa
  remoção de fundo sem confirmar que a chave existe.
- Suporte de View Transitions e scroll-driven CSS ainda é parcial. Use como
  progressive enhancement, nunca como fundação.

## Convenções

- Declare qual skill está usando antes de aplicar a recomendação.
- Toda animação precisa de função: feedback, orientação, continuidade ou atenção.
  Se não dá para nomear a função, não anime.
- Não instale GSAP para fazer fade-in. Peso é a primeira coisa que o usuário baixa.
- Não instale novos componentes do aitmpl.com sem o usuário pedir.
