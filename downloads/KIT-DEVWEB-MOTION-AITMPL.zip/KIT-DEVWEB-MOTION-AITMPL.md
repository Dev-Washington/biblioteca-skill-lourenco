# Kit de Sites e Landing Pages com Animação — aitmpl.com

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) (arquivo `components.json`, que alimenta o site).
> Repositório de origem: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)
> Data da análise: 26/08/2026

---

## 1. O achado principal: o catálogo não tem skill de animação

Antes de qualquer recomendação, o resultado mais importante da busca.

Varri as 872 skills, 422 agents e 286 commands por `anim`, `motion`, `gsap`,
`framer`, `lottie`, `transition`, `keyframe`, `easing`, `tween`, `spring`,
`parallax`, `rive`, `spline`, `particle`. Nenhum componente do catálogo tem
animação web como tema. Os que chegam perto:

| Componente | Tamanho | Menciona |
|---|---|---|
| `creative-design/frontend-design` (12.382 downloads) | 20 KB | **nada** de animação |
| `creative-design/premium-web-design` (206) | 60 KB | `@keyframes` em 1 arquivo |
| `creative-design/scroll-experience` (468) | 8 KB | GSAP, Framer Motion, ScrollTrigger — 1 vez cada |
| `creative-design/3d-web-experience` (971) | 8 KB | GSAP, ScrollTrigger — 1 vez cada |

E o mais grave: **nenhum componente do catálogo menciona `prefers-reduced-motion`.**
Isso é requisito WCAG e questão de saúde — parallax causa náusea real em quem tem
distúrbio vestibular.

Conclusão: as skills de animação "de verdade" do catálogo são de **vídeo
programático** (Remotion, Motion Canvas, Manim), não de animação em página web.

**Por isso este kit inclui uma skill escrita do zero — `web-motion` — que não vem
do aitmpl.com.** Ela cobre a lacuna: escolha de técnica, CSS/WAAPI/GSAP/Motion,
scroll-driven, View Transitions, performance de compositor, `prefers-reduced-motion`
e o fluxo de animar imagem de produto anexada. São 6 arquivos, 56 KB.

---

## 2. O que existe no catálogo

| Tipo | Total | Candidatos com termo de animação/design | Selecionados |
|---|---|---|---|
| Skills | 872 | 75 | 30 (+1 própria) |
| Agents | 422 | 83 | 4 |
| MCPs | 101 | 4 relevantes | 4 |
| Commands | 286 | 8 (nenhum útil aqui) | 0 |

A categoria `creative-design` (33 skills) concentra quase tudo que interessa.
`web-development` (30 skills) traz o stack.

---

## 3. Kit essencial — instale estes primeiro

| Componente | Tipo | Por quê | Downloads |
|---|---|---|---|
| `creative-design/frontend-design` | skill | **A skill mais baixada do catálogo inteiro.** Interfaces de alta qualidade, production-grade | 12.382 |
| `development-team/frontend-developer` | agent | Agent mais baixado do catálogo. React, Vue, Angular | 10.867 |
| `development-team/ui-ux-designer` | agent | Review de UI/UX, auditoria de usabilidade e acessibilidade | 7.029 |
| `creative-design/ui-ux-pro-max` | skill | 50 estilos, 21 paletas, 50 pares de fontes, 9 stacks | 6.790 |
| `creative-design/ui-design-system` | skill | Design tokens, documentação de componente, handoff | 4.209 |
| `web-development/react-best-practices` | skill | 40+ regras de performance React/Next. Animação em React vive ou morre por aqui | 3.272 |
| **`web-motion`** | skill | **Escrita para este kit.** Cobre a lacuna de animação do catálogo | — |

```bash
npx claude-code-templates@latest --skill creative-design/frontend-design --yes
npx claude-code-templates@latest --agent development-team/frontend-developer --yes
npx claude-code-templates@latest --agent development-team/ui-ux-designer --yes
npx claude-code-templates@latest --skill creative-design/ui-ux-pro-max --yes
npx claude-code-templates@latest --skill creative-design/ui-design-system --yes
npx claude-code-templates@latest --skill web-development/react-best-practices --yes
# web-motion não está no catálogo — já vem instalada neste kit
```

---

## 4. Landing page de alto padrão

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `creative-design/premium-web-design` | skill | Landing page nível Awwwards, em React. Dispara com "faça parecer caro", "qualidade de agência", ou referência a Apple, Aesop, Stripe. **60 KB de conteúdo** — a mais densa do kit | 206 |
| `creative-design/theme-factory` | skill | 10 temas prontos (cores/fontes) para landing page HTML | 957 |
| `business-marketing/copywriting` | skill | Copy de homepage, landing, pricing, feature pages | 923 |
| `creative-design/tailwind-patterns` | skill | Tailwind v4: config CSS-first, container queries, tokens | 656 |
| `creative-design/web-design-guidelines` | skill | Review de UI contra Web Interface Guidelines | 481 |
| `business-marketing/page-cro` | skill | Otimização de conversão da página | 97 |

`premium-web-design` é a descoberta mais subestimada do catálogo: 206 downloads,
mas 60 KB de conteúdo, e a descrição diz explicitamente que serve para quando o
usuário está **insatisfeito com a estética genérica de site gerado por IA**.

---

## 5. Animação e experiência — o que o catálogo oferece

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `creative-design/3d-web-experience` | skill | Three.js, React Three Fiber, Spline, WebGL. **Configurador de produto 3D** | 971 |
| `creative-design/scroll-experience` | skill | Parallax narrativo, scroll animations, experiência cinemática | 468 |
| `creative-design/algorithmic-art` | skill | Arte generativa com p5.js, aleatoriedade com seed | 358 |
| `creative-design/interactive-portfolio` | skill | Portfólio como experiência memorável | 135 |
| `creative-design/claude-d3js-skill` | skill | Visualização de dados interativa com d3.js | 113 |
| `creative-design/slack-gif-creator` | skill | GIF animado com validação de restrições | 71 |

Todas úteis, todas rasas em animação propriamente dita (ver seção 1). Use-as pelo
enquadramento e pelo repertório; a mecânica está em `web-motion`.

---

## 6. Vídeo programático — animar produto para vídeo

Se o entregável for **vídeo** (anúncio, reels, demo) em vez de página:

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `video/remotion` | skill | Vídeo programático em React: animação, composição, mídia | 226 |
| `creative-design/remotion-best-practices` | skill | Boas práticas de Remotion | 108 |
| `video/motion-canvas` | skill | Vídeo programático em TypeScript, com setup completo | 66 |

Existem também `video/sora` (44) e `video/manim` (28) — Sora gera vídeo por IA via
API da OpenAI, Manim é para animação matemática. Fora do escopo de site.

---

## 7. Imagem — o produto anexado

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `creative-design/canvas-design` | skill | Arte visual em .png e .pdf com filosofia de design | 2.626 |
| `creative-design/imagegen` | skill | OpenAI Image API: gerar, editar, inpaint, **remoção de fundo** | 78 |

`imagegen` é a peça que fecha o fluxo de produto: recorta o fundo da foto anexada,
e aí o produto vira PNG que aceita tilt 3D, float e parallax. O passo a passo está
em `web-motion/referencias/produto-imagem.md`.

Existe também `creative-design/luma-imagegen` (19), via API da Luma. Ambas exigem
chave de API paga.

---

## 8. Stack e qualidade

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `web-development/web-performance-optimization` | skill | Core Web Vitals, bundle, cache. **Animação é o que mais derruba LCP** | 806 |
| `creative-design/accessibility-auditor` | skill | WCAG, ARIA, design inclusivo | 187 |
| `web-tools/web-accessibility-checker` | agent | Auditoria WCAG automatizada | 350 |
| `development-team/ui-designer` | agent | Design system, biblioteca de componentes | 420 |
| `web-development/roier-seo` | skill | Lighthouse/PageSpeed em site ou dev server, com correção | 125 |
| `web-development/tailwind-design-system` | skill | Design system em Tailwind com tokens e variantes | 117 |
| `web-development/shadcn` | skill | Componentes shadcn/ui | 107 |
| `web-development/nextjs-app-router-patterns` | skill | Next.js 14+ App Router, Server Components | 79 |
| `web-development/astro` | skill | Site de conteúdo, zero JS por padrão, islands | 34 |

Astro merece nota: para landing page, "zero JS por padrão" significa que a animação
CSS entrega sem custo de bundle. É o oposto da armadilha de puxar React + Framer
Motion para animar um fade.

---

## 9. Figma

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `creative-design/figma` | skill | Busca contexto, screenshot, variáveis e assets do Figma | 186 |
| `creative-design/figma-implement-design` | skill | Traduz nó do Figma em código com fidelidade 1:1 | 165 |
| `devtools/figma-dev-mode` | MCP | Servidor MCP oficial do Dev Mode | 408 |

Exige o app desktop do Figma rodando localmente (porta 3845).

---

## 10. MCPs — ver a animação rodando

O ganho mais concreto do kit. Sem eles, a IA escreve animação e nunca vê o resultado.

| Componente | O que faz | Downloads |
|---|---|---|
| `devtools/context7` | Documentação atualizada da fonte — API atual de GSAP, Motion, Three.js. Resolve o problema de trabalhar de memória sobre libs que mudam | 3.936 |
| `browser_automation/playwright-mcp-server` | Abre a página, screenshot, executa JS | 1.752 |
| `devtools/chrome-devtools` | Automação + **performance trace**. Confirma 60 fps de verdade | 1.096 |
| `devtools/figma-dev-mode` | Design do Figma direto no fluxo | 408 |

`chrome-devtools` é o que permite dizer "está a 60 fps" com base em medição, e não
em suposição.

---

## 11. Sintaxe de instalação

```bash
npx claude-code-templates@latest --skill <categoria>/<nome> --yes
npx claude-code-templates@latest --agent <categoria>/<nome> --yes
npx claude-code-templates@latest --mcp   <categoria>/<nome> --yes
```

A CLI escreve em `.claude/` do diretório atual.

> A API do GitHub limita a 60 requisições/hora sem autenticação. Instalar 30 skills
> de uma vez estoura o limite e falha com HTTP 403. Este kit foi instalado clonando
> o repositório (`git clone --depth 1 --filter=blob:none --sparse`), que não passa
> pela API REST. Se você bater no limite, use `gh auth login` ou espere.

---

## 12. Ressalvas honestas

1. **Não existe skill de animação web no catálogo.** É a razão de `web-motion`
   existir. Ver seção 1. Se você esperava GSAP ou Framer Motion prontos do
   aitmpl.com, não estão lá.

2. **Nenhum componente do catálogo trata `prefers-reduced-motion`.** Isso é
   requisito WCAG 2.3.3 e questão de saúde. `web-motion` cobre.

3. **`premium-web-design` gera React (.jsx).** Se seu projeto é HTML puro ou Astro,
   você vai precisar traduzir. A skill não avisa isso.

4. **`imagegen` e `luma-imagegen` exigem chave de API paga** (OpenAI / Luma). Sem
   chave, não funcionam. Para remoção de fundo pontual, recorte manual ou uma
   ferramenta dedicada sai mais barato.

5. **Popularidade desigual.** `astro` (34 downloads), `slack-gif-creator` (71),
   `imagegen` (78), `nextjs-app-router-patterns` (79) e `page-cro` (97) são pouco
   usados — provavelmente pouco testados. Já `frontend-design` (12.382),
   `frontend-developer` (10.867) e `ui-ux-designer` (7.029) são os mais baixados
   do catálogo inteiro.

6. **Duplicatas.** `remotion` existe em `video/` e `remotion-best-practices` em
   `creative-design/` — são componentes diferentes, ambos instalados.
   `accessibility-auditor` (skill) e `web-accessibility-checker` (agent) se
   sobrepõem. Sempre instale com `categoria/nome`.

7. **Animação bonita não é animação boa.** O kit dá repertório visual; ele não
   substitui medir. Se o LCP passa de 2,5 s ou o scroll trava no celular, a
   animação está errada por definição, por mais bonita que esteja no seu monitor.

---

## 13. Resumo — o que instalar agora

```bash
# Essencial
npx claude-code-templates@latest --skill creative-design/frontend-design --yes
npx claude-code-templates@latest --skill creative-design/ui-ux-pro-max --yes
npx claude-code-templates@latest --skill creative-design/ui-design-system --yes
npx claude-code-templates@latest --skill creative-design/premium-web-design --yes
npx claude-code-templates@latest --agent development-team/frontend-developer --yes
npx claude-code-templates@latest --agent development-team/ui-ux-designer --yes

# Animação e experiência
npx claude-code-templates@latest --skill creative-design/scroll-experience --yes
npx claude-code-templates@latest --skill creative-design/3d-web-experience --yes
npx claude-code-templates@latest --skill creative-design/algorithmic-art --yes
npx claude-code-templates@latest --skill creative-design/interactive-portfolio --yes

# Landing page
npx claude-code-templates@latest --skill creative-design/theme-factory --yes
npx claude-code-templates@latest --skill creative-design/tailwind-patterns --yes
npx claude-code-templates@latest --skill business-marketing/copywriting --yes
npx claude-code-templates@latest --skill business-marketing/page-cro --yes

# Imagem de produto
npx claude-code-templates@latest --skill creative-design/imagegen --yes
npx claude-code-templates@latest --skill creative-design/canvas-design --yes

# Stack e qualidade
npx claude-code-templates@latest --skill web-development/react-best-practices --yes
npx claude-code-templates@latest --skill web-development/web-performance-optimization --yes
npx claude-code-templates@latest --skill creative-design/web-design-guidelines --yes
npx claude-code-templates@latest --skill creative-design/accessibility-auditor --yes
npx claude-code-templates@latest --agent web-tools/web-accessibility-checker --yes

# MCPs — ver a animação rodando
npx claude-code-templates@latest --mcp devtools/chrome-devtools --yes
npx claude-code-templates@latest --mcp browser_automation/playwright-mcp-server --yes
npx claude-code-templates@latest --mcp devtools/context7 --yes
```

E a skill `web-motion`, que não existe no catálogo, já está em
`.claude/skills/web-motion/`.
