# Kit IA e Agentes — LLM, prompt, RAG e agentes autônomos

**12 skills, 7 agents e 2 MCPs** em `.claude/`, para **colocar IA dentro do
produto**: prompt, RAG, memória, agentes autônomos, avaliação de modelo.

Fonte: [aitmpl.com](https://aitmpl.com/).

Para criar skills, agents e MCPs **do Claude Code**, o kit é o `KIT-CLAUDE-CODE`.
São coisas diferentes — não confunda.

---

## Regra que vale mais que qualquer skill

**Conteúdo sobre LLM envelhece em meses.** Preço, limite de contexto, nome de
modelo, formato de API — tudo muda. Uma skill deste kit pode recomendar um modelo
que não existe mais.

Antes de afirmar qualquer coisa sobre modelo, preço, limite ou API:
- Para a Anthropic → `docs.claude.com`, ou a skill `claude-api` se estiver disponível
- Para outros provedores → documentação oficial deles
- Use o MCP `context7` para puxar a doc da versão em uso

**Nunca cite preço ou limite de memória.** Se não conseguir verificar, diga que
precisa confirmar. Número errado de preço vira decisão de arquitetura errada.

---

## Roteamento

### Prompt
| Assunto da tarefa | Use |
|---|---|
| Desenhar prompt para aplicação com LLM | agent `prompt-engineer` |
| Otimização, padrões, saída estruturada, produto com IA | skill `senior-prompt-engineer` |
| Técnicas e padrões de prompt | skills `prompt-engineering`, `prompt-engineer` |

### Construir agente
| Assunto da tarefa | Use |
|---|---|
| Arquitetar agente autônomo: ferramenta, memória, loop | skill `ai-agents-architect` |
| **Desenhar as ferramentas que o agente usa** | skill `agent-tool-builder` |
| Memória de agente: curto prazo, longo prazo, entidade | skills `agent-memory-systems`, `conversation-memory` |
| Arquitetura de sistema com LLM | agent `llm-architect` |
| Quebrar objetivo complexo em tarefas com dependência | agent `task-decomposition-expert` |
| Orquestrar vários agentes | skill `agents-crewai` |
| LangChain: agents, chains, RAG | skill `agents-langchain` |
| Gerenciar agentes CLI locais via tmux | skill `agent-manager-skill` |

### Busca e RAG
| Assunto da tarefa | Use |
|---|---|
| Busca web avançada, síntese multi-fonte, retrieval iterativo | agent `search-specialist` |
| Puxar documentação atualizada de biblioteca | skill `context7-auto-research`, MCP `context7` |
| Memória persistente entre sessões | MCP `memory` |

### Avaliação
| Assunto da tarefa | Use |
|---|---|
| Escolher modelo, desenhar benchmark | agent `model-evaluator` |
| Rigor científico em experimento | skill `research-engineer` |
| Ética, viés, uso responsável | agent `ai-ethics-advisor` |
| Manter `llms.txt` | agent `llms-maintainer` |

---

## Regras ao construir com LLM

**A ferramenta importa mais que o prompt.** Agente que alucina argumento quase
sempre tem ferramenta mal desenhada — nome ambíguo, parâmetro sem descrição,
retorno inconsistente. Antes de ajustar o prompt, revise as ferramentas: skill
`agent-tool-builder`.

**Meça antes de escolher modelo.** `model-evaluator` existe para isso. Escolher o
modelo maior "por garantia" multiplica o custo sem melhorar o resultado na maioria
das tarefas. Monte um benchmark com os seus dados.

**Memória não é opcional em agente conversacional.** Sem ela, toda interação começa
do zero. Mas memória mal desenhada enche o contexto com ruído — decida o que
guardar, por quanto tempo e como recuperar.

**RAG ruim é pior que nenhum RAG.** Recuperar trecho errado faz o modelo responder
com confiança sobre a coisa errada. Meça a qualidade da recuperação separadamente da
qualidade da resposta.

**Custo e latência são requisito, não detalhe.** Pergunte o orçamento por chamada e
o tempo aceitável **antes** de propor arquitetura. Isso decide entre um modelo e
outro, entre RAG e contexto longo, entre síncrono e fila.

## Convenções

- Declare qual skill/agent está usando.
- Não cite preço, limite de contexto ou nome de modelo sem verificar.
- Este é o domínio menos validado do catálogo (média de 34 downloads por skill em
  `ai-research`). Diga quando estiver seguindo uma skill pouco testada.
