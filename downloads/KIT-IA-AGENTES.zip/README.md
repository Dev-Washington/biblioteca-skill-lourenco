# Kit IA e Agentes — LLM, prompt, RAG e agentes autônomos

**12 skills, 7 agents, 2 commands e 2 MCPs** para colocar IA dentro do seu produto.

Origem: [aitmpl.com](https://aitmpl.com/) · **21 componentes, 19.291 downloads somados.**

---

## Este kit não é sobre usar IA para programar

É sobre **construir produto com IA dentro**: chatbot, busca semântica, agente com
ferramentas, classificador.

Para criar skills, agents e MCPs **do Claude Code**, o kit é o `KIT-CLAUDE-CODE`.
É a confusão mais comum, e o `CLAUDE.md` instrui a IA a esclarecer isso.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-ia`.

Ou instale num projeto existente:

```bash
./install.sh /caminho/do/seu/projeto
./check.sh
```

### Windows (PowerShell)

```powershell
.\install.ps1 C:\caminho\do\seu\projeto
```

Se o Windows bloquear a execução do script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Isso libera só a sessão atual — não altera a política da máquina.

### macOS e Linux

```bash
chmod +x install.sh check.sh    # só na primeira vez
./install.sh /caminho/do/seu/projeto
./check.sh
```

O `install.ps1` também roda no macOS e no Linux, se você tiver PowerShell 7+.

---

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-ia [assunto]` | Mostra o que tem e o que se aplica |
| `/desenhar-agente [descrição]` | Projeta agente: escopo → ferramentas → memória → loop → modelo → avaliação |

O `/desenhar-agente` faz quatro perguntas antes de qualquer código, e a quarta é a
que mais gente pula: **o que acontece quando o agente erra — quem percebe e como se
reverte.**

---

## O que está instalado

**Prompt** — `prompt-engineer` agent (4.497), `senior-prompt-engineer` (2.315),
`prompt-engineering` (166), `prompt-engineer` skill (162).

**Agentes** — `task-decomposition-expert` (1.947), `search-specialist` (1.851),
`ai-agents-architect` (263), `agent-memory-systems` (241), `llm-architect` (136),
`agent-manager-skill` (90), `agent-tool-builder` (81).

**Frameworks** — `agents-langchain` (224), `context7-auto-research` (185),
`conversation-memory` (88), `agents-crewai` (85).

**Avaliação** — `model-evaluator` (260), `llms-maintainer` (254),
`ai-ethics-advisor` (159), `research-engineer` (83).

Dois merecem destaque:

`agent-tool-builder` — "uma ferramenta bem desenhada é a diferença entre um agente
que funciona e um que alucina". É o problema real de quem constrói agente, e quase
ninguém trata. Antes de ajustar prompt, revise as ferramentas.

`model-evaluator` — escolher modelo por benchmark próprio, em vez de por marketing,
muda o custo do produto em ordem de grandeza.

Detalhe e justificativa: [KIT-IA-AGENTES.md](KIT-IA-AGENTES.md).

---

## MCPs

**Ativo:** `memory` (2.268) — memória persistente entre sessões, sem credencial.

**Opcional:** `context7` (3.936) — documentação atualizada por versão. Precisa de
chave de API. **Vale muito aqui**, pelo motivo da próxima seção.

---

## Limitações — a mais importante primeiro

1. **Conteúdo sobre LLM envelhece em meses.** Preço, limite de contexto, nome de
   modelo, formato de API — tudo muda. Uma skill deste kit pode recomendar um modelo
   que não existe mais. O `CLAUDE.md` instrui a IA a **nunca citar preço ou limite
   sem verificar** na documentação do provedor.

2. **`ai-research` é a categoria menos validada do catálogo.** 130 skills, média de
   **34 downloads cada**. Instalei 12 — as que passam de 80 downloads ou cobrem tema
   sem alternativa. Trate como ponto de partida.

3. **Nada aqui é específico da Anthropic.** As skills falam de LLM em geral,
   LangChain, CrewAI. Para a API da Anthropic, a fonte é `docs.claude.com`.

4. **Sobreposição de nomes.** `prompt-engineer` existe como agent (4.497) **e** como
   skill (162) — componentes diferentes, ambos instalados.

---

## Arquivos

```
KIT-IA-AGENTES/
├── CLAUDE.md            contexto automático: roteamento e a regra de verificação
├── README.md            este arquivo
├── KIT-IA-AGENTES.md    análise do catálogo
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/
    ├── skills/  12    ├── agents/  7    └── commands/  2
```
