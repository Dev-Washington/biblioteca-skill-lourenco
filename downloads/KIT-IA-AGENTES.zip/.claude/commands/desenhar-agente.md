---
description: Projeta um agente com LLM — ferramentas, memória, avaliação
---

Agente desejado: $ARGUMENTS

1. **Defina o escopo real.** Se $ARGUMENTS for vago, pergunte:
   - Que tarefa o agente executa, do início ao fim
   - O que ele pode fazer sozinho e o que exige aprovação humana
   - **Orçamento por execução e latência aceitável** — isso decide a arquitetura
   - O que acontece quando ele erra: quem percebe, e como se reverte

   A última pergunta é a que mais gente pula e a que mais causa estrago.

2. **Desenhe as ferramentas antes do prompt** — skill `agent-tool-builder`. Agente
   que alucina argumento quase sempre tem ferramenta mal desenhada: nome ambíguo,
   parâmetro sem descrição, retorno inconsistente. Para cada ferramenta:
   - nome que diz o que faz, sem ambiguidade com as outras
   - cada parâmetro com descrição e tipo
   - retorno previsível, incluindo o caso de erro
   - o que acontece se for chamada duas vezes com o mesmo argumento

3. **Decida a memória** — skills `agent-memory-systems`, `conversation-memory`.
   O que guardar, por quanto tempo, como recuperar. Memória mal desenhada enche o
   contexto de ruído e piora o resultado.

4. **Arquitete o loop** — skill `ai-agents-architect`, agent `llm-architect`.
   Quantos passos no máximo? O que faz o agente parar? Como você detecta que ele
   entrou em loop?

5. **Escolha o modelo medindo** — agent `model-evaluator`. Monte um benchmark com
   os dados reais do usuário. Não escolha o maior "por garantia" — multiplica o
   custo sem melhorar a maioria das tarefas.

6. **Confirme a API antes de escrever código.** Nome de modelo, formato de tool use
   e limites mudam. Verifique na documentação do provedor — para a Anthropic,
   `docs.claude.com`. Não escreva de memória.

7. **Defina como avaliar em produção**: o que é sucesso, como você mede, e o que
   dispara alerta.
