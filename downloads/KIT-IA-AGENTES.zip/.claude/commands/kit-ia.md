---
description: Mostra o que este kit tem e o que se aplica ao seu caso de IA
---

Leia `CLAUDE.md` na raiz e apresente, em português:

1. Verifique o que existe **de fato**: `ls .claude/skills` · `ls .claude/agents` ·
   `cat .mcp.json`. Não liste nada que não esteja lá.

2. Resuma agrupado: prompt, construir agente, busca/RAG, avaliação.

3. **Deixe claro a distinção**: este kit é para colocar IA dentro do produto do
   usuário. Para criar skills e MCPs do Claude Code, o kit é o `KIT-CLAUDE-CODE`.
   É a confusão mais comum.

4. Se o usuário passou um assunto ($ARGUMENTS), diga o que se aplica. Se não passou,
   pergunte o que ele quer construir — chatbot, busca semântica, agente com
   ferramentas, classificador — e qual o orçamento por chamada e a latência
   aceitável.

Seja direto.
