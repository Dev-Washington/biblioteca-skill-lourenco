# Kit IA e Agentes — LLM, prompt, RAG e agentes autônomos

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**21 componentes · 19.291 downloads somados.** Para colocar IA dentro do seu produto
— não para usar IA no desenvolvimento (isso são os outros kits).

---

## 1. O que a busca encontrou

A categoria `ai-research` tem **130 skills** e estava 100% descoberta pelos kits
anteriores. É a segunda maior do catálogo.

Mas o número engana. Somadas, as 130 skills têm **4.421 downloads** — média de 34
por skill. É a categoria com **maior volume e menor validação** do catálogo inteiro.
Por isso instalei 12, não 130: só as que passam de 80 downloads ou cobrem um tema
sem alternativa.

O peso real do kit vem de fora dessa categoria: `prompt-engineer` (agent, 4.497) e
`senior-prompt-engineer` (skill, 2.315) sozinhos somam 6.812 dos 19.291.

---

## 2. Componentes

### Prompt
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `ai-specialists/prompt-engineer` | agent | Design de prompt para aplicação com LLM | 4.497 |
| `development/senior-prompt-engineer` | skill | Otimização, padrões, saída estruturada, produto com IA | 2.315 |
| `ai-research/prompt-engineering` | skill | Padrões e técnicas de otimização | 166 |
| `ai-research/prompt-engineer` | skill | Estrutura de prompt para aplicação | 162 |

Quatro componentes de prompt com sobreposição clara. `prompt-engineer` existe como
agent (4.497) **e** como skill (162) — nomes iguais, componentes diferentes.

### Agentes
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `ai-specialists/task-decomposition-expert` | agent | Quebra objetivo complexo em WBS com dependência e paralelismo | 1.947 |
| `ai-specialists/search-specialist` | agent | Busca web avançada, síntese multi-fonte, retrieval iterativo | 1.851 |
| `ai-research/ai-agents-architect` | skill | Projetar agente autônomo: uso de ferramenta, memória | 263 |
| `ai-research/agent-memory-systems` | skill | Memória de agente — sem ela toda interação começa do zero | 241 |
| `ai-research/agent-tool-builder` | skill | Desenhar ferramenta que o agente usa sem alucinar | 81 |
| `ai-research/agent-manager-skill` | skill | Gerenciar agentes CLI locais via tmux | 90 |
| `ai-specialists/llm-architect` | agent | Arquitetura de sistema com LLM | 136 |

`agent-tool-builder` merece destaque: "uma ferramenta bem desenhada é a diferença
entre um agente que funciona e um que alucina". É o problema real de quem constrói
agente, e quase ninguém trata.

### Frameworks e memória
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `ai-research/agents-langchain` | skill | LangChain: agents, chains, RAG | 224 |
| `ai-research/agents-crewai` | skill | CrewAI: orquestração multi-agente | 85 |
| `ai-research/conversation-memory` | skill | Memória de conversa: curto prazo, longo prazo, entidade | 88 |
| `ai-research/context7-auto-research` | skill | Busca automática de doc atualizada via Context7 | 185 |

### Avaliação e ética
`ai-specialists/model-evaluator` (260) — escolher modelo e desenhar benchmark.
`ai-specialists/ai-ethics-advisor` (159). `ai-specialists/llms-maintainer` (254).
`ai-research/research-engineer` (83) — rigor científico em experimento.

`model-evaluator` é o mais subestimado: escolher modelo por benchmark próprio, em
vez de por marketing, muda o custo do produto em ordem de grandeza.

### MCPs
`integration/memory-integration` (2.268) — memória persistente entre sessões,
funciona sem credencial. `devtools/context7` (3.936) — doc atualizada por versão,
precisa de chave.

---

## 3. Ressalvas honestas

1. **Esta é a categoria menos validada do catálogo.** 130 skills, média de 34
   downloads. Instalei 12. Trate como ponto de partida, valide antes de levar a
   produção.

2. **Conteúdo sobre LLM envelhece rápido.** Preço, limite de contexto, nome de
   modelo, API — tudo muda em meses. Uma skill escrita há um ano pode recomendar
   modelo que não existe mais. **Confirme na documentação do provedor**, sempre.

3. **Nada aqui é específico da Anthropic.** As skills falam de LLM em geral,
   LangChain, CrewAI. Para a API da Anthropic — modelos, preço, cache, tool use — a
   fonte é `docs.claude.com`.

4. **Sobreposição de nomes.** `prompt-engineer` é agent (4.497) e skill (162);
   `data-scientist` e `research-engineer` também aparecem em mais de uma categoria.
   Use o caminho completo `categoria/nome`.

5. **Construir agente é diferente de usar agente.** Este kit é para quem coloca IA
   dentro do produto. Para criar skills e MCPs do Claude Code, o kit é o
   `KIT-CLAUDE-CODE`.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --agent ai-specialists/prompt-engineer --yes
npx claude-code-templates@latest --skill development/senior-prompt-engineer --yes
npx claude-code-templates@latest --agent ai-specialists/task-decomposition-expert --yes
npx claude-code-templates@latest --agent ai-specialists/search-specialist --yes
npx claude-code-templates@latest --skill ai-research/ai-agents-architect --yes
npx claude-code-templates@latest --skill ai-research/agent-memory-systems --yes
npx claude-code-templates@latest --mcp integration/memory-integration --yes
```
