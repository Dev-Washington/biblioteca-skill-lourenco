# Kit Marketing — SEO, conteúdo e aquisição

**13 skills, 9 agents, 3 commands e 2 MCPs** para SEO, conteúdo, estratégia e
aquisição.

Origem: [aitmpl.com](https://aitmpl.com/) · **24 componentes, 12.698 downloads somados.**

---

## O recorte

O `KIT-DEVWEB-MOTION-AITMPL` já cobre o texto e a conversão de uma página
específica (`copywriting`, `page-cro`). Este kit cobre **como as pessoas chegam
naquela página**: SEO, conteúdo, campanha, concorrência, lead.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-marketing`.

Ou instale num projeto existente:

```bash
./install.sh /caminho/do/seu/projeto
./check.sh
```

---

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-marketing [assunto]` | Mostra o que tem e o que se aplica ao objetivo |
| `/conteudo [pedido]` | Peça de conteúdo: público → pesquisa → estrutura → SEO → rascunho |
| `/auditar-seo [url]` | Auditoria priorizada por impacto × esforço, com nível de confiança |

O `/conteudo` tem uma etapa de revisão contra os **vícios de texto de IA** — abertura
genérica, tricolon em toda frase, "não apenas X, mas Y", conclusão que repete a
introdução. É o que separa rascunho utilizável de texto que qualquer leitor
identifica como gerado.

---

## O que está instalado

**SEO** — `seo-optimizer` (2.686), `seo-analyzer` (930), `seo-specialist` (404),
`seo-audit` (401), `programmatic-seo` (157),
`search-ai-optimization-expert` (143), `competitor-alternatives` (98).

**Conteúdo** — `content-marketer` (1.013), `content-creator` (998),
`content-research-writer` (605), `social-content` (432),
`executing-marketing-campaigns` (307).

**Estratégia** — `marketing-strategy-pmm` (472), `marketing-psychology` (427),
`lead-research-assistant` (403), `marketing-ideas` (364),
`competitive-ads-extractor` (305), `market-researcher` (179),
`competitive-analyst` (167), `trend-analyst` (166).

**Aquisição** — `sales-automator` (336), `customer-support` (236).

`competitive-ads-extractor` é o mais concreto do grupo: puxa os anúncios que seu
concorrente roda no Facebook e LinkedIn e analisa o ângulo.

Detalhe e justificativa: [KIT-MARKETING.md](KIT-MARKETING.md).

---

## MCPs

**Ativo:** `fetch` (1.308) — busca conteúdo web, sem credencial.

**Opcional:** `firecrawl` (161) — scraping profundo, screenshot, crawling. Precisa
de chave de API.

---

## Limitações — leia antes de publicar

1. **Marketing é onde texto de IA mais se parece com texto de IA.** As skills
   melhoram estrutura e ângulo; não substituem sua voz. Trate a saída como rascunho.

2. **Verifique a lei antes de disparar.** `sales-automator` escreve e-mail frio em
   massa; `lead-research-assistant` coleta dado de pessoa. LGPD, CAN-SPAM e GDPR se
   aplicam — **base comprada é ilegal no Brasil.** O `KIT-SECURITY-SISTEM-AITMPL`
   tem as skills de privacidade.

3. **`programmatic-seo` é faca de dois gumes.** Gerar centenas de páginas por
   template é exatamente o que o Google penaliza quando não há valor real em cada
   uma. Só com dado próprio que justifique a página.

4. **Nenhuma skill de SEO sabe o último update do Google.** Elas ensinam princípios
   que envelhecem devagar. Para algoritmo, use fonte primária.

5. **`competitive-ads-extractor` raspa plataformas de terceiros.** Confira os termos
   de uso antes.

---

## Arquivos

```
KIT-MARKETING/
├── CLAUDE.md          contexto automático: roteamento e regras
├── README.md          este arquivo
├── KIT-MARKETING.md   análise do catálogo
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/
    ├── skills/  13    ├── agents/  9    └── commands/  3
```
