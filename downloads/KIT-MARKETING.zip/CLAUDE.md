# Kit Marketing — SEO, conteúdo e aquisição

**13 skills, 9 agents e 2 MCPs** em `.claude/`, para SEO, conteúdo, estratégia e
aquisição.

Fonte: [aitmpl.com](https://aitmpl.com/).

Este kit cobre **como as pessoas chegam** ao site. O texto e a conversão de uma
página específica estão no `KIT-DEVWEB-MOTION-AITMPL` (`copywriting`, `page-cro`).

---

## Roteamento

### SEO
| Assunto da tarefa | Use |
|---|---|
| Estratégia de conteúdo, palavra-chave, SEO técnico | skill `seo-optimizer` |
| Auditar ou diagnosticar problema de SEO | skill `seo-audit`, agent `seo-analyzer` |
| Especialista em SEO para decisão específica | agent `seo-specialist` |
| Páginas em escala via template e dados | skill `programmatic-seo` |
| Aparecer em resposta de IA, não só no Google | agent `search-ai-optimization-expert` |
| Página de comparação com concorrente | skill `competitor-alternatives` |

### Conteúdo
| Assunto da tarefa | Use |
|---|---|
| Estratégia de conteúdo e campanha multicanal | agent `content-marketer` |
| Escrever conteúdo com voz de marca consistente | skill `content-creator` |
| Conteúdo com pesquisa e citação | skill `content-research-writer` |
| LinkedIn, Instagram, X — criar, agendar, otimizar | skill `social-content` |
| Campanha completa: social, e-mail, analytics | skill `executing-marketing-campaigns` |

### Estratégia
| Assunto da tarefa | Use |
|---|---|
| Posicionamento, GTM, ICP, inteligência competitiva | skill `marketing-strategy-pmm` |
| Princípios psicológicos e modelos mentais | skill `marketing-psychology` |
| Ideias de marketing para SaaS/software | skill `marketing-ideas` |
| Analisar mercado e tamanho de oportunidade | agent `market-researcher` |
| Análise de concorrente | agent `competitive-analyst` |
| Anúncios que o concorrente está rodando | skill `competitive-ads-extractor` |
| Tendências | agent `trend-analyst` |

### Aquisição e relacionamento
| Assunto da tarefa | Use |
|---|---|
| Identificar leads qualificados | skill `lead-research-assistant` |
| E-mail frio, follow-up, proposta | agent `sales-automator` |
| Resposta a ticket, FAQ, documentação de suporte | agent `customer-support` |

---

## Regras

**Pergunte pelo público antes de escrever.** Quem é, qual o problema, em que estágio
está. Conteúdo escrito para "todo mundo" não converte ninguém. Se o usuário não
souber responder, esse é o trabalho a fazer primeiro — use skill
`marketing-strategy-pmm` para definir o ICP.

**Texto de IA parece texto de IA.** Estas skills melhoram estrutura e ângulo, não
substituem voz. Entregue como rascunho e diga isso. Evite os vícios: abertura
genérica ("No mundo acelerado de hoje"), tricolon em toda frase, "não apenas X, mas
Y", conclusão que repete a introdução.

**Não invente número.** Estatística de mercado, tamanho de audiência, benchmark de
conversão — se você não tem a fonte, diga que não tem. Número inventado em material
de marketing vira alegação falsa.

**SEO tem prazo de validade.** As skills ensinam princípios que envelhecem devagar
(intenção de busca, estrutura, autoridade). Não sabem o que mudou no último update
do Google. Ao falar de algoritmo, diga que precisa de fonte primária.

**`programmatic-seo` é faca de dois gumes.** Gerar centenas de páginas é exatamente
o que o Google penaliza quando não há valor real em cada uma. Só recomende com dado
próprio que justifique a página existir.

**Verifique a lei antes de disparar.** `sales-automator` escreve e-mail frio em
massa; `lead-research-assistant` coleta dado de pessoa. LGPD, CAN-SPAM e GDPR se
aplicam. Base comprada é ilegal no Brasil. Diga isso ao usuário — não é rodapé.

## Convenções

- Declare qual skill/agent está usando.
- Toda peça de conteúdo precisa de um objetivo único e mensurável.
- Não instale componentes do aitmpl.com sem o usuário pedir.
