---
description: Mostra o que este kit tem e o que se aplica ao seu objetivo
---

Leia `CLAUDE.md` na raiz e apresente, em português:

1. Verifique o que existe **de fato**: `ls .claude/skills` · `ls .claude/agents` ·
   `cat .mcp.json`. Não liste nada que não esteja lá.

2. Resuma agrupado: SEO, conteúdo, estratégia, aquisição.

3. Se o usuário passou um assunto ($ARGUMENTS), diga o que se aplica. Se não passou,
   pergunte qual o objetivo — mais tráfego, mais lead, mais conversão, entender
   concorrente — e **quem é o público**. Sem público definido, nenhuma dessas skills
   entrega algo útil.

Seja direto.
