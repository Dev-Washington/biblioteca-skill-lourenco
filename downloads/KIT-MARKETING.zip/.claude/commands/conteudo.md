---
description: Produz uma peça de conteúdo — do público ao rascunho revisável
---

Pedido: $ARGUMENTS

1. **Defina o público e o objetivo antes de escrever.** Se $ARGUMENTS não deixa
   claro, pergunte:
   - Para quem é (papel, nível de conhecimento, problema que tem)
   - Qual a ação única que a peça deve gerar
   - Onde vai ser publicado
   - Existe voz de marca definida? Tem exemplo de texto que o usuário gosta?

   Sem isso você produz texto genérico. Não avance.

2. **Pesquise se a peça faz alegação factual** — skill `content-research-writer`.
   Cada número precisa de fonte. **Se você não tem a fonte, não use o número** —
   diga ao usuário que a alegação precisa ser verificada.

3. **Estruture antes de escrever** — skill `content-creator`. Ângulo, promessa,
   sequência de argumentos. Mostre o esqueleto e confirme antes do texto completo.

4. **SEO, se for para busca** — skill `seo-optimizer`: intenção de busca, termo
   principal, estrutura de heading. SEO entra na estrutura, não como enfeite no fim.

5. **Escreva.** E revise contra os vícios de texto de IA:
   - abertura genérica ("No mundo acelerado de hoje", "Em um cenário cada vez mais")
   - tricolon em toda frase
   - "não apenas X, mas também Y"
   - conclusão que só repete a introdução
   - adjetivo sem substância ("robusto", "poderoso", "revolucionário")

6. **Entregue como rascunho.** Diga o que precisa da revisão humana: voz, exemplos
   reais da empresa, números a confirmar.
