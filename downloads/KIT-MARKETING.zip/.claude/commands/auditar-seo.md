---
description: Audita o SEO de um site e prioriza o que dá mais resultado
---

Site ou página: $ARGUMENTS  (se vazio, pergunte a URL)

1. **Levante o estado atual** — skill `seo-audit` + agent `seo-analyzer`. Use o MCP
   `fetch` para buscar as páginas de verdade. Verifique:
   - title e meta description (existem? são únicos? cabem no limite?)
   - estrutura de heading (um H1 por página, hierarquia coerente)
   - URL, canonical, redirecionamento
   - `alt` em imagem
   - sitemap e robots.txt
   - velocidade e Core Web Vitals
   - dado estruturado (schema.org)
   - versão mobile

2. **Entenda a intenção de busca** — skill `seo-optimizer`. Problema técnico resolve
   pouco se o conteúdo não responde ao que a pessoa procura. Para os termos
   principais, o conteúdo atual corresponde à intenção?

3. **Considere busca com IA** — agent `search-ai-optimization-expert`. Cada vez mais
   tráfego vem de resposta de IA, não de link azul. O que muda: conteúdo citável,
   resposta direta, dado estruturado.

4. **Priorize por impacto × esforço.** Uma lista de 40 itens com peso igual não
   ajuda. Separe em: corrigir agora (alto impacto, baixo esforço), planejar, e
   ignorar por enquanto. **Diga o que vale a pena não fazer.**

5. **Para cada item**: URL afetada, o que está errado, por que importa, como
   corrigir, e nível de confiança (verificado ou suspeita).

6. Feche com o que **não** foi verificado — o que exige acesso ao Search Console,
   ao servidor ou a ferramenta paga.

Não prometa posição no Google. Ninguém controla isso.
