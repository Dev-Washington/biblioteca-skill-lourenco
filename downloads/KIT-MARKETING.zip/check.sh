#!/usr/bin/env bash
# Verifica se o KIT-MARKETING esta completo.
cd "$(dirname "${BASH_SOURCE[0]}")"
ok=0; fail=0
chk(){ if [ -e "$2" ]; then ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }
echo "== Skills (13) =="
for s in competitive-ads-extractor competitor-alternatives content-creator content-research-writer executing-marketing-campaigns lead-research-assistant marketing-ideas marketing-psychology marketing-strategy-pmm programmatic-seo seo-audit seo-optimizer social-content; do chk "skill $s" ".claude/skills/$s/SKILL.md"; done
echo "== Agents (9) =="
for a in competitive-analyst content-marketer customer-support market-researcher sales-automator search-ai-optimization-expert seo-analyzer seo-specialist trend-analyst; do chk "agent $a" ".claude/agents/$a.md"; done
echo "== Commands (3) =="
for c in auditar-seo conteudo kit-marketing; do chk "/$c" ".claude/commands/$c.md"; done
echo "== Config =="
chk "CLAUDE.md" "CLAUDE.md"
chk "README.md" "README.md"
chk "KIT-MARKETING.md" "KIT-MARKETING.md"
chk ".mcp.json" ".mcp.json"
chk ".mcp.optional.json" ".mcp.optional.json"
node -e 'JSON.parse(require("fs").readFileSync(".mcp.json","utf8"))' 2>/dev/null \
  && echo "  .mcp.json: JSON valido" || { echo "  .mcp.json: INVALIDO"; fail=$((fail+1)); }

echo
echo "  ativos:   $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo "  opcionais: $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.optional.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo
echo "== Ferramentas =="
for t in node npx; do
  if command -v "$t" >/dev/null 2>&1; then echo "  ok       $t"; else echo "  ausente  $t"; fi
done
echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
