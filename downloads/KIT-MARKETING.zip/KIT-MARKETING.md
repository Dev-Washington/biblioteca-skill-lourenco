# Kit Marketing — SEO, conteúdo e aquisição

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**24 componentes · 12.698 downloads somados.** É o kit que traz gente para o site que
os outros kits constroem.

---

## 1. O recorte

O `KIT-DEVWEB-MOTION-AITMPL` já tem `copywriting` (923) e `page-cro` (97) — o texto
e a conversão de uma página específica. Este kit cobre o resto da operação: por que
alguém chega naquela página.

A categoria `business-marketing` tem 48 skills e 21 agents. Instalei 13 skills e 9
agents, deixando de fora o que já está em outro kit (`copywriting`, `page-cro`,
`onboarding-cro`, `analytics-tracking`, `app-store-optimization`, `legal-advisor`) e
o que é de vendas/CRM pesado.

---

## 2. Componentes

### SEO
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `business-marketing/seo-optimizer` | skill | Estratégia de conteúdo, SEO técnico, pesquisa de palavra-chave | 2.686 |
| `web-tools/seo-analyzer` | agent | Análise de SEO de site | 930 |
| `business-marketing/seo-audit` | skill | Auditar e diagnosticar problema de SEO no site | 401 |
| `business-marketing/seo-specialist` | agent | Especialista em SEO | 404 |
| `business-marketing/programmatic-seo` | skill | Páginas em escala via template e dados | 157 |
| `web-tools/search-ai-optimization-expert` | agent | Otimizar para busca com IA (AEO/GEO) | 143 |

`seo-optimizer` é a 2ª skill mais baixada de toda a categoria de marketing.
`search-ai-optimization-expert` cobre algo novo: aparecer nas respostas de IA, não só
no Google.

### Conteúdo
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `business-marketing/content-marketer` | agent | Estratégia de conteúdo, SEO, campanha multicanal | 1.013 |
| `business-marketing/content-creator` | skill | Conteúdo com voz de marca consistente | 998 |
| `business-marketing/content-research-writer` | skill | Conteúdo com pesquisa e citação | 605 |
| `business-marketing/social-content` | skill | Redes sociais: criar, agendar, otimizar | 432 |
| `creative-design/executing-marketing-campaigns` | skill | Campanha: estratégia, social, e-mail, analytics | 307 |

### Estratégia e mercado
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `business-marketing/marketing-strategy-pmm` | skill | Posicionamento, GTM, ICP, inteligência competitiva | 472 |
| `business-marketing/marketing-psychology` | skill | Princípios psicológicos e modelos mentais aplicados | 427 |
| `business-marketing/lead-research-assistant` | skill | Identifica leads qualificados analisando seu negócio | 403 |
| `business-marketing/marketing-ideas` | skill | Ideias e estratégias para SaaS e software | 364 |
| `business-marketing/competitive-ads-extractor` | skill | Extrai e analisa anúncios de concorrente das ad libraries | 305 |
| `business-marketing/competitor-alternatives` | skill | Páginas de comparação com concorrente, para SEO e vendas | 98 |
| `business-marketing/market-researcher` | agent | Analisar mercado, comportamento, tamanho de oportunidade | 179 |
| `business-marketing/competitive-analyst` | agent | Análise competitiva | 167 |
| `business-marketing/trend-analyst` | agent | Tendências | 166 |

`competitive-ads-extractor` é o mais concreto do grupo: puxa os anúncios que seu
concorrente está rodando no Facebook e LinkedIn e analisa o ângulo usado.

### Vendas e suporte
`business-marketing/sales-automator` (336) — e-mail frio, sequência de follow-up,
proposta. `business-marketing/customer-support` (236) — resposta a ticket, FAQ.

### MCPs
`web/web-fetch` (1.308) — buscar conteúdo web, funciona sem credencial.
`devtools/firecrawl` (161) — scraping profundo, screenshot, crawling; precisa de
chave de API.

---

## 3. Ressalvas honestas

1. **Marketing é o domínio onde texto gerado por IA mais se parece com texto gerado
   por IA.** Estas skills melhoram a estrutura e o ângulo; não substituem sua voz.
   Use como rascunho, reescreva.

2. **`competitive-ads-extractor` e `lead-research-assistant` dependem de raspar
   dados de terceiros.** Verifique os termos de uso da plataforma antes. Raspar ad
   library pública é diferente de raspar dado pessoal — o segundo tem implicação de
   LGPD (ver `KIT-SECURITY-SISTEM-AITMPL`).

3. **Nenhuma skill de SEO tem dado atualizado de algoritmo.** Elas ensinam
   princípios que envelhecem devagar (intenção de busca, estrutura, links) — não o
   que mudou no último update do Google. Para isso, fonte primária.

4. **`programmatic-seo` gera páginas em escala.** É eficaz e é exatamente o que o
   Google penaliza quando feito sem valor real. Só use com dado próprio que
   justifique a página existir.

5. **`sales-automator` escreve e-mail frio em massa.** Verifique CAN-SPAM, GDPR e
   LGPD antes de disparar. Base comprada é ilegal no Brasil.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --skill business-marketing/seo-optimizer --yes
npx claude-code-templates@latest --skill business-marketing/content-creator --yes
npx claude-code-templates@latest --skill business-marketing/marketing-strategy-pmm --yes
npx claude-code-templates@latest --agent business-marketing/content-marketer --yes
npx claude-code-templates@latest --agent web-tools/seo-analyzer --yes
npx claude-code-templates@latest --mcp web/web-fetch --yes
```
