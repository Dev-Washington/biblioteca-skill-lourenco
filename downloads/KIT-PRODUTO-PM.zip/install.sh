#!/usr/bin/env bash
# Instala o KIT-PRODUTO-PM em um projeto existente.
# Uso:  ./install.sh /caminho/do/seu/projeto
set -euo pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:-}"

[ -n "$DEST" ] || { echo "uso: $0 /caminho/do/projeto" >&2; exit 1; }
[ -d "$DEST" ] || { echo "erro: '$DEST' nao e um diretorio" >&2; exit 1; }
DEST="$(cd "$DEST" && pwd)"
[ "$DEST" != "$KIT" ] || { echo "erro: destino e o proprio kit" >&2; exit 1; }

echo "Kit:     $KIT"
echo "Destino: $DEST"
echo

mkdir -p "$DEST/.claude/skills" "$DEST/.claude/agents" "$DEST/.claude/commands"

copy_dir() {
  local src="$KIT/.claude/$1" name added=0 skipped=0
  [ -d "$src" ] || return 0
  for path in "$src"/*; do
    [ -e "$path" ] || continue
    name="$(basename "$path")"
    if [ -e "$DEST/.claude/$1/$name" ]; then skipped=$((skipped+1))
    else cp -R "$path" "$DEST/.claude/$1/$name"; added=$((added+1)); fi
  done
  echo "  $1: $added adicionado(s), $skipped ja existia(m)"
}

copy_dir skills
copy_dir agents
copy_dir commands

echo
if [ -f "$DEST/CLAUDE.md" ]; then
  cp "$KIT/CLAUDE.md" "$DEST/.claude/KIT-PRODUTO-PM.md"
  if grep -q "KIT-PRODUTO-PM.md" "$DEST/CLAUDE.md"; then
    echo "CLAUDE.md: referencia ao kit ja presente"
  else
    printf '\n@.claude/KIT-PRODUTO-PM.md\n' >> "$DEST/CLAUDE.md"
    echo "CLAUDE.md: ja existia - kit salvo em .claude/KIT-PRODUTO-PM.md e referenciado via @import"
  fi
else
  cp "$KIT/CLAUDE.md" "$DEST/CLAUDE.md"; echo "CLAUDE.md: criado"
fi

if [ -s "$KIT/.mcp.json" ] && [ "$(node -e 'const m=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"));console.log(Object.keys(m.mcpServers||{}).length)' "$KIT/.mcp.json")" != "0" ]; then
  if [ -f "$DEST/.mcp.json" ]; then
    node -e '
      const fs=require("fs"), [dstF,srcF]=process.argv.slice(1);
      const d=JSON.parse(fs.readFileSync(dstF,"utf8")), s=JSON.parse(fs.readFileSync(srcF,"utf8"));
      d.mcpServers=d.mcpServers||{}; let n=0;
      for(const [k,v] of Object.entries(s.mcpServers||{})){
        if(k in d.mcpServers) console.log("  pulado (ja existe): mcp "+k);
        else { d.mcpServers[k]=v; n++; console.log("  + mcp "+k); }
      }
      if(n) fs.writeFileSync(dstF,JSON.stringify(d,null,2)+"\n");
    ' "$DEST/.mcp.json" "$KIT/.mcp.json"
    echo ".mcp.json: mesclado"
  else
    cp "$KIT/.mcp.json" "$DEST/.mcp.json"; echo ".mcp.json: criado"
  fi
fi
cp "$KIT/.mcp.optional.json" "$DEST/.mcp.optional.json" 2>/dev/null || true

echo
echo "Pronto. Abra '$DEST' no Claude Code e rode /kit-produto-pm."
