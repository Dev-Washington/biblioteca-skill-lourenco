# Kit Produto e Gestão — PRD, roadmap, backlog

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**21 componentes · 7.412 downloads somados.**

---

## 1. O recorte

Este kit é sobre **decidir o que construir**, antes de qualquer kit técnico entrar.
Combina a categoria `project-management` (20 commands) com os agents de produto de
`business-marketing`.

Faz sentido quando mais de uma pessoa mexe no roadmap. Para quem trabalha sozinho,
o `/writing-plans` do `KIT-DEVWEB-AITMPL` já resolve.

---

## 2. Componentes

### Definir o produto
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `business-marketing/business-analyst` | agent | Processo de negócio, levantar requisito, oportunidade de melhoria | 955 |
| `business-marketing/product-strategist` | agent | Liderança de produto, cascata de OKR | 931 |
| `business-marketing/product-strategist` | skill | Mesmo tema, em skill | 316 |
| `business-marketing/product-manager-toolkit` | skill | RICE, entrevista com cliente, priorização | 336 |
| `business-marketing/ceo-advisor` | skill | Decisão estratégica, desenvolvimento organizacional | 385 |
| `business-marketing/product-manager` | agent | Estratégia de produto, priorização, roadmap | 210 |
| `data-ai/prd` | agent | Gera PRD completo em Markdown | 151 |

### Executar
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `business-marketing/project-manager` | agent | Gestão de projeto | 217 |
| `business-marketing/scrum-master` | agent | Facilitação ágil | 108 |
| `business-marketing/ux-researcher` | agent | Pesquisa com usuário | 156 |

### Commands
`todo` (787) · `create-prd` (656) · `init-project` (377) · `create-feature` (238) ·
`project-health-check` (105) · `create-prp` (98) · `milestone-tracker` (87) ·
`create-jtbd` (84) · `release` (40) · `github-issues` (32)

`create-jtbd` — Jobs-to-be-Done — é o mais subestimado: força descrever o que o
usuário está tentando **realizar**, não a funcionalidade que ele pediu. Muda o que
você constrói.

### MCP
`integration/github-integration` (1.143) — issues, PRs, repositórios. Precisa de token.

---

## 3. Ressalvas honestas

1. **`product-strategist` existe como agent (931) e como skill (316).** Nomes
   idênticos, componentes diferentes. Instalei os dois.

2. **PRD gerado por IA precisa de dado real.** `create-prd` produz uma estrutura
   convincente com premissas inventadas se você não fornecer pesquisa, número de
   uso e entrevista. Estrutura boa com conteúdo inventado é pior que rascunho
   honesto — parece decidido.

3. **Priorização RICE depende de estimativas suas.** A fórmula não cria informação:
   se o alcance e o impacto forem chutes, o ranking também é. Use para organizar a
   conversa, não para terminá-la.

4. **`scrum-master` (108) e `release` (32)** são pouco baixados. Os pesos do kit são
   `business-analyst` (955) e `product-strategist` (931).

5. **Estes componentes não conhecem seu contexto.** Roadmap gerado sem saber a
   capacidade do time, a dívida técnica acumulada e os compromissos já assumidos é
   ficção organizada.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --agent business-marketing/business-analyst --yes
npx claude-code-templates@latest --agent business-marketing/product-strategist --yes
npx claude-code-templates@latest --skill business-marketing/product-manager-toolkit --yes
npx claude-code-templates@latest --command project-management/create-prd --yes
npx claude-code-templates@latest --command project-management/create-jtbd --yes
npx claude-code-templates@latest --command project-management/todo --yes
```
