# Kit Produto e Gestão — PRD, roadmap, backlog

**3 skills, 7 agents, 12 commands e 1 MCP** para decidir o que construir.

Origem: [aitmpl.com](https://aitmpl.com/) · **21 componentes, 7.412 downloads somados.**

---

## Quando vale

Este kit é sobre **decidir o que construir**, antes de qualquer kit técnico entrar.

Faz sentido quando mais de uma pessoa mexe no roadmap. Para quem trabalha sozinho, o
`/writing-plans` do `KIT-DEVWEB-AITMPL` costuma resolver com menos cerimônia — e o
`CLAUDE.md` instrui a IA a dizer isso.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-produto`. Ou instale num projeto: `./install.sh /caminho` · `./check.sh`.

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-produto [assunto]` | Mostra o que tem e o que se aplica ao momento |
| `/definir-feature [problema]` | Do problema ao requisito, separando validado de premissa |
| `/create-prd` · `/create-jtbd` · `/create-prp` | Do catálogo |
| `/todo` · `/init-project` · `/create-feature` · `/release` | Do catálogo |
| `/project-health-check` · `/milestone-tracker` · `/github-issues` | Do catálogo |

O `/definir-feature` faz duas coisas que quase nenhum fluxo de PRD faz: **volta da
solução para o problema** (JTBD), e **separa explicitamente o que é validado do que
é premissa**. Se a lista de validado estiver vazia, ele diz isso em vez de preencher.

---

## O que está instalado

**Decidir** — `business-analyst` (955), `product-strategist` agent (931),
`ceo-advisor` (385), `product-manager-toolkit` (336), `product-strategist` skill
(316), `product-manager` (210), `ux-researcher` (156), `prd` (151).

**Executar** — `project-manager` (217), `scrum-master` (108).

**Commands** — `todo` (787), `create-prd` (656), `init-project` (377),
`create-feature` (238), `project-health-check` (105), `create-prp` (98),
`milestone-tracker` (87), `create-jtbd` (84), `release` (40), `github-issues` (32).

`create-jtbd` é o mais subestimado do kit: força descrever o que o usuário tenta
**realizar**, não a funcionalidade que pediu.

Detalhe: [KIT-PRODUTO-PM.md](KIT-PRODUTO-PM.md).

---

## MCP

`.mcp.json` está vazio. `github` (1.143) fica em `.mcp.optional.json` — precisa de
token. Use escopo mínimo e não versione o arquivo preenchido.

---

## Limitações

1. **PRD gerado por IA sem dado real é ficção organizada.** `/create-prd` produz
   estrutura convincente com premissas inventadas se você não fornecer pesquisa e
   número de uso. O `CLAUDE.md` obriga a marcar cada premissa não validada.

2. **RICE não cria informação.** Se alcance e impacto são chutes, o ranking é chute
   ordenado. Serve para estruturar a conversa, não para encerrá-la.

3. **Roadmap sem capacidade real é lista de desejos.** Estes componentes não sabem
   quantas pessoas você tem nem que dívida técnica existe.

4. **`product-strategist` existe como agent (931) e skill (316)** — componentes
   diferentes, ambos instalados.

---

## Arquivos

```
KIT-PRODUTO-PM/
├── CLAUDE.md · README.md · KIT-PRODUTO-PM.md
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/  skills/ 3 · agents/ 7 · commands/ 12
```
