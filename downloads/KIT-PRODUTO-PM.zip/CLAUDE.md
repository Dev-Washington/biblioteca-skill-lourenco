# Kit Produto e Gestão — PRD, roadmap, backlog

**3 skills, 7 agents e 10 commands** em `.claude/`, para decidir o que construir.

Fonte: [aitmpl.com](https://aitmpl.com/).

---

## Roteamento

### Decidir
| Assunto da tarefa | Use |
|---|---|
| Levantar requisito, mapear processo, achar oportunidade | agent `business-analyst` |
| Estratégia de produto, OKR, roadmap | agent `product-strategist`, agent `product-manager` |
| RICE, entrevista com cliente, priorização | skill `product-manager-toolkit` |
| Decisão estratégica, organização | skill `ceo-advisor` |
| **O que o usuário está tentando realizar** (JTBD) | command `/create-jtbd` |
| Pesquisa com usuário | agent `ux-researcher` |

### Documentar
| Assunto da tarefa | Use |
|---|---|
| PRD completo | command `/create-prd`, agent `prd` |
| PRP (Product Requirement Prompt) | command `/create-prp` |

### Executar
| Assunto da tarefa | Use |
|---|---|
| Gestão de projeto, prazo, dependência | agent `project-manager` |
| Facilitação ágil, cerimônia, impedimento | agent `scrum-master` |
| Lista de tarefas em `todos.md` | command `/todo` |
| Iniciar projeto com estrutura | command `/init-project` |
| Scaffold de feature com teste e doc | command `/create-feature` |
| Saúde do projeto, métricas | command `/project-health-check` |
| Marco e previsão | command `/milestone-tracker` |
| Release | command `/release` |
| Issues do GitHub | command `/github-issues` |

---

## Regras

**Pergunte pelo problema, não pela funcionalidade.** Quando o usuário pede "quero um
botão de exportar", a pergunta é o que ele vai fazer com o arquivo exportado.
`/create-jtbd` existe para isso, e frequentemente muda o que se constrói.

**PRD sem dado real é ficção organizada.** `/create-prd` gera uma estrutura
convincente com premissas inventadas se você não fornecer pesquisa, número de uso e
entrevista. **Marque explicitamente cada premissa não validada** — estrutura boa com
conteúdo inventado é pior que rascunho honesto, porque parece decidido.

**RICE não cria informação.** Se alcance e impacto são chutes, o ranking é chute
ordenado. Use para estruturar a conversa, não para encerrá-la. E mostre as
estimativas, não só o resultado.

**Roadmap precisa de capacidade real.** Antes de propor prazo, pergunte: quantas
pessoas, que dívida técnica existe, que compromissos já estão assumidos. Roadmap
sem isso é lista de desejos.

**Diga o que não vai ser feito.** Um roadmap que só tem o que entra não é decisão —
decisão é o que fica de fora e por quê.

## Convenções

- Declare qual skill/agent/command está usando.
- Toda premissa não validada deve estar marcada como tal.
- Não invente número de mercado ou de uso. Se não tem, diga que precisa levantar.
