---
description: Define uma feature do problema ao requisito, sem inventar premissa
---

Feature ou problema: $ARGUMENTS

1. **Volte ao problema.** Se $ARGUMENTS descreve uma solução ("quero um botão de
   exportar"), pergunte o que a pessoa vai fazer com o resultado. Use command
   `/create-jtbd` — Jobs-to-be-Done força descrever o que o usuário tenta
   **realizar**, não a funcionalidade que pediu. Isso muda o que se constrói com
   frequência.

2. **Levante o que se sabe e o que se supõe** — agent `business-analyst`. Separe em
   duas listas explícitas:
   - **Validado**: pesquisa, entrevista, dado de uso, ticket de suporte
   - **Premissa**: tudo o que ninguém confirmou

   Se a lista de validado estiver vazia, **diga isso ao usuário** e pergunte se vale
   pesquisar antes de especificar. Não preencha com o que parece razoável.

3. **Priorize com as contas à mostra** — skill `product-manager-toolkit` (RICE).
   Mostre alcance, impacto, confiança e esforço separados, não só a nota final. Se
   forem estimativas, marque como estimativa.

4. **Escreva o requisito** — command `/create-prd` ou agent `prd`. Obrigatório:
   - o problema, em uma frase
   - quem tem o problema
   - critério de aceite verificável
   - **o que está fora de escopo**
   - premissas não validadas, marcadas

5. **Cheque a capacidade** — agent `project-manager`. Prazo sem saber quantas
   pessoas e que dívida técnica existe é lista de desejos.

Entregue dizendo o que ainda precisa ser validado antes de alguém começar a codar.
