---
description: Mostra o que este kit tem e o que se aplica ao momento do produto
---

Leia `CLAUDE.md` e apresente, em português:

1. Verifique o que existe **de fato**: `ls .claude/skills` · `ls .claude/agents` ·
   `ls .claude/commands`. Não liste nada que não esteja lá.

2. Resuma agrupado: decidir, documentar, executar.

3. Se o usuário passou um assunto ($ARGUMENTS), diga o que se aplica. Se não passou,
   pergunte em que momento ele está — descobrindo o problema, priorizando,
   escrevendo requisito, ou acompanhando execução — e **quantas pessoas mexem no
   roadmap**. Para quem trabalha sozinho, o `/writing-plans` do `KIT-DEVWEB-AITMPL`
   costuma resolver com menos cerimônia.

Seja direto.
