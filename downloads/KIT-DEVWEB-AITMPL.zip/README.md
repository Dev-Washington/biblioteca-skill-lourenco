# Kit DevWeb — engenharia de aplicações web

**43 skills, 20 agents, 25 commands, 6 hooks e 5 MCPs** para construir, testar e
operar aplicações web. Tudo já instalado nesta pasta — não precisa rodar `npx`.

Origem: [aitmpl.com](https://aitmpl.com/) · repositório
[davila7/claude-code-templates](https://github.com/davila7/claude-code-templates).

Este é o kit de **engenharia**. Para animação e landing page visual, use o
`KIT-DEVWEB-MOTION-AITMPL`.

---

## Leia isto primeiro

**Dois hooks bloqueiam comandos de verdade:**

- `conventional-commits` — recusa mensagem de commit fora do padrão
  `tipo(escopo): descrição`
- `prevent-direct-push` — recusa `git push` direto em `main` e `develop`

Testados nesta máquina: `"consertei umas coisas"` é recusado, `"feat: adiciona login"`
passa; `git push origin main` é recusado, `git push origin feature/x` passa.

São boas práticas — mas se você trabalha sozinho commitando direto na `main`, vão
atrapalhar. Instale com `--sem-hooks`.

---

## Como usar

### Opção A — trabalhar dentro desta pasta

```bash
claude
```
Rode `/kit-devweb` para ver o que está disponível.

### Opção B — instalar num projeto existente

```bash
./install.sh /caminho/do/seu/projeto              # com os hooks
./install.sh /caminho/do/seu/projeto --sem-hooks  # só o conhecimento
```

### Windows (PowerShell)

```powershell
.\install.ps1 C:\caminho\do\seu\projeto
```

Se o Windows bloquear a execução do script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Isso libera só a sessão atual — não altera a política da máquina.

### macOS e Linux

```bash
chmod +x install.sh check.sh    # só na primeira vez
./install.sh /caminho/do/seu/projeto
./check.sh
```

O `install.ps1` também roda no macOS e no Linux, se você tiver PowerShell 7+.

Não sobrescreve nada. `CLAUDE.md` existente ganha `@import`; `settings.json` e
`.mcp.json` são mesclados preservando o que já era seu. Rodar duas vezes não duplica.

### Conferir

```bash
./check.sh
```

---

## Comandos próprios do kit

| Comando | O que faz |
|---|---|
| `/kit-devweb [assunto]` | Mostra o que está instalado e o que se aplica ao seu caso |
| `/novo-projeto [descrição]` | Aplicação do zero: entender → arquitetura → schema → scaffold |
| `/feature [descrição]` | Feature completa: escopo → ler o código → plano → teste → código → review |
| `/investigar [problema]` | Bug com método: reproduzir → delimitar → causa raiz → teste que falha |
| `/revisar [alvo]` | Revisão em camadas, com evidência e nível de confiança |

Os quatro últimos impõem uma ordem que a IA costuma pular: **entender antes de
codar, e investigar antes de corrigir.**

## Comandos do catálogo

`/code-review` · `/ultra-think` · `/refactor-code` · `/explain-code` · `/debug-error` ·
`/generate-tests` · `/test-coverage` · `/commit` · `/create-pr` ·
`/create-architecture-documentation` · `/update-docs` · `/generate-api-documentation` ·
`/add-changelog` · `/containerize-application` · `/ci-setup` · `/design-database-schema` ·
`/design-rest-api` · `/setup-linting` · `/performance-audit` ·
`/optimize-database-performance`

---

## O que está instalado

### Método de trabalho — o que mais muda o resultado

Estas skills não ensinam tecnologia; ensinam como conduzir a tarefa. São as mais
ignoradas e as que mais mudam a qualidade da entrega.

| Skill | Downloads | Para quê |
|---|---|---|
| `brainstorming` | 2.606 | "Use ANTES de qualquer trabalho criativo" |
| `clean-code` | 1.695 | Sem over-engineering, sem comentário desnecessário |
| `systematic-debugging` | 527 | Investigar antes de propor correção |
| `writing-plans` | 375 | Planejar tarefa multi-passo antes de tocar em código |
| `error-resolver` | 249 | Diagnóstico por primeiros princípios |
| `test-driven-development` | 203 | Teste antes da implementação |

`clean-code` merece destaque: "no over-engineering" ataca exatamente o vício mais
comum de código gerado por IA — abstração antecipada, camada que ninguém pediu.

### A família `senior-*` — a espinha

`senior-frontend` (7.366) · `senior-backend` (6.320) · `senior-architect` (5.217) ·
`senior-fullstack` (3.016) · `senior-devops` (872) · `senior-qa` (719)

Seis skills cobrindo as seis frentes de um sistema web.

### Backend, API e banco

`code-reviewer` (8.384), `api-integration-specialist` (755),
`supabase-postgres-best-practices` (652), `nestjs-expert` (280),
`database-design` (267), `postgres-best-practices` (206),
`backend-dev-guidelines` (164), `nodejs-best-practices` (160), `api-patterns` (130),
`postgresql` (76), `database-migration` (37).

`api-patterns` resolve a decisão que trava projeto no dia 1: **REST, GraphQL ou tRPC.**

### Frontend

`react-best-practices` (3.272), `web-performance-optimization` (806),
`nextjs-best-practices` (467), `typescript-expert` (176),
`frontend-dev-guidelines` (147), `performance` (122), `seo` (114), `shadcn` (107),
`nextjs-app-router-patterns` (79), `progressive-web-app` (55),
`tanstack-query-expert` (46), `zod-validation-expert` (44),
`react-state-management` (38), `astro` (34).

### Agents (20)

`frontend-developer` (10.867 — o mais baixado do catálogo), `code-reviewer` (8.333),
`backend-architect` (6.339), `fullstack-developer` (4.816), `debugger` (3.650),
`database-architect` (3.175), `python-pro` (3.227), `test-engineer` (2.624),
`typescript-pro` (2.560), `architect-review` (2.457), `error-detective` (2.133),
`devops-engineer` (1.951), `documentation-expert` (1.848),
`deployment-engineer` (1.633), `javascript-pro` (1.370),
`database-optimization` (1.074), `sql-pro` (945), `devops-troubleshooter` (647),
`performance-profiler` (493), `api-architect` (196).

Lista completa com justificativa: [KIT-DEVWEB-AITMPL.md](KIT-DEVWEB-AITMPL.md).

---

## Hooks

| Hook | Dispara em | O que faz |
|---|---|---|
| `conventional-commits` | `git commit` | **Bloqueia** mensagem fora do padrão |
| `prevent-direct-push` | `git push` | **Bloqueia** push em `main`/`develop` |
| `lint-on-save` | após Edit | ESLint, pylint, rubocop |
| `smart-formatting` | após Edit | Prettier, Black, gofmt, rustfmt |
| `run-tests-after-changes` | após Edit | `npm run test:quick` se existir |
| `simple-notifications` | Stop / Notification | Notificação no desktop |

**Duas armadilhas reais:**

`run-tests-after-changes` depende de um script `test:quick` no `package.json`. Sem
ele, o hook imprime "⚠️ Tests may need attention" em toda edição **sem ter rodado
teste nenhum**. Crie o script ou remova o hook — a mensagem dá falsa sensação de
cobertura.

`lint-on-save` e `smart-formatting` chamam `npx eslint` e `npx prettier` a cada
edição. Falham em silêncio se a ferramenta não existir (`|| true`) — ausência de
erro não significa que formatou. Em projeto grande, adicionam latência perceptível.

Para desativar qualquer um: edite `.claude/settings.json`.

---

## MCPs

### Ativo — `.mcp.json`

| Servidor | O que faz | Requisitos |
|---|---|---|
| `playwright` | Abre a página, screenshot, executa JS | nenhum |

### Opcionais — `.mcp.optional.json`

| Servidor | Requisitos |
|---|---|
| `context7` | Chave de API — puxa doc atualizada da fonte, por versão de lib |
| `github` | Personal access token — repos, issues, PRs |
| `postgresql` | Connection string — query direto no banco |
| `serena` | `uv` instalado + Serena clonado local (o config vem com caminhos placeholder) |

`context7` vale a pena em projeto que usa libs que mudam rápido: evita a IA
trabalhar de memória sobre uma API que já mudou de versão.

> **Cuidado com credenciais.** O token do GitHub dá acesso de escrita aos seus
> repositórios — use escopo mínimo. A connection string do Postgres dá acesso ao
> banco — em produção, use um usuário read-only. Não versione o `.mcp.json`
> preenchido.

---

## Limitações — leia antes de confiar

1. **Nomes duplicados entre skill e agent.** `code-reviewer` existe como skill
   (8.384) e como agent (8.333); `database-architect`, `sql-pro` e
   `backend-architect` também aparecem em mais de um lugar. São componentes
   diferentes, ambos instalados, com função parecida. Sempre use o caminho completo
   `categoria/nome` ao reinstalar.

2. **Popularidade muito desigual.** `astro` (34 downloads na origem),
   `database-migration` (37), `react-state-management` (38),
   `zod-validation-expert` (44) e `tanstack-query-expert` (46) são pouco usados —
   provavelmente pouco testados. Já `frontend-developer` (10.867),
   `code-reviewer` (8.384) e `senior-frontend` (7.366) estão entre os mais baixados
   do catálogo inteiro.

3. **Sem skill de animação.** Intencional. Ver `KIT-DEVWEB-MOTION-AITMPL`.

4. **Hooks executam código na sua máquina a cada ação.** Os dois scripts estão em
   `.claude/hooks/` — leia antes de instalar em máquina de trabalho.

5. **Skill não substitui engenheiro.** O kit aumenta a chance de a IA lembrar de
   verificar algo. Não substitui revisão humana em decisão de arquitetura, migração
   de banco ou qualquer coisa difícil de reverter.

---

## Arquivos

```
KIT-DEVWEB-AITMPL/
├── CLAUDE.md                contexto automático: ordem de trabalho e roteamento
├── README.md                este arquivo
├── KIT-DEVWEB-AITMPL.md     análise do catálogo que originou a seleção
├── install.sh               instala em outro projeto (--sem-hooks disponível)
├── check.sh                 verifica instalação e ferramentas
├── .mcp.json                MCP pronto (playwright)
├── .mcp.optional.json       MCPs que precisam de credencial
└── .claude/
    ├── settings.json        6 hooks
    ├── hooks/               2 scripts python
    ├── skills/              43 skills
    ├── agents/              20 agents
    └── commands/            25 commands (20 do catálogo + 5 próprios)
```

## Atualizar um componente

```bash
npx claude-code-templates@latest --skill <categoria>/<nome> --yes
```

Rode a partir desta pasta. A API do GitHub limita a 60 requisições/hora sem
autenticação — instalar 94 componentes de uma vez estoura o limite e falha com
HTTP 403. Este kit foi instalado clonando o repositório, que não passa pela API REST.

**Não atualize os 5 commands próprios** (`kit-devweb`, `novo-projeto`, `feature`,
`investigar`, `revisar`) — não estão no catálogo.
