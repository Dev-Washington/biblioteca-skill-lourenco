---
description: Mostra o que este kit tem — e se você realmente precisa dele
---

Leia `CLAUDE.md` e apresente, em português:

1. **Primeiro, verifique se o kit é necessário.** Pergunte onde o usuário hospeda
   hoje. Se for Vercel, Railway, Render ou similar, diga que o `KIT-DEVWEB-AITMPL`
   já cobre o que ele precisa, e que este kit só vale ao gerenciar infra própria.
   Ser honesto aqui vale mais que listar componentes.

2. Verifique o que existe **de fato**: `ls .claude/agents` · `ls .claude/commands` ·
   `cat .mcp.json`. Não liste nada que não esteja lá.

3. Resuma agrupado: arquitetura, IaC, Kubernetes, observabilidade, deploy.

4. Destaque os commands de emergência — `/rollback-deploy` e `/hotfix-deploy` — e
   diga para lerem **antes** de precisar.

5. Se o usuário passou um assunto ($ARGUMENTS), diga o que se aplica.
