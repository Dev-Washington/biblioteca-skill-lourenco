---
description: Revisa a infraestrutura — custo, confiabilidade, risco operacional
---

Alvo: $ARGUMENTS  (se vazio, o projeto atual)

1. **Mapeie o que existe.** Procure `*.tf`, `*.yaml` de Kubernetes, `Dockerfile`,
   `docker-compose`, workflows de CI, `vercel.json`. Liste o que achou. Se não achar
   nada, pergunte onde a infra está definida.

2. **Revise por dimensão**, dizendo qual agent está usando:

   | Dimensão | Procure |
   |---|---|
   | Segurança | credencial em texto no código, bucket público, security group aberto, container como root |
   | Confiabilidade | ponto único de falha, sem health check, sem retry, sem limite de recurso |
   | Custo | recurso superdimensionado, ambiente parado ligado, storage sem lifecycle |
   | Observabilidade | sem métrica, sem alerta, log sem retenção, sem tracing |
   | Reversibilidade | dá para reverter o deploy? e a migração de banco? |
   | IaC | state em local, sem lock, recurso criado à mão fora do código |

3. **Para cada achado**: arquivo e linha, o que acontece na prática, e a correção.
   Marque o nível de confiança — verificado no código, ou suspeita.

4. **Ordene por risco real**, não por quantidade. Credencial exposta vale mais que
   vinte avisos de convenção de nome.

5. **Se propuser mudança em Terraform**, mostre o `terraform plan` e destaque tudo
   que aparecer como `destroy`. Nunca sugira `apply` direto.

6. Feche com o que não deu para verificar — o que exige acesso ao console da nuvem,
   à conta de billing ou a dado de produção.

Este comando **audita**. Não altere infraestrutura sem o usuário pedir explicitamente.
