#!/usr/bin/env bash
# Verifica se o KIT-DEVOPS-CLOUD esta completo.
cd "$(dirname "${BASH_SOURCE[0]}")"
ok=0; fail=0
chk(){ if [ -e "$2" ]; then ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }
echo "== Skills (1) =="
for s in devops-iac-engineer; do chk "skill $s" ".claude/skills/$s/SKILL.md"; done
echo "== Agents (12) =="
for a in cloud-architect devops-incident-responder kubernetes-specialist microservices-architect monitoring-specialist network-engineer platform-engineer se-gitops-ci-specialist sre-engineer terraform-engineer terraform-specialist vercel-deployment-specialist; do chk "agent $a" ".claude/agents/$a.md"; done
echo "== Commands (12) =="
for c in blue-green-deployment deployment-monitoring hotfix-deploy kit-devops prepare-release revisar-infra rollback-deploy setup-automated-releases setup-ci-cd-pipeline setup-docker-containers setup-kubernetes-deployment setup-monitoring-observability; do chk "/$c" ".claude/commands/$c.md"; done
echo "== Config =="
chk "CLAUDE.md" "CLAUDE.md"
chk "README.md" "README.md"
chk "KIT-DEVOPS-CLOUD.md" "KIT-DEVOPS-CLOUD.md"
chk ".mcp.json" ".mcp.json"
chk ".mcp.optional.json" ".mcp.optional.json"
node -e 'JSON.parse(require("fs").readFileSync(".mcp.json","utf8"))' 2>/dev/null \
  && echo "  .mcp.json: JSON valido" || { echo "  .mcp.json: INVALIDO"; fail=$((fail+1)); }

echo
echo "  ativos:   $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo "  opcionais: $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.optional.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo
echo "== Ferramentas =="
for t in node npx; do
  if command -v "$t" >/dev/null 2>&1; then echo "  ok       $t"; else echo "  ausente  $t"; fi
done
echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
