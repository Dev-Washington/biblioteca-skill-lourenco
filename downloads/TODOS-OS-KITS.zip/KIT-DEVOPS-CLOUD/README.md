# Kit DevOps e Cloud

**1 skill, 12 agents e 12 commands** para infraestrutura própria:
Kubernetes, Terraform, observabilidade, SRE.

Origem: [aitmpl.com](https://aitmpl.com/) · **25 componentes, 4.022 downloads somados.**

---

## Você provavelmente não precisa deste kit

O `KIT-DEVWEB-AITMPL` já tem Docker, CI/CD, deploy e troubleshooting. **Este kit só
vale se você sair de PaaS.**

Se você roda em Vercel, Railway ou Render, o outro cobre. Aqui entram Kubernetes,
Terraform, observabilidade e SRE — coisas que só existem quando você gerencia a
própria infra. O `/kit-devops` pergunta isso antes de recomendar qualquer coisa.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-devops`. Ou instale num projeto: `./install.sh /caminho` · `./check.sh`.

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-devops [assunto]` | **Verifica se você precisa do kit**, depois mostra o que tem |
| `/revisar-infra [alvo]` | Auditoria: segurança, confiabilidade, custo, reversibilidade |
| `/rollback-deploy` · `/hotfix-deploy` | Emergência — leia **antes** de precisar |
| `/setup-kubernetes-deployment` · `/blue-green-deployment` | Do catálogo |
| `/setup-monitoring-observability` · `/deployment-monitoring` | Do catálogo |
| `/setup-automated-releases` · `/prepare-release` | Do catálogo |
| `/setup-docker-containers` · `/setup-ci-cd-pipeline` | Do catálogo |

---

## O que está instalado

**Arquitetura** — `cloud-architect` (845), `network-engineer` (442),
`microservices-architect` (81), `platform-engineer` (49).

**IaC** — `terraform-specialist` (380), `devops-iac-engineer` (158),
`terraform-engineer` (61), `se-gitops-ci-specialist` (41).

**Kubernetes e confiabilidade** — `monitoring-specialist` (403),
`vercel-deployment-specialist` (298), `kubernetes-specialist` (93),
`sre-engineer` (74), `devops-incident-responder` (33).

`sre-engineer` traz o conceito que muda a operação: **error budget**. Define quanto
de indisponibilidade é aceitável e transforma "está estável?" numa pergunta com
resposta numérica.

Detalhe: [KIT-DEVOPS-CLOUD.md](KIT-DEVOPS-CLOUD.md).

---

## MCPs

Nenhum funciona sem preparo — os dois ficam em `.mcp.optional.json`:

| Servidor | O que faz | O que precisa |
|---|---|---|
| `terraform` (122) | Registry, workspace, orquestração de run | Docker |
| `grafana` (119) | Dashboards e monitoramento | URL e credencial da sua instância |

---

## Limitações — este é o kit menos validado dos nove

1. **Downloads baixos em toda a linha.** `kubernetes-specialist` (93),
   `sre-engineer` (74), `terraform-engineer` (61), `devops-incident-responder` (33).
   Infraestrutura é onde errar custa mais caro — revise tudo antes de aplicar.

2. **Nunca aplique IaC sem `plan`.** `terraform apply` sem ler a saída do `plan` já
   destruiu banco de produção. O `CLAUDE.md` obriga a mostrar o `plan` e destacar
   tudo que aparece como `destroy`.

3. **Kubernetes é resposta errada para a maioria dos projetos.** Se você tem um
   monólito e três desenvolvedores, K8s adiciona um sistema distribuído inteiro ao
   seu problema. As skills assumem que a decisão já foi tomada — o `CLAUDE.md`
   instrui a IA a questionar.

4. **Nada aqui cobre rollback de banco.** Reverter código é fácil; reverter migração
   de schema não é. `blue-green-deployment` e `rollback-deploy` não tratam isso.

5. **Metade da categoria original é Azure** e ficou de fora. Se você usa Azure,
   `bicep-plan`, `azure-principal-architect` e outros valem a instalação.

---

## Arquivos

```
KIT-DEVOPS-CLOUD/
├── CLAUDE.md · README.md · KIT-DEVOPS-CLOUD.md
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/  skills/ 1 · agents/ 12 · commands/ 12
```
