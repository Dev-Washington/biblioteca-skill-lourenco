# Kit DevOps e Cloud — infraestrutura, Kubernetes, Terraform, observabilidade

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**25 componentes · 4.022 downloads somados.**

---

## 1. O recorte, e quando este kit não vale

O `KIT-DEVWEB-AITMPL` já tem o básico de DevOps: `senior-devops`, `docker-expert`,
`deployment-engineer`, `devops-engineer`, `devops-troubleshooter`, `/ci-setup`,
`/containerize-application`.

**Este kit só vale se você sair de PaaS.** Se você roda em Vercel, Railway ou
Render, o que está no `KIT-DEVWEB` cobre. Aqui entram Kubernetes, Terraform,
observabilidade e SRE — coisas que só existem quando você gerencia a própria infra.

A categoria `devops-infrastructure` tem 40 agents, mas **~15 são específicos de
Azure** (`azure-principal-architect`, `bicep-plan`, `arm-migration`,
`azure-verified-modules-*`). Instalei 12: os agnósticos de nuvem. Se você usa Azure,
vale instalar os que ficaram de fora.

---

## 2. Componentes

### Arquitetura de infra
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `devops-infrastructure/cloud-architect` | agent | Arquitetura de nuvem em escala | 845 |
| `devops-infrastructure/network-engineer` | agent | Rede em nuvem e híbrida | 442 |
| `devops-infrastructure/microservices-architect` | agent | Decompor monolito, sistema distribuído | 81 |
| `devops-infrastructure/platform-engineer` | agent | Plataforma interna de desenvolvimento | 49 |

### Infraestrutura como código
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `devops-infrastructure/terraform-specialist` | agent | Módulos, gestão de state | 380 |
| `devops-infrastructure/terraform-engineer` | agent | IaC multi-nuvem em escala | 61 |
| `development/devops-iac-engineer` | skill | Terraform, Kubernetes, plataformas de nuvem | 158 |
| `devops-infrastructure/se-gitops-ci-specialist` | agent | GitOps e CI | 41 |

### Kubernetes e confiabilidade
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `devops-infrastructure/kubernetes-specialist` | agent | Projetar, implantar e depurar cluster | 93 |
| `devops-infrastructure/sre-engineer` | agent | SLO, error budget, confiabilidade | 74 |
| `devops-infrastructure/monitoring-specialist` | agent | Métrica, alerta, observabilidade | 403 |
| `devops-infrastructure/devops-incident-responder` | agent | Resposta a incidente | 33 |
| `devops-infrastructure/vercel-deployment-specialist` | agent | Edge functions, middleware, deploy Vercel | 298 |

`sre-engineer` traz o conceito que muda a operação: **error budget**. Define quanto
de indisponibilidade é aceitável e transforma "está estável?" numa pergunta com
resposta numérica.

### Commands
`setup-kubernetes-deployment` (94) · `setup-automated-releases` (90) ·
`prepare-release` (88) · `rollback-deploy` (56) · `deployment-monitoring` (55) ·
`hotfix-deploy` (53) · `blue-green-deployment` (45) ·
`setup-monitoring-observability` (61) · `setup-docker-containers` (195) ·
`setup-ci-cd-pipeline` (86)

`rollback-deploy` e `hotfix-deploy` são os que você vai usar sob pressão. Leia antes
de precisar — não durante o incidente.

### MCPs
`devtools/terraform` (122) — registry, workspace, orquestração de run; **exige
Docker**. `devtools/grafana` (119) — dashboards; precisa de URL e credencial da sua
instância. Ambos em `.mcp.optional.json`.

---

## 3. Ressalvas honestas

1. **Downloads baixos em toda a linha.** `kubernetes-specialist` (93),
   `sre-engineer` (74), `terraform-engineer` (61), `devops-incident-responder` (33).
   É o kit **menos validado** dos nove. Infraestrutura é onde errar custa mais caro
   — revise tudo antes de aplicar.

2. **Nunca aplique IaC gerado sem `plan`.** `terraform apply` sem ler o `plan` já
   destruiu banco de produção. Isso vale para qualquer sugestão destas skills.

3. **Kubernetes é resposta errada para a maioria dos projetos.** Se você tem um
   monólito e três desenvolvedores, K8s adiciona um sistema distribuído inteiro ao
   seu problema. As skills não vão te dizer isso — elas assumem que a decisão já foi
   tomada.

4. **`blue-green-deployment` e `rollback-deploy` não cobrem o banco.** Reverter
   código é fácil; reverter migração de schema não é. Nenhum componente aqui trata
   isso — planeje separado.

5. **Metade da categoria é Azure.** Se você usa Azure, instale `bicep-plan`,
   `azure-principal-architect`, `azure-verified-modules-terraform` e os demais que
   ficaram de fora.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --agent devops-infrastructure/cloud-architect --yes
npx claude-code-templates@latest --agent devops-infrastructure/terraform-specialist --yes
npx claude-code-templates@latest --agent devops-infrastructure/monitoring-specialist --yes
npx claude-code-templates@latest --agent devops-infrastructure/sre-engineer --yes
npx claude-code-templates@latest --agent devops-infrastructure/kubernetes-specialist --yes
npx claude-code-templates@latest --mcp devtools/terraform --yes
```
