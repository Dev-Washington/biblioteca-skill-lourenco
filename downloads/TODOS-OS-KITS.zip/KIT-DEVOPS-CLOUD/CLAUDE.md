# Kit DevOps e Cloud

**1 skill, 12 agents e 10 commands** em `.claude/`, para infraestrutura
própria: Kubernetes, Terraform, observabilidade, SRE.

Fonte: [aitmpl.com](https://aitmpl.com/).

---

## Antes de usar: este kit é necessário?

O `KIT-DEVWEB-AITMPL` já cobre Docker, CI/CD e deploy. **Este kit só vale se o
usuário gerencia a própria infraestrutura.**

Se ele roda em Vercel, Railway ou Render, diga isso — e não proponha Kubernetes.
Adicionar orquestração de container a um projeto que não precisa é o erro mais caro
que este kit pode causar.

Pergunte antes de recomendar arquitetura: quantas pessoas no time, qual a carga
real, o que dói hoje.

---

## Regras de segurança operacional

**Nunca aplique IaC sem `plan`.** Toda sugestão de Terraform deve vir acompanhada de
`terraform plan`, e o usuário precisa ler a saída antes de aplicar. `apply` sem
`plan` já destruiu banco de produção.

**Marque o que é destrutivo.** Recurso que será recriado, volume que será apagado,
DNS que muda. Se o `plan` mostra `destroy` em algo com estado, **pare e destaque**.

**Reverter código é diferente de reverter banco.** `rollback-deploy` e
`blue-green-deployment` não cobrem migração de schema. Se o deploy inclui migração,
diga que o rollback não é automático e planeje separado.

**Antes de mexer em produção, confirme.** Não é formalidade: infraestrutura é onde
o erro é mais difícil de desfazer.

---

## Roteamento

| Assunto da tarefa | Use |
|---|---|
| Arquitetura de nuvem em escala | agent `cloud-architect` |
| Rede em nuvem e híbrida, VPC, peering | agent `network-engineer` |
| Decompor monolito, sistema distribuído | agent `microservices-architect` |
| Plataforma interna de desenvolvimento | agent `platform-engineer` |
| Terraform: módulo, state, multi-nuvem | agents `terraform-specialist`, `terraform-engineer`, skill `devops-iac-engineer` |
| GitOps, CI declarativo | agent `se-gitops-ci-specialist` |
| Kubernetes: projetar, implantar, depurar | agent `kubernetes-specialist`, command `/setup-kubernetes-deployment` |
| SLO, error budget, confiabilidade | agent `sre-engineer` |
| Métrica, alerta, observabilidade | agent `monitoring-specialist`, command `/setup-monitoring-observability` |
| Incidente em produção | agent `devops-incident-responder` |
| Vercel: edge function, middleware | agent `vercel-deployment-specialist` |
| Release automatizado, versionamento | commands `/setup-automated-releases`, `/prepare-release` |
| **Reverter um deploy** | command `/rollback-deploy` |
| **Correção urgente em produção** | command `/hotfix-deploy` |
| Deploy sem downtime | command `/blue-green-deployment` |
| Monitorar o deploy | command `/deployment-monitoring` |
| Docker, CI/CD | commands `/setup-docker-containers`, `/setup-ci-cd-pipeline` |

---

## Lacunas conhecidas

- **Metade da categoria original é Azure** e não foi instalada. Se o usuário usa
  Azure, diga que existem `bicep-plan`, `azure-principal-architect` e outros no
  catálogo.
- **Nada aqui cobre rollback de banco.** Migração de schema revertida é problema
  separado, e não resolvido.
- **Este é o kit menos validado dos nove** — vários componentes com menos de 100
  downloads. Diga quando estiver seguindo um pouco testado.

## Convenções

- Declare qual agent/command está usando.
- Toda mudança de infra: mostre o `plan`, destaque o destrutivo, confirme antes.
- Não recomende Kubernetes sem confirmar que o problema justifica.
