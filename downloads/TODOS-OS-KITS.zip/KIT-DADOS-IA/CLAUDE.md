# Kit Dados e IA — pipeline, análise, ML

**4 skills, 9 agents e 2 MCPs** em `.claude/`, para engenharia de dados, análise e
machine learning.

Fonte: [aitmpl.com](https://aitmpl.com/).

---

## Roteamento

| Assunto da tarefa | Use |
|---|---|
| Sistema de IA ponta a ponta — entrada generalista | agent `ai-engineer` |
| Pipeline, ETL/ELT, dbt, infraestrutura de dados | agent `data-engineer`, skill `senior-data-engineer` |
| Modelo preditivo, padrão em dados, estatística | agent `data-scientist`, skill `senior-data-scientist` |
| Inferência causal, experimentação, teste A/B | skill `senior-data-scientist` |
| ML em produção: treino, serving, retreino | agent `ml-engineer`, skill `senior-ml-engineer` |
| Infra de ML, CI/CD de modelo | agent `mlops-engineer` |
| Texto, NLP em produção | agent `nlp-engineer` |
| Imagem e vídeo, detecção, segmentação | agent `computer-vision-engineer`, skill `senior-computer-vision` |
| Insight de negócio, dashboard, relatório | agent `data-analyst` |
| Administrar Postgres | agent `postgresql-dba` |

---

## Regras

**Olhe o dado antes de propor modelo.** Quantas linhas, quantas colunas, quanto
está faltando, como está distribuído, há vazamento entre treino e teste. A maioria
dos projetos de ML morre no dataset, não no algoritmo — e nenhuma skill conserta
dado ruim.

**Correlação não é causa.** Se a pergunta do usuário é sobre efeito ("aumentar X
aumenta Y?"), correlação não responde. Use skill `senior-data-scientist` —
inferência causal, desenho experimental. Apresentar correlação como causa é o erro
mais caro em análise de negócio.

**Comece pelo baseline mais simples.** Média, regra fixa, regressão linear. Se um
modelo complexo não bate o baseline com folga, ele não vale o custo de manutenção.
Diga qual é o baseline e quanto o modelo ganhou.

**Declare a incerteza.** Intervalo de confiança, tamanho da amostra, período
coberto. Número sem contexto de incerteza vira decisão errada.

**Dado pessoal tem lei.** Pipeline que processa dado de cliente esbarra em LGPD:
base legal, minimização, retenção, anonimização. O `KIT-SECURITY-SISTEM-AITMPL` tem
as skills. Levante isso antes de construir, não depois.

## Convenções

- Declare qual skill/agent está usando.
- Mostre o dado: primeiras linhas, contagem, distribuição. Não descreva sem mostrar.
- Se um número não pôde ser calculado, diga qual e por quê. Não estime em silêncio.
