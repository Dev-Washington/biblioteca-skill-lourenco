#!/usr/bin/env bash
# Verifica se o KIT-DADOS-IA esta completo.
cd "$(dirname "${BASH_SOURCE[0]}")"
ok=0; fail=0
chk(){ if [ -e "$2" ]; then ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }
echo "== Skills (4) =="
for s in senior-computer-vision senior-data-engineer senior-data-scientist senior-ml-engineer; do chk "skill $s" ".claude/skills/$s/SKILL.md"; done
echo "== Agents (9) =="
for a in ai-engineer computer-vision-engineer data-analyst data-engineer data-scientist ml-engineer mlops-engineer nlp-engineer postgresql-dba; do chk "agent $a" ".claude/agents/$a.md"; done
echo "== Commands (2) =="
for c in analisar-dados kit-dados; do chk "/$c" ".claude/commands/$c.md"; done
echo "== Config =="
chk "CLAUDE.md" "CLAUDE.md"
chk "README.md" "README.md"
chk "KIT-DADOS-IA.md" "KIT-DADOS-IA.md"
chk ".mcp.json" ".mcp.json"
chk ".mcp.optional.json" ".mcp.optional.json"
node -e 'JSON.parse(require("fs").readFileSync(".mcp.json","utf8"))' 2>/dev/null \
  && echo "  .mcp.json: JSON valido" || { echo "  .mcp.json: INVALIDO"; fail=$((fail+1)); }

echo
echo "  ativos:   $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo "  opcionais: $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.optional.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo
echo "== Ferramentas =="
for t in node npx; do
  if command -v "$t" >/dev/null 2>&1; then echo "  ok       $t"; else echo "  ausente  $t"; fi
done
echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
