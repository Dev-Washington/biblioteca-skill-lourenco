---
description: Mostra o que este kit tem e o que se aplica ao seu problema de dados
---

Leia `CLAUDE.md` e apresente, em português:

1. Verifique o que existe **de fato**: `ls .claude/skills` · `ls .claude/agents` ·
   `cat .mcp.json`. Não liste nada que não esteja lá.

2. Resuma agrupado: pipeline/engenharia, análise/estatística, ML em produção,
   visão computacional e NLP.

3. Se o usuário passou um assunto ($ARGUMENTS), diga o que se aplica. Se não passou,
   pergunte qual a **pergunta de negócio** por trás — não a técnica. "Quero um
   modelo de ML" quase nunca é o problema real.

Seja direto.
