---
description: Analisa um dataset — inspeciona antes de concluir, declara incerteza
---

Dado / pergunta: $ARGUMENTS

1. **Entenda a pergunta de negócio.** Se $ARGUMENTS trouxer só a técnica ("rode um
   modelo"), pergunte qual decisão depende do resultado. Análise sem decisão
   associada é desperdício.

   Pergunte também: **a pergunta é de correlação ou de efeito?** "Quem usa X compra
   mais" é correlação. "Se eu aumentar X, vendo mais" é efeito, e exige desenho
   diferente.

2. **Olhe o dado antes de qualquer conclusão.** Mostre ao usuário:
   - linhas, colunas, tipos
   - percentual faltante por coluna
   - distribuição das variáveis principais
   - período coberto e granularidade
   - duplicata, outlier, valor impossível

   Se o dado tiver problema que invalide a análise, **pare e diga** em vez de
   analisar mesmo assim.

3. **Baseline primeiro.** Média, regra simples, modelo linear. Ele é o piso.

4. **Analise** — agent `data-analyst` para negócio, skill `senior-data-scientist`
   para estatística e inferência causal.

5. **Declare a incerteza.** Intervalo de confiança, tamanho de amostra, período. E
   diga explicitamente o que a análise **não** permite concluir.

6. **Se houver dado pessoal**, levante LGPD antes de seguir — base legal, retenção,
   anonimização.

Nunca apresente correlação como causa. Se o usuário pedir isso, explique a diferença.
