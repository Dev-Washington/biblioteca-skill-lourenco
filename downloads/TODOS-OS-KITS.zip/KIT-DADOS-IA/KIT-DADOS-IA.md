# Kit Dados e IA — pipeline, análise, ML

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**15 componentes · 8.514 downloads somados.**

---

## 1. O recorte

A categoria `data-ai` tem **40 agents**, mas a maioria é nicho de ecossistema
Microsoft — Power BI, Power Platform, Azure, .NET, MS SQL. Instalei **9**: os que
servem para qualquer stack.

Somei as 4 skills `senior-*` de dados da categoria `development`, que são mais
baixadas que os agents equivalentes.

---

## 2. Componentes

### Agents
| Componente | O que entrega | Downloads |
|---|---|---|
| `data-ai/ai-engineer` | Ponto de entrada generalista para sistema de IA ponta a ponta | 2.154 |
| `data-ai/data-scientist` | Padrões em dados, modelo preditivo, extração de insight | 907 |
| `data-ai/data-engineer` | Pipeline de dados, transformação dbt, ETL/ELT | 859 |
| `data-ai/ml-engineer` | ML em produção: treino, serving, retreino automático | 556 |
| `data-ai/computer-vision-engineer` | Detecção de objeto, segmentação, análise de imagem/vídeo | 303 |
| `data-ai/mlops-engineer` | Infra de ML, CI/CD para modelo | 291 |
| `data-ai/nlp-engineer` | Pipeline de texto, NLP em produção | 252 |
| `data-ai/data-analyst` | Insight de dado de negócio, dashboard, análise estatística | 198 |
| `data-ai/postgresql-dba` | Administração de Postgres | 115 |

### Skills
| Componente | O que entrega | Downloads |
|---|---|---|
| `development/senior-data-engineer` | Pipeline escalável, ETL/ELT, infraestrutura de dados | 629 |
| `development/senior-data-scientist` | Modelagem estatística, experimentação, inferência causal | 540 |
| `development/senior-ml-engineer` | Produtizar modelo, MLOps, sistema de ML escalável | 201 |
| `development/senior-computer-vision` | Processamento de imagem e vídeo, IA visual | 131 |

`senior-data-scientist` cobre **inferência causal** — a diferença entre "correlaciona"
e "causa". É o que separa análise que sustenta decisão de análise que engana.

### MCPs
Ambos precisam de credencial: `database/postgresql-integration` (1.299) e
`devtools/elasticsearch` (79).

---

## 3. Ressalvas honestas

1. **A categoria é dominada por nicho Microsoft.** Dos 40 agents, ~15 são Power BI,
   Azure, .NET e MS SQL. Se você usa esse ecossistema, vale instalar os que deixei
   de fora: `power-bi-dax-expert`, `power-bi-data-modeling-expert`,
   `ms-sql-dba`, `power-platform-expert`.

2. **Sobreposição entre skill e agent.** `data-scientist`, `data-engineer` e
   `ml-engineer` existem nas duas formas, com nomes quase idênticos. Instalei ambos
   — a skill para consulta, o agent para tarefa longa.

3. **Nenhum componente trata privacidade de dado pessoal.** Pipeline que processa
   dado de cliente esbarra em LGPD. O `KIT-SECURITY-SISTEM-AITMPL` tem
   `data-privacy-compliance` e `gdpr-dsgvo-expert`.

4. **Skill de ML não substitui dado.** Nenhuma dessas melhora um dataset pequeno,
   enviesado ou mal rotulado — e é aí que a maioria dos projetos de ML morre.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --agent data-ai/ai-engineer --yes
npx claude-code-templates@latest --agent data-ai/data-engineer --yes
npx claude-code-templates@latest --agent data-ai/data-scientist --yes
npx claude-code-templates@latest --skill development/senior-data-engineer --yes
npx claude-code-templates@latest --skill development/senior-data-scientist --yes
```
