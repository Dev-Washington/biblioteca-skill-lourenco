---
description: Mostra o que o Kit DevWeb+Motion tem instalado e o que se aplica ao seu caso
---

Leia `CLAUDE.md` na raiz e apresente ao usuário, em português:

1. Verifique o que existe **de fato** em disco antes de responder:
   - `ls .claude/skills` · `ls .claude/agents` · `cat .mcp.json`
   Não liste nada que não esteja lá.

2. Resuma agrupado: animação, construir a página, conteúdo/conversão, qualidade,
   Figma/vídeo. Destaque que **`web-motion` é a skill de referência para animação**
   e que ela foi escrita para este kit — não vem do aitmpl.com.

3. Se o usuário passou um assunto como argumento ($ARGUMENTS), diga exatamente o
   que se aplica e por quê. Se não passou, pergunte o que ele quer construir
   (landing page, site institucional, portfólio, página de produto) e se já tem
   design, copy ou imagens.

Seja direto. Não repita a tabela inteira do CLAUDE.md.
