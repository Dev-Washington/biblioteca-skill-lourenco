---
description: Audita as animações do projeto — performance, acessibilidade e propósito
---

Alvo: $ARGUMENTS  (se vazio, o projeto atual)

Encontre todas as animações do projeto e audite. Use skill `web-motion` como
critério.

1. **Encontre.** Varra por `transition`, `@keyframes`, `animation`, `.animate(`,
   `gsap`, `motion.`, `framer-motion`, `ScrollTrigger`, `animation-timeline`,
   `startViewTransition`. Liste o que achou e onde.

2. **Audite cada uma:**

   | Verificação | Falha se |
   |---|---|
   | Propriedade animada | anima `width`, `height`, `top`, `left`, `margin`, `box-shadow` |
   | Propósito | não dá para nomear a função (feedback/orientação/continuidade/atenção) |
   | Duração | grande e rápido demais, ou pequeno e lento demais |
   | Easing | `ease` ou `linear` onde deveria ter curva com intenção |
   | Reduced motion | não há bloco `prefers-reduced-motion` cobrindo |
   | Fallback sem JS | conteúdo começa em `opacity: 0` sem `.js-ready` ou equivalente |
   | `will-change` | estático em CSS, em muitos elementos, sem remoção |
   | Handler de scroll | escreve estilo direto, sem `requestAnimationFrame` |
   | Foco | elemento invisível continua focável |
   | Touch | tilt/parallax ativo em `pointer: coarse` |

3. **Meça, não suponha.** Com o MCP `chrome-devtools`: performance trace com CPU
   em throttle 4×, procure long tasks e "Recalculate Style" repetido durante a
   animação. Sem medição, marque o achado como "suspeita", não como confirmado.

4. **Relatório** ordenado por impacto real. Para cada item: arquivo e linha, o que
   está errado, o efeito prático (trava no celular / causa náusea / some sem JS),
   e a correção concreta.

5. Feche com o que **não** foi possível verificar e por quê.

Não conserte nada sem o usuário pedir — este comando audita. Para aplicar as
correções, ele pede depois.
