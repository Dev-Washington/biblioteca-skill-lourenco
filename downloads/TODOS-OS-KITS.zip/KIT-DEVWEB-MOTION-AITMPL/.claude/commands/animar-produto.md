---
description: Anima uma imagem de produto anexada — escolhe a técnica pela imagem real
---

Produto / imagem: $ARGUMENTS

1. **Olhe a imagem antes de qualquer coisa.** Use a ferramenta Read no arquivo. Se
   o usuário não anexou nem informou o caminho, peça agora. Não escolha técnica no
   escuro e não descreva o que você não viu.

   Ao ver, responda para si: tem fundo ou é PNG recortado? foto ou render? qual o
   ângulo? há mais de uma imagem? qual a resolução?

2. **Pergunte a sensação.** Leveza, solidez, precisão, luxo, velocidade? Isso muda
   mais o resultado do que a escolha técnica. E confirme onde o produto fica —
   hero, meio da página, grade.

3. **Escolha o caso** em `web-motion/referencias/produto-imagem.md`:
   - PNG recortado → tilt 3D, float com sombra acompanhando, sheen, reveal clip-path
   - Foto com fundo → Ken Burns, ou remova o fundo antes (skill `imagegen`, exige
     chave OpenAI — confirme que existe antes de prometer)
   - Camadas separadas → parallax real, o efeito mais convincente
   - Vários ângulos → spin 360 por arraste
   - Modelo .glb → skill `3d-web-experience`

4. **Otimize a imagem antes de animar.** AVIF + WebP + fallback, `width`/`height`
   no `<img>`, `fetchpriority="high"` se for hero. Uma imagem de 4 MB anula
   qualquer ganho de animação.

5. **Implemente** seguindo skill `web-motion`: só `transform` e `opacity`,
   `prefers-reduced-motion` tratado, tilt e parallax desligados em touch.

6. **Verifique no browser** com o MCP `chrome-devtools`/`playwright`: screenshot,
   interação, performance trace. Se não houver MCP, diga que não verificou.

Entregue o `alt` descrevendo o produto de verdade — não "imagem do produto".
