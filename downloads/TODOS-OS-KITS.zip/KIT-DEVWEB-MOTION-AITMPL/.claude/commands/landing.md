---
description: Constrói uma landing page completa, com animação, na ordem certa
---

Pedido do usuário: $ARGUMENTS

Não comece a escrever código antes do passo 2.

1. **Entenda antes de construir.** Se $ARGUMENTS for vago, pergunte:
   - O que é o produto/serviço e para quem
   - Qual a ação única que a página deve gerar (a landing tem **um** objetivo)
   - Já existe marca — logo, cor, fonte? Já existe copy? Já existe imagem?
   - Stack: HTML puro, Astro, Next.js, outro?

   Sem isso, você vai gerar mais uma página genérica.

2. **Estrutura e copy** — skill `copywriting` para o texto, skill `page-cro` para a
   ordem das seções. **Copy antes de layout**: layout que nasce do texto real fica
   certo; texto encaixado em layout pronto fica torto.

3. **Direção visual** — skill `ui-ux-pro-max` para escolher estilo, paleta e par de
   fontes. Se o usuário quer que pareça caro, nível agência, ou reclamou de
   "cara de IA", use skill `premium-web-design` (ela gera React — se o stack for
   outro, avise que vai traduzir).

4. **Construa a página estática primeiro. Sem animação nenhuma.**
   Ela precisa estar completa, legível e correta parada. Animação é camada, não
   estrutura. Use skill `frontend-design` e a skill do stack (`astro`,
   `nextjs-app-router-patterns`, `tailwind-patterns`, `shadcn`).

5. **Só então anime** — skill `web-motion`. Para cada animação, nomeie a função
   (feedback, orientação, continuidade, atenção). Se não conseguir nomear, corte.
   Comece pelo hero e pelos reveals de seção; microinterações depois.

6. **Verifique de verdade.** Suba o dev server, e com o MCP `chrome-devtools` ou
   `playwright`: screenshot do topo, role até o fim, screenshot de novo. Confirme
   que os reveals dispararam e que nada ficou invisível. Grave um performance trace.
   Se não houver MCP disponível, diga que não conseguiu verificar visualmente.

7. **Feche com o checklist** de `web-motion` (reduced motion, sem JS, 360 px,
   60 fps) e com skill `web-performance-optimization` para LCP e bundle.

Ao final, diga o que ficou pendente e o que precisa do usuário (imagens reais,
domínio, analytics).
