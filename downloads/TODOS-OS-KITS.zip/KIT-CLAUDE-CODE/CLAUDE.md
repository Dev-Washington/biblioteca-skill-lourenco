# Kit Claude Code — criar skills, agents, MCPs e hooks

**8 skills, 12 agents e 1 MCP** em `.claude/`, para construir componentes do
Claude Code: skills, agents, slash commands, hooks e servidores MCP.

Fonte: [aitmpl.com](https://aitmpl.com/).

---

## Roteamento

| Assunto da tarefa | Use |
|---|---|
| Criar skill nova, melhorar existente, medir performance | skill `skill-creator` |
| Criar agent ou subagent | skill `agent-development`, agent `agent-expert` |
| Criar slash command | agent `command-expert` |
| Criar hook (PreToolUse, PostToolUse, Stop) | skill `hook-development` |
| Construir servidor MCP | skill `mcp-builder`, agent `mcp-server-architect` |
| Protocolo MCP, detalhe de especificação | agent `mcp-protocol-specialist` |
| Integrar MCP existente no projeto | skill `mcp-integration`, agent `mcp-expert` |
| Testar servidor MCP | agent `mcp-testing-engineer` |
| Deploy de servidor MCP | agent `mcp-deployment-orchestrator` |
| Encontrar MCP que já existe | agent `mcp-registry-navigator` |
| Descobrir e instalar agents | agent `agent-installer` |
| Tarefa longa, muitos arquivos, risco de estourar contexto | agent `context-manager` |
| Executar plano com tarefas independentes | skill `subagent-driven-development` |
| Configuração do Claude Code, templates de prompt | skill `claude-code-guide` |

---

## Regras ao criar componentes

**Skill precisa de `name` e `description` no frontmatter.** A `description` é o que
decide se a skill é ativada — escreva os gatilhos reais que o usuário digitaria, não
um resumo do conteúdo. Uma skill excelente com descrição vaga nunca é chamada.

**Skill grande vira SKILL.md + referências.** Um arquivo de 60 KB entra inteiro no
contexto. Divida: `SKILL.md` com a árvore de decisão e as regras, `referencias/*.md`
com o detalhe que só é lido quando necessário.

**Hook bloqueia trabalho de verdade.** Teste antes de instalar: monte o payload JSON
de exemplo e rode o script na mão. Um hook que recusa o que deveria passar é pior
que nenhum hook.

**Não confie na memória para sintaxe.** A especificação do MCP e o formato de hook
do Claude Code mudam. Confirme na documentação oficial
(`docs.claude.com/en/docs/claude-code`) ou use o MCP `context7`.

**Antes de criar, procure.** Muita coisa já existe no catálogo (872 skills, 422
agents). Use `agent-installer` ou `mcp-registry-navigator` antes de escrever do zero.

## Convenções

- Declare qual skill/agent está usando antes de aplicar a recomendação.
- Componente novo precisa ser testado, não só escrito. Diga como testou.
- Não instale componentes do aitmpl.com sem o usuário pedir.
