---
description: Constrói um servidor MCP do zero — arquitetura, implementação, teste, deploy
---

Servidor desejado: $ARGUMENTS

1. **Verifique se já existe** — agent `mcp-registry-navigator`. O catálogo tem 101
   MCPs e há centenas fora dele. Construir o que já existe é desperdício.

2. **Defina o contrato antes do código** — skill `mcp-builder` + agent
   `mcp-server-architect`. Quais ferramentas o servidor expõe, que argumentos
   recebem, o que retornam. Ferramenta mal desenhada faz o modelo alucinar
   argumento — o contrato importa mais que a implementação.

3. **Confirme a especificação atual** — agent `mcp-protocol-specialist`. A spec do
   MCP muda. Não escreva de memória; se o MCP `context7` estiver configurado, use.

4. **Implemente** — agent `mcp-developer`.

5. **Teste** — agent `mcp-testing-engineer`. Rode o servidor, conecte, chame cada
   ferramenta. Servidor MCP que não foi conectado uma vez não está pronto.

6. **Deploy** — agent `mcp-deployment-orchestrator`, se for para produção.

7. **Segurança**: se o servidor toca dado sensível ou credencial, o
   `KIT-SECURITY-SISTEM-AITMPL` tem o agent `mcp-security-auditor` (OAuth, RBAC).

Ao final, mostre o bloco de `.mcp.json` para o usuário conectar.
