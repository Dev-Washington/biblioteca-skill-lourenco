---
description: Cria uma skill nova do zero, com estrutura e teste
---

Skill desejada: $ARGUMENTS

Use skill `skill-creator`.

1. **Procure antes de criar.** Verifique se algo no catálogo já cobre isso. Se
   cobrir parcialmente, pergunte ao usuário se prefere estender o existente.

2. **Defina o gatilho antes do conteúdo.** A `description` do frontmatter decide se
   a skill é ativada. Escreva as frases reais que o usuário digitaria — verbos,
   nomes de ferramenta, sinônimos. Uma skill excelente com descrição vaga nunca é
   chamada. Mostre a `description` ao usuário e confirme antes de seguir.

3. **Estruture pelo tamanho:**
   - Skill pequena (< 10 KB) → só `SKILL.md`
   - Skill grande → `SKILL.md` com árvore de decisão e regras + `referencias/*.md`
     com o detalhe. Um arquivo de 60 KB entra inteiro no contexto toda vez.

4. **Escreva o conteúdo.** Regras acionáveis, não teoria. Se há uma decisão a tomar,
   dê a árvore. Se há armadilha, diga qual e a consequência. Código que dá para
   copiar vale mais que explicação.

5. **Declare as lacunas.** O que a skill **não** cobre é tão importante quanto o que
   cobre — evita a IA inventar que sabe.

6. **Teste.** Instale em `.claude/skills/`, abra uma sessão e faça a pergunta que
   deveria ativá-la. Se não ativar, o problema está na `description`. Diga ao
   usuário se conseguiu testar ou não.
