---
description: Mostra o que este kit tem e o que se aplica ao que você quer criar
---

Leia `CLAUDE.md` na raiz e apresente ao usuário, em português:

1. Verifique o que existe **de fato** em disco antes de responder:
   `ls .claude/skills` · `ls .claude/agents` · `cat .mcp.json`
   Não liste nada que não esteja lá.

2. Resuma agrupado: criar componentes (skill, agent, command, hook), construir MCP,
   e operar o Claude Code.

3. Se o usuário passou um assunto ($ARGUMENTS), diga o que se aplica. Se não passou,
   pergunte o que ele quer criar — skill, agent, command, hook ou servidor MCP — e
   **verifique antes se já existe algo no catálogo que resolva**, usando o agent
   `agent-installer` ou `mcp-registry-navigator`. Criar do zero o que já existe é o
   erro mais comum aqui.

Seja direto.
