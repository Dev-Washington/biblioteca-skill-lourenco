# Kit Claude Code — criar skills, agents, MCPs e hooks

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**21 componentes · 19.224 downloads somados.** É o kit que constrói os outros kits.

---

## 1. Por que este kit

Os outros kits **consomem** componentes do catálogo. Este **produz**.

Quando o catálogo não tem o que você precisa — como aconteceu com animação web, onde
as 872 skills não cobriam GSAP nem `prefers-reduced-motion` — a saída é escrever a
skill você mesmo. `skill-creator` (4.534 downloads, a 6ª skill mais baixada do
catálogo) existe exatamente para isso: criar, modificar e **medir** a performance de
uma skill.

O mesmo vale para MCP: se nenhum servidor do catálogo faz o que você precisa,
`mcp-builder` (1.388) ensina a construir um.

---

## 2. Componentes

### Criar componentes
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development/skill-creator` | skill | Criar skill nova, melhorar existente, medir performance | 4.534 |
| `development/mcp-builder` | skill | Construir servidor MCP de qualidade | 1.388 |
| `development/agent-development` | skill | Criar agent/subagent, frontmatter, ferramentas | 612 |
| `development/hook-development` | skill | PreToolUse, PostToolUse, Stop, validação de tool | 60 |
| `development/mcp-integration` | skill | Adicionar e configurar MCP em plugin | 134 |
| `expert-advisors/agent-expert` | agent | Especialista em design de agent | 426 |
| `development-tools/command-expert` | agent | Design de slash command | 541 |

### Operar o Claude Code
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development-tools/context-manager` | agent | Gestão de contexto em fluxo multi-agente e tarefa longa | 2.987 |
| `development-tools/mcp-expert` | agent | Integração MCP no sistema de componentes | 1.763 |
| `development/using-superpowers` | skill | Como encontrar e usar skills — exige invocar a skill antes de agir | 690 |
| `development/subagent-driven-development` | skill | Executar plano com tarefas independentes na mesma sessão | 151 |
| `ai-research/claude-code-guide` | skill | Guia de configuração, templates de prompt | 208 |
| `expert-advisors/agent-installer` | agent | Descobrir e instalar agents | 89 |

### Time de MCP — 7 agents
`mcp-server-architect` (431) · `mcp-integration-engineer` (307) ·
`mcp-deployment-orchestrator` (276) · `mcp-testing-engineer` (223) ·
`mcp-protocol-specialist` (203) · `mcp-registry-navigator` (172) ·
`mcp-developer` (93)

Um time completo para construir um servidor MCP do zero: arquitetura → protocolo →
implementação → teste → deploy. `mcp-security-auditor` do mesmo time já está no
`KIT-SECURITY-SISTEM-AITMPL`.

### MCP
`devtools/context7` (3.936) — documentação atualizada da fonte, por versão. Útil
aqui porque a especificação do MCP e a API do Claude Code mudam; trabalhar de
memória sobre elas gera código que não roda.

---

## 3. Ressalvas honestas

1. **`hook-development` tem 60 downloads.** É a skill mais importante do kit para
   quem quer automação que age sozinha, e uma das menos usadas. Trate como ponto de
   partida e teste cada hook antes de confiar — hook mal escrito bloqueia seu
   próprio trabalho.

2. **O catálogo é do `claude-code-templates`, não da Anthropic.** As skills refletem
   o entendimento da comunidade sobre o formato de skill/agent/hook, que evolui.
   Antes de seguir um detalhe de sintaxe, confirme na documentação oficial —
   `docs.claude.com/en/docs/claude-code`.

3. **7 agents de MCP é muito para a maioria dos casos.** Se você só quer um servidor
   MCP simples, `mcp-builder` (skill) resolve sozinho. O time completo faz sentido
   em servidor que vai para produção com múltiplos consumidores.

4. **`context7` exige chave de API.** Fica em `.mcp.optional.json`.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --skill development/skill-creator --yes
npx claude-code-templates@latest --skill development/mcp-builder --yes
npx claude-code-templates@latest --skill development/agent-development --yes
npx claude-code-templates@latest --skill development/hook-development --yes
npx claude-code-templates@latest --agent development-tools/context-manager --yes
npx claude-code-templates@latest --agent development-tools/mcp-expert --yes
npx claude-code-templates@latest --agent development-tools/command-expert --yes
npx claude-code-templates@latest --agent expert-advisors/agent-expert --yes
```

> A API do GitHub limita a 60 requisições/hora sem autenticação. Este kit foi
> instalado clonando o repositório, que não passa pela API REST.
