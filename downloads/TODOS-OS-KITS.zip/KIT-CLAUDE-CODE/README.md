# Kit Claude Code

**8 skills, 12 agents, 3 commands e 1 MCP** para criar componentes do Claude Code:
skills, agents, slash commands, hooks e servidores MCP.

Origem: [aitmpl.com](https://aitmpl.com/) · **21 componentes, 19.224 downloads somados.**

---

## Por que este kit vem primeiro

Os outros kits consomem componentes do catálogo. Este produz.

Quando o catálogo não tem o que você precisa — como aconteceu com animação web, onde
nenhuma das 872 skills cobria GSAP nem `prefers-reduced-motion` — a saída é escrever
você mesmo. `skill-creator` (4.534 downloads) existe para isso: criar, melhorar e
**medir** uma skill.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-claude-code`.

Ou instale num projeto existente:

```bash
./install.sh /caminho/do/seu/projeto
./check.sh                             # conferir
```

### Windows (PowerShell)

```powershell
.\install.ps1 C:\caminho\do\seu\projeto
```

Se o Windows bloquear a execução do script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Isso libera só a sessão atual — não altera a política da máquina.

### macOS e Linux

```bash
chmod +x install.sh check.sh    # só na primeira vez
./install.sh /caminho/do/seu/projeto
./check.sh
```

O `install.ps1` também roda no macOS e no Linux, se você tiver PowerShell 7+.

O `install.sh` não sobrescreve nada: `CLAUDE.md` existente ganha `@import`,
`.mcp.json` é mesclado. Rodar duas vezes não duplica.

---

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-claude-code [assunto]` | Mostra o que tem e o que se aplica ao seu caso |
| `/nova-skill [descrição]` | Cria skill do zero: gatilho → estrutura → conteúdo → teste |
| `/novo-mcp [descrição]` | Servidor MCP: verificar se existe → contrato → spec → implementar → testar |

Os dois últimos começam **procurando se já existe**. Criar do zero o que o catálogo
já tem é o erro mais comum aqui.

---

## O que está instalado

**Criar componentes** — `skill-creator` (4.534), `mcp-builder` (1.388),
`agent-development` (612), `command-expert` (541), `agent-expert` (426),
`mcp-integration` (134), `hook-development` (60).

**Operar o Claude Code** — `context-manager` (2.987), `mcp-expert` (1.763),
`using-superpowers` (690), `claude-code-guide` (208),
`subagent-driven-development` (151), `agent-installer` (89).

**Time de MCP (7 agents)** — `mcp-server-architect` (431),
`mcp-integration-engineer` (307), `mcp-deployment-orchestrator` (276),
`mcp-testing-engineer` (223), `mcp-protocol-specialist` (203),
`mcp-registry-navigator` (172), `mcp-developer` (93).

O 8º agent do time, `mcp-security-auditor`, já está no `KIT-SECURITY-SISTEM-AITMPL`.

Detalhe e justificativa: [KIT-CLAUDE-CODE.md](KIT-CLAUDE-CODE.md).

---

## MCP

`.mcp.json` está **vazio** — este kit não tem MCP que funcione sem configuração.

`.mcp.optional.json` traz `context7` (3.936 downloads), que precisa de chave de API.
Vale configurar aqui: a especificação do MCP e o formato de hook mudam, e `context7`
puxa a documentação da fonte em vez de você trabalhar de memória.

---

## Limitações

1. **`hook-development` tem só 60 downloads.** É a skill mais importante do kit para
   automação e uma das menos usadas do catálogo. Teste cada hook na mão antes de
   instalar — hook mal escrito bloqueia seu próprio trabalho.

2. **O catálogo é da comunidade, não da Anthropic.** As skills refletem o
   entendimento de terceiros sobre o formato de skill/agent/hook, que evolui. Para
   detalhe de sintaxe, confirme em `docs.claude.com/en/docs/claude-code`.

3. **7 agents de MCP é exagero para caso simples.** Para um servidor pequeno, a
   skill `mcp-builder` resolve sozinha.

---

## Arquivos

```
KIT-CLAUDE-CODE/
├── CLAUDE.md              contexto automático: roteamento e regras de criação
├── README.md              este arquivo
├── KIT-CLAUDE-CODE.md     análise do catálogo
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/
    ├── skills/   8    ├── agents/  12    └── commands/  3
```
