#!/usr/bin/env bash
# Verifica se o kit está completo e quais ferramentas externas faltam.
cd "$(dirname "${BASH_SOURCE[0]}")"
ok=0; fail=0
chk(){ if [ -e "$2" ]; then ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }

echo "== Skills (43) =="
for s in senior-architect senior-frontend senior-backend senior-fullstack senior-devops senior-qa \
  code-reviewer clean-code brainstorming writing-plans systematic-debugging error-resolver \
  test-driven-development testing-patterns webapp-testing software-architecture api-patterns \
  api-integration-specialist database-design postgres-best-practices docker-expert \
  nextjs-best-practices nodejs-best-practices typescript-expert python-patterns \
  backend-dev-guidelines frontend-dev-guidelines git-commit-helper nestjs-expert performance seo \
  react-best-practices web-performance-optimization nextjs-app-router-patterns shadcn \
  tanstack-query-expert zod-validation-expert react-state-management astro progressive-web-app \
  supabase-postgres-best-practices postgresql database-migration; do
  chk "skill $s" ".claude/skills/$s/SKILL.md"; done

echo "== Agents (20) =="
for a in frontend-developer code-reviewer backend-architect fullstack-developer debugger \
  database-architect python-pro test-engineer typescript-pro architect-review error-detective \
  devops-engineer documentation-expert deployment-engineer javascript-pro database-optimization \
  sql-pro devops-troubleshooter performance-profiler api-architect; do
  chk "agent $a" ".claude/agents/$a.md"; done

echo "== Commands do catálogo (20) =="
for c in code-review ultra-think refactor-code explain-code debug-error generate-tests test-coverage \
  commit create-pr create-architecture-documentation update-docs generate-api-documentation \
  add-changelog containerize-application ci-setup design-database-schema design-rest-api \
  setup-linting performance-audit optimize-database-performance; do
  chk "/$c" ".claude/commands/$c.md"; done

echo "== Commands próprios do kit (5) =="
for c in kit-devweb novo-projeto feature investigar revisar; do chk "/$c" ".claude/commands/$c.md"; done

echo "== Hooks =="
for h in conventional-commits.py prevent-direct-push.py; do chk "script $h" ".claude/hooks/$h"; done
if [ -f .claude/settings.json ]; then
  n=$(node -e 'const s=JSON.parse(require("fs").readFileSync(".claude/settings.json","utf8"));let n=0;for(const a of Object.values(s.hooks||{}))for(const e of a)n+=(e.hooks||[]).length;console.log(n)' 2>/dev/null || echo 0)
  echo "  $n hook(s) registrados em settings.json"
  node -e 'JSON.parse(require("fs").readFileSync(".claude/settings.json","utf8"))' 2>/dev/null \
    && echo "  settings.json: JSON válido" || { echo "  settings.json: INVÁLIDO"; fail=$((fail+1)); }
else echo "  FALTA .claude/settings.json"; fail=$((fail+1)); fi

echo "== Config =="
chk "CLAUDE.md" "CLAUDE.md"; chk ".mcp.json" ".mcp.json"; chk ".mcp.optional.json" ".mcp.optional.json"

echo
echo "  total: $(ls .claude/skills 2>/dev/null|wc -l|tr -d ' ') skills, \
$(ls .claude/agents 2>/dev/null|wc -l|tr -d ' ') agents, \
$(ls .claude/commands 2>/dev/null|wc -l|tr -d ' ') commands"

echo
echo "== Ferramentas externas =="
dep(){ if command -v "$1" >/dev/null 2>&1; then echo "  ok       $1 — $2"; else echo "  ausente  $1 — $2 ($3)"; fi; }
dep node    "necessário para tudo"                  "https://nodejs.org"
dep python3 "hooks de git"                          "vem com o macOS"
dep git     "hooks de commit e push"                "xcode-select --install"
echo "  -- usadas pelos hooks lint-on-save e smart-formatting (falham em silêncio sem elas) --"
dep npx     "roda eslint e prettier"                "vem com o node"
dep black   "formata Python"                        "pipx install black"
dep gofmt   "formata Go"                            "instale o Go"
echo "  -- opcional --"
dep uv      "MCP serena"                            "brew install uv"

echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
