---
description: Investiga um bug com método — causa raiz antes de correção
---

Problema: $ARGUMENTS

Use skill `systematic-debugging`. A regra dela: **investigar antes de propor
correção.** Não chute, não conserte o sintoma.

1. **Reproduza.** Se você não consegue reproduzir, você não sabe se corrigiu.
   Peça ao usuário: passos exatos, ambiente, mensagem de erro completa, quando
   começou. Se não reproduzir, diga isso e trate tudo abaixo como hipótese.

2. **Delimite.** Onde o comportamento correto vira incorreto? Bissecção no código,
   no tempo (`git bisect`) ou nos dados. Reduza o espaço antes de mergulhar.

3. **Encontre a causa raiz** — skill `error-resolver` (primeiros princípios),
   agent `debugger`, agent `error-detective` se o erro atravessa sistemas.
   Pergunte "por quê" até chegar em algo que explique **todos** os sintomas.
   Uma causa que explica só parte do problema não é a causa.

4. **Corrija a causa, não o sintoma.** Se a correção é um `try/catch` em volta do
   erro, você provavelmente não achou a causa.

5. **Escreva o teste que falha sem a correção.** É a única prova de que o bug
   existia e não volta.

6. **Verifique.** Rode os testes. Mostre a saída. Confirme que o caso original
   reproduzido no passo 1 agora passa.

7. **Relate**: o que causava, por que passou despercebido, o que mudou, e se há
   outros lugares no código com o mesmo padrão.

Se depois de investigar você ainda não tem certeza, **diga que não tem**. Apresente
as hipóteses ordenadas e o que falta para confirmar cada uma. Chute apresentado com
confiança é pior que incerteza declarada.
