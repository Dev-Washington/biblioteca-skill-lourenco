---
description: Mostra o que o Kit DevWeb tem instalado e o que se aplica à sua tarefa
---

Leia `CLAUDE.md` na raiz e apresente ao usuário, em português:

1. Verifique o que existe **de fato** em disco antes de responder:
   - `ls .claude/skills` · `ls .claude/agents` · `ls .claude/commands`
   - `cat .claude/settings.json` (quais hooks estão ativos)
   - `cat .mcp.json`
   Não liste nada que não esteja lá.

2. Resuma agrupado: método de trabalho, arquitetura, backend/API, banco, frontend,
   testes, debug, git/deploy, documentação. Destaque **os 2 hooks que bloqueiam**
   (`conventional-commits` e `prevent-direct-push`), porque o usuário vai esbarrar
   neles.

3. Se o usuário passou um assunto como argumento ($ARGUMENTS), diga exatamente o
   que se aplica e por quê. Se não passou, pergunte em que ponto ele está —
   começando projeto, construindo feature, corrigindo bug, preparando deploy — e
   recomende o caminho.

Seja direto. Não repita a tabela inteira do CLAUDE.md.
