---
description: Revisa o código do projeto — qualidade, arquitetura e dívida técnica
---

Alvo: $ARGUMENTS  (se vazio, revise as mudanças não commitadas; se não houver, o projeto)

1. **Delimite o que revisar.** `git diff`, `git status`. Revisar tudo sem foco gera
   lista longa e inútil. Se o alvo for grande, pergunte ao usuário o que priorizar.

2. **Revise em camadas**, dizendo qual está usando:
   - Correção e qualidade → skill `code-reviewer` ou agent `code-reviewer`
   - Consistência arquitetural, SOLID → agent `architect-review`
   - Simplicidade → skill `clean-code`. Procure over-engineering: abstração com um
     só uso, camada que só repassa, opção de configuração que ninguém usa
   - Performance → agent `performance-profiler`, skill `web-performance-optimization`
   - Cobertura de teste → command `/test-coverage`, agent `test-engineer`

3. **Para cada achado**, obrigatoriamente:
   - arquivo e linha
   - o que está errado
   - a consequência prática — não "é ruim", mas "quebra quando X"
   - a correção concreta
   - **nível de confiança**: confirmado (você reproduziu ou leu o caminho todo) ou
     suspeita

4. **Ordene por impacto real.** Um bug confirmado vale mais que vinte avisos de
   estilo. Se a lista tem mais de 10 itens, corte os menos importantes em vez de
   entregar tudo com peso igual.

5. **Feche com o que você não revisou** e por quê.

Este comando **audita**. Não corrija nada sem o usuário pedir.
