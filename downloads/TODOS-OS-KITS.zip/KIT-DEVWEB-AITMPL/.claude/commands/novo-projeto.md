---
description: Inicia uma aplicação web do zero — decisões antes de código
---

Projeto: $ARGUMENTS

Não crie nenhum arquivo antes do passo 3.

1. **Entenda o problema** — skill `brainstorming`. Se $ARGUMENTS for vago, pergunte:
   - O que a aplicação faz e para quem
   - Quantos usuários se espera, e qual o crescimento previsto
   - Precisa de login? de pagamento? de tempo real? de offline?
   - Existe restrição de stack — time, infra, orçamento, prazo?

   Não avance sem isso. Escolher stack sem saber a carga é chute.

2. **Decida a arquitetura** — skill `senior-architect` + skill `api-patterns`
   (REST vs GraphQL vs tRPC) + skill `database-design`. Recomende **um** caminho e
   justifique. Registre as decisões: command `/create-architecture-documentation`
   gera ADRs — é o que evita "por que isso foi feito assim?" seis meses depois.

3. **Modele os dados** — agent `database-architect` + command
   `/design-database-schema`. O schema decide mais sobre o futuro do projeto que a
   escolha de framework.

4. **Scaffold.** Agora sim. Use a skill do stack escolhido (`nextjs-best-practices`,
   `astro`, `nestjs-expert`, `backend-dev-guidelines`).

5. **Qualidade desde o dia 1** — command `/setup-linting`, skill
   `test-driven-development`, command `/ci-setup`. Adicionar depois custa 10× mais.

6. **Verifique.** Rode o projeto. Rode os testes. Mostre a saída. Se não conseguir
   rodar, diga isso em vez de afirmar que está pronto.

Feche listando o que ficou pendente e o que depende do usuário (domínio,
credenciais, contas em serviços).
