---
description: Implementa uma feature completa — do plano ao teste, na ordem certa
---

Feature: $ARGUMENTS

1. **Entenda o escopo** — skill `brainstorming`. Se estiver vago, pergunte o que a
   feature precisa fazer, quem usa e qual o critério de "pronto". Um critério de
   aceite explícito evita metade do retrabalho.

2. **Leia o código que já existe antes de escrever o novo.** Encontre os padrões do
   projeto — como as rotas são organizadas, como o estado é gerenciado, como os
   testes são escritos. Código que destoa do que está em volta é dívida, mesmo
   quando é "melhor".

3. **Planeje** — skill `writing-plans`. Para tarefa multi-passo, escreva o plano
   antes de tocar em código e mostre ao usuário. Se a decisão for difícil, use
   command `/ultra-think`.

4. **Teste primeiro** — skill `test-driven-development` + skill `testing-patterns`.
   O teste define o contrato antes da implementação existir.

5. **Implemente** — skill `clean-code` como padrão: sem over-engineering, sem
   abstração antes do segundo caso de uso, sem comentário que repete a linha.
   Use a skill da camada (`senior-frontend`, `senior-backend`, `senior-fullstack`)
   ou o agent (`frontend-developer`, `backend-architect`, `fullstack-developer`).

6. **Revise** — skill `code-reviewer` ou command `/code-review`.

7. **Verifique de verdade.** Rode os testes e mostre a saída. Se for visível no
   browser, use o MCP `playwright` para abrir e conferir. Não diga que funciona sem
   ter executado.

8. **Commit.** O hook `conventional-commits` exige `tipo(escopo): descrição`. Use
   skill `git-commit-helper` ou command `/commit`. E lembre: `prevent-direct-push`
   bloqueia push em `main` — trabalhe em branch.
