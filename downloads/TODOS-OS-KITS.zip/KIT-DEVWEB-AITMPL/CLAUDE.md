# Kit DevWeb — engenharia de aplicações web

Este projeto tem **43 skills, 20 agents, 24 commands, 6 hooks e 5 MCPs** instalados
em `.claude/`, para construir, testar e operar aplicações web.

Fonte: [aitmpl.com](https://aitmpl.com/) (`claude-code-templates`).

Este kit é de **engenharia**, não de design. Para animação, motion e landing page
visual, existe o `KIT-DEVWEB-MOTION-AITMPL` — não improvise animação aqui.

---

## Proteções automáticas já ativas

`.claude/settings.json` instala 6 hooks. **Dois bloqueiam de verdade:**

| Hook | Quando dispara | O que faz |
|---|---|---|
| `conventional-commits` | Bash com `git commit` | **Bloqueia** mensagem fora do padrão `tipo(escopo): descrição` |
| `prevent-direct-push` | Bash com `git push` | **Bloqueia** push direto em `main` e `develop` |
| `lint-on-save` | após Edit/MultiEdit | ESLint, pylint ou rubocop conforme a extensão |
| `smart-formatting` | após Edit/MultiEdit | Prettier, Black, gofmt, rustfmt |
| `run-tests-after-changes` | após Edit | Roda `npm run test:quick` se existir |
| `simple-notifications` | Stop / Notification | Notificação no desktop |

Se um commit ou push for recusado, é o hook — não é bug. Use
`feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `chore:`, `ci:`, `perf:`, `build:`,
`style:`, `revert:` na mensagem, e trabalhe em branch em vez de `main`.

Para desligar: edite `.claude/settings.json`. Não desligue por conta própria — avise
o usuário qual hook bloqueou e deixe a decisão com ele.

---

## Ordem de trabalho

O kit tem skills de **método**, e elas valem mais que as de tecnologia. Respeite a ordem:

1. **Entender antes de codar** → skill `brainstorming`. Ela mesma diz: use ANTES de
   qualquer trabalho criativo — feature, componente, funcionalidade.
2. **Planejar tarefa multi-passo** → skill `writing-plans`, ou command `/ultra-think`
   quando a decisão for difícil e você precisar de soluções concorrentes.
3. **Testar antes de implementar** → skill `test-driven-development`.
4. **Debugar com método** → skill `systematic-debugging`. Use ao encontrar bug ou
   teste falhando, **antes** de propor correção. Não chute.
5. **Escrever simples** → skill `clean-code`. Sem over-engineering, sem abstração
   antecipada, sem comentário que repete a linha.

Pular direto para o código é o erro mais caro, e o mais comum.

---

## Roteamento — qual usar para quê

### Arquitetura e decisão
| Assunto da tarefa | Use |
|---|---|
| Escolher stack, desenhar sistema, trade-offs | skill `senior-architect` |
| Arquitetura voltada a qualidade, padrões | skill `software-architecture` |
| Revisar consistência arquitetural, SOLID | agent `architect-review` |
| Design de serviço, decompor monolito, paradigma de API | agent `backend-architect` |
| **REST vs GraphQL vs tRPC**, versionamento, paginação | skill `api-patterns` |
| Decisão difícil, suposições ocultas, soluções concorrentes | command `/ultra-think` |
| Documentar arquitetura com diagramas e ADRs | command `/create-architecture-documentation` |

### Backend e API
| Assunto da tarefa | Use |
|---|---|
| Backend em Node, Express, Go, Python, Postgres, GraphQL | skill `senior-backend` |
| Node/Express/TypeScript em microserviço | skill `backend-dev-guidelines` |
| Escolha de framework Node, async, segurança | skill `nodejs-best-practices` |
| Nest.js: módulos, DI, guards, interceptors | skill `nestjs-expert` |
| REST e GraphQL com resiliência e versionamento | agent `api-architect` |
| Integrar API de terceiro: auth, retry, rate limit | skill `api-integration-specialist` |
| Projetar API REST do zero | command `/design-rest-api` |
| Python | skill `python-patterns`, agent `python-pro` |

### Banco de dados
| Assunto da tarefa | Use |
|---|---|
| Modelar dados, escolher tecnologia de banco | agent `database-architect`, skill `database-design` |
| Schema Postgres: tipos, índices, constraints | skill `postgresql` |
| Performance de Postgres | skills `postgres-best-practices`, `supabase-postgres-best-practices` |
| Query lenta, indexação, tuning | agent `database-optimization`, command `/optimize-database-performance` |
| SQL complexo, OLTP/OLAP | agent `sql-pro` |
| Migração entre ORMs, com rollback | skill `database-migration` |
| Projetar schema | command `/design-database-schema` |

### Frontend
| Assunto da tarefa | Use |
|---|---|
| App web moderno em React/Next/TypeScript | skill `senior-frontend` |
| Construir front completo (React, Vue, Angular) | agent `frontend-developer` |
| Performance de React: waterfall, bundle, render | skill `react-best-practices` |
| Suspense, lazy loading, padrões React modernos | skill `frontend-dev-guidelines` |
| Next.js App Router, Server Components | skills `nextjs-best-practices`, `nextjs-app-router-patterns` |
| TypeScript avançado, generics, type-level | skill `typescript-expert`, agent `typescript-pro` |
| JavaScript moderno | agent `javascript-pro` |
| Escolher entre Redux, Zustand, Jotai, React Query | skill `react-state-management` |
| React Query: fetching, stale time, optimistic | skill `tanstack-query-expert` |
| Validação com Zod, inferência de tipo | skill `zod-validation-expert` |
| Componentes shadcn/ui | skill `shadcn` |
| Site de conteúdo, zero JS por padrão | skill `astro` |
| PWA: offline, service worker | skill `progressive-web-app` |
| Core Web Vitals, bundle, cache | skill `web-performance-optimization`, skill `performance` |
| Meta tags, ranking | skill `seo` |
| Feature completa atravessando banco + API + front | agent `fullstack-developer`, skill `senior-fullstack` |

### Testes e qualidade
| Assunto da tarefa | Use |
|---|---|
| Estratégia de teste, automação, cobertura | agent `test-engineer`, skill `senior-qa` |
| Gerar arquivo de teste para um fonte | command `/generate-tests` |
| Analisar cobertura e lacunas | command `/test-coverage` |
| Jest: factory, mocking, TDD | skill `testing-patterns` |
| Testar app local com Playwright | skill `webapp-testing` |
| Review de código | skill `code-reviewer`, agent `code-reviewer`, command `/code-review` |
| Refatorar | command `/refactor-code` |
| Explicar código existente | command `/explain-code` |

### Debug e incidente
| Assunto da tarefa | Use |
|---|---|
| Bug, teste falhando, comportamento inesperado | skill `systematic-debugging` |
| Diagnosticar causa raiz | agent `debugger`, command `/debug-error` |
| Mensagem de erro, diagnóstico por primeiros princípios | skill `error-resolver` |
| Correlacionar erro entre sistemas | agent `error-detective` |
| Gargalo, vazamento de memória | agent `performance-profiler`, command `/performance-audit` |
| Incidente em produção, análise de log | agent `devops-troubleshooter` |

### Git, CI/CD e deploy
| Assunto da tarefa | Use |
|---|---|
| Mensagem de commit a partir do diff | skill `git-commit-helper`, command `/commit` |
| Abrir pull request | command `/create-pr` |
| Pipeline de CI/CD | agent `deployment-engineer`, command `/ci-setup` |
| Docker: multi-stage, imagem otimizada, Compose | skill `docker-expert`, command `/containerize-application` |
| CI/CD, infra, containers, AWS/GCP/Azure | skill `senior-devops`, agent `devops-engineer` |
| Changelog | command `/add-changelog` |
| Configurar lint | command `/setup-linting` |

### Documentação
| Assunto da tarefa | Use |
|---|---|
| Criar e manter documentação técnica | agent `documentation-expert` |
| Arquitetura com diagramas e ADRs | command `/create-architecture-documentation` |
| Sincronizar doc com a implementação | command `/update-docs` |
| Referência de API | command `/generate-api-documentation` |

---

## Verifique antes de dizer que funciona

`.mcp.json` traz **playwright** ativo. Se a mudança é visível no browser, abra,
tire screenshot e confirme. Se é backend, rode os testes e mostre a saída.

Se não conseguir verificar, **diga isso**. "Implementei, os testes não rodam nesta
máquina" é honesto. "Está funcionando" sem ter rodado, não.

---

## Lacunas conhecidas — não invente que existe

- **Sem skill de animação.** Intencional. Se a tarefa virar motion ou landing page
  visual, diga que o kit certo é o `KIT-DEVWEB-MOTION-AITMPL`.
- **`run-tests-after-changes` depende de um script `test:quick`** no `package.json`.
  Se não existir, o hook imprime aviso sem ter rodado teste nenhum. Não trate essa
  mensagem como resultado de teste.
- **`lint-on-save` e `smart-formatting` falham em silêncio** se ESLint/Prettier não
  estiverem instalados. Ausência de erro não significa que formatou.
- **Componentes com nome duplicado** entre skill e agent (`code-reviewer`,
  `database-architect`, `sql-pro`). São diferentes — diga qual está usando.

## Convenções

- Declare qual skill/agent está usando antes de aplicar a recomendação.
- Sem over-engineering. Skill `clean-code` é o padrão: nenhuma abstração antes de
  existir o segundo caso de uso.
- Achado de bug precisa de evidência: arquivo, linha e como reproduzir.
- Antes de migração de banco ou mudança difícil de reverter, pare e confirme.
- Não instale novos componentes do aitmpl.com sem o usuário pedir.
