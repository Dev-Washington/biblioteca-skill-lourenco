# Kit de Desenvolvimento Web — aitmpl.com

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) (arquivo `components.json`, que alimenta o site).
> Repositório de origem: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)
> Data da análise: 26/08/2026

Kit de engenharia: arquitetura, backend, frontend, banco, API, testes, debug, git,
CI/CD e deploy. **Sem foco em animação** — para isso, use o `KIT-DEVWEB-MOTION-AITMPL`.

---

## 1. O que existe no catálogo

| Tipo | Total | Categorias relevantes | Selecionados |
|---|---|---|---|
| Skills | 872 | `development` (227), `web-development` (30), `database` (12) | 43 |
| Agents | 422 | `development-tools` (35), `programming-languages` (50), `devops-infrastructure` (40), `development-team` (17), `expert-advisors` (52), `database` (11) | 20 |
| Commands | 286 | `utilities` (21), `testing` (15), `setup` (15), `git-workflow` (14), `deployment` (11), `documentation` (10), `performance` (10) | 20 |
| Hooks | 62 | `development-tools` (9), `automation` (19), `git` (3), `post-tool` (4) | 6 |
| MCPs | 101 | `devtools` (48), `database` (8), `browser_automation` (6) | 5 |

**Total: 94 componentes.** Todos validados contra o catálogo antes de instalar.

A categoria `development` (227 skills) é a maior do catálogo depois de `ai-research`
e `scientific`. É onde mora a família `senior-*`, que forma a espinha do kit.

---

## 2. Kit essencial — a família `senior-*`

Seis skills cobrem as seis frentes de um sistema web. São as mais baixadas da
categoria e a base de tudo.

| Componente | Tipo | Por quê | Downloads |
|---|---|---|---|
| `development/code-reviewer` | skill | Review em TS, JS, Python, Swift, Kotlin, Go. Análise automatizada, segurança, checklist | 8.384 |
| `development/senior-frontend` | skill | React, Next.js, TypeScript — aplicações web modernas e performantes | 7.366 |
| `development/senior-backend` | skill | Node, Express, Go, Python, Postgres, GraphQL, REST | 6.320 |
| `development/senior-architect` | skill | Arquitetura escalável, decisão de stack, diagramas, trade-offs | 5.217 |
| `development/senior-fullstack` | skill | Aplicação completa: React, Next, Node, GraphQL | 3.016 |
| `development/senior-devops` | skill | CI/CD, automação de infra, containers, AWS/GCP/Azure | 872 |
| `development/senior-qa` | skill | QA, automação de teste, estratégia de testes | 719 |

```bash
npx claude-code-templates@latest --skill development/code-reviewer --yes
npx claude-code-templates@latest --skill development/senior-frontend --yes
npx claude-code-templates@latest --skill development/senior-backend --yes
npx claude-code-templates@latest --skill development/senior-architect --yes
npx claude-code-templates@latest --skill development/senior-fullstack --yes
npx claude-code-templates@latest --skill development/senior-devops --yes
npx claude-code-templates@latest --skill development/senior-qa --yes
```

---

## 3. Método de trabalho — o que mais muda o resultado

Estas skills não ensinam tecnologia; ensinam **como conduzir a tarefa**. São as que
mais mudam a qualidade do que a IA entrega, e as mais ignoradas.

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development/brainstorming` | skill | "Use ANTES de qualquer trabalho criativo" — explora o problema antes de codar | 2.606 |
| `development/clean-code` | skill | Padrão pragmático: conciso, direto, **sem over-engineering**, sem comentário desnecessário | 1.695 |
| `development/systematic-debugging` | skill | Use ao encontrar bug ou teste falhando, **antes** de propor correção | 527 |
| `development/writing-plans` | skill | Use quando há spec de tarefa multi-passo, antes de tocar em código | 375 |
| `development/error-resolver` | skill | Diagnóstico por primeiros princípios | 249 |
| `development/test-driven-development` | skill | Use ao implementar feature ou correção, antes do código de implementação | 203 |
| `utilities/ultra-think` | command | Análise multi-framework: expõe suposições ocultas, gera soluções concorrentes | 2.278 |

`clean-code` merece destaque: "no over-engineering" é exatamente o vício mais comum
de código gerado por IA — abstração antecipada, camada que ninguém pediu, comentário
que repete o que a linha já diz.

`brainstorming` e `writing-plans` invertem a ordem padrão: pensar antes de escrever.
Vale mais que qualquer skill de framework.

---

## 4. Backend, API e banco

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development-team/backend-architect` | agent | Design de serviço, decomposição de monolito, escolha de paradigma de API | 6.339 |
| `database/database-architect` | agent | Modelagem de dados, decisão de tecnologia de banco | 3.175 |
| `database/database-optimization` | agent | Query lenta, indexação, tuning | 1.074 |
| `programming-languages/sql-pro` | agent | Query complexa, schema eficiente, OLTP/OLAP | 945 |
| `development/api-integration-specialist` | skill | Integrar API de terceiro: auth, erro, rate limit, retry | 755 |
| `database/supabase-postgres-best-practices` | skill | Performance e boas práticas de Postgres, pela Supabase | 652 |
| `development/nestjs-expert` | skill | Nest.js: módulos, DI, guards, interceptors | 280 |
| `development/database-design` | skill | Schema, indexação, escolha de ORM, banco serverless | 267 |
| `development/postgres-best-practices` | skill | Otimização de Postgres | 206 |
| `api-graphql/api-architect` | agent | REST e GraphQL com resiliência e versionamento | 196 |
| `development/backend-dev-guidelines` | skill | Node/Express/TypeScript em microserviços | 164 |
| `development/nodejs-best-practices` | skill | Escolha de framework, async, segurança, arquitetura | 160 |
| `development/api-patterns` | skill | **REST vs GraphQL vs tRPC**, formato de resposta, versionamento, paginação | 130 |
| `database/postgresql` | skill | Schema específico de Postgres: tipos, índices, constraints | 76 |
| `database/database-migration` | skill | Migração entre ORMs (Sequelize, TypeORM, Prisma), com rollback | 37 |

`api-patterns` resolve a decisão que trava projeto no dia 1 — REST, GraphQL ou tRPC.

---

## 5. Frontend e stack web

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development-team/frontend-developer` | agent | **O agent mais baixado do catálogo.** React, Vue, Angular | 10.867 |
| `web-development/react-best-practices` | skill | 40+ regras: elimina waterfall, otimiza bundle e render | 3.272 |
| `programming-languages/typescript-pro` | agent | Tipos avançados, generics, type-level programming | 2.560 |
| `programming-languages/javascript-pro` | agent | JS moderno para browser e Node | 1.370 |
| `web-development/web-performance-optimization` | skill | Core Web Vitals, bundle, cache, runtime | 806 |
| `development/nextjs-best-practices` | skill | App Router, Server Components, data fetching | 467 |
| `development/typescript-expert` | skill | TypeScript aplicado | 176 |
| `development/frontend-dev-guidelines` | skill | React/TypeScript: Suspense, lazy loading, padrões modernos | 147 |
| `development/performance` | skill | "Acelerar o site", otimizar carregamento | 122 |
| `development/seo` | skill | Meta tags, ranking, visibilidade | 114 |
| `web-development/shadcn` | skill | Componentes shadcn/ui | 107 |
| `web-development/nextjs-app-router-patterns` | skill | Next.js 14+ App Router | 79 |
| `web-development/progressive-web-app` | skill | PWA: offline, service worker, instalável | 55 |
| `web-development/tanstack-query-expert` | skill | React Query: fetching, stale time, mutation, optimistic update | 46 |
| `web-development/zod-validation-expert` | skill | Zod: parsing, refinement, inferência de tipo, React Hook Form | 44 |
| `web-development/react-state-management` | skill | Redux Toolkit, Zustand, Jotai, React Query — e **qual escolher** | 38 |
| `web-development/astro` | skill | Site de conteúdo, zero JS por padrão, islands | 34 |

---

## 6. Testes, debug e qualidade

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development-tools/code-reviewer` | agent | Review focado em qualidade e vulnerabilidade | 8.333 |
| `development-tools/debugger` | agent | Diagnóstico de bug, causa raiz, análise de erro | 3.650 |
| `testing/generate-tests` | command | Gera arquivo de teste completo para um fonte | 3.154 |
| `development/webapp-testing` | skill | Playwright: testar app local, screenshot, verificar comportamento | 2.720 |
| `development-tools/test-engineer` | agent | Estratégia de teste, automação, cobertura | 2.624 |
| `expert-advisors/architect-review` | agent | Consistência arquitetural, SOLID | 2.457 |
| `development-tools/error-detective` | agent | Correlaciona erro entre sistemas | 2.133 |
| `utilities/code-review` | command | Review de qualidade, segurança, performance, arquitetura | 1.526 |
| `utilities/refactor-code` | command | Refatoração | 1.378 |
| `development-tools/performance-profiler` | agent | Gargalo, vazamento de memória | 493 |
| `development/software-architecture` | skill | Arquitetura voltada a qualidade | 452 |
| `development/testing-patterns` | skill | Jest: factory, mocking, fluxo TDD | 118 |
| `testing/test-coverage` | command | Analisa cobertura e aponta lacunas | 167 |

---

## 7. Git, CI/CD e deploy

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development/git-commit-helper` | skill | Mensagem de commit a partir do diff | 1.836 |
| `devops-infrastructure/deployment-engineer` | agent | Pipeline de CI/CD e automação de deploy | 1.633 |
| `git-workflow/commit` | command | Commit em formato convencional | 1.236 |
| `development-team/devops-engineer` | agent | CI/CD, deploy, operação em nuvem | 1.951 |
| `devops-infrastructure/devops-troubleshooter` | agent | Incidente em produção, análise de log | 647 |
| `deployment/add-changelog` | command | Changelog em formato Keep a Changelog | 630 |
| `development/docker-expert` | skill | Multi-stage build, otimização de imagem, Compose | 546 |
| `deployment/containerize-application` | command | Containeriza a aplicação com Docker otimizado | 346 |
| `git-workflow/create-pr` | command | Abre pull request | 288 |
| `deployment/ci-setup` | command | Pipeline de CI/CD com teste, build e deploy | 87 |

---

## 8. Documentação

Subestimada e barata — o catálogo tem componentes muito bons aqui.

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `expert-advisors/documentation-expert` | agent | Cria e mantém documentação técnica | 1.848 |
| `documentation/create-architecture-documentation` | command | Documentação de arquitetura com diagramas e ADRs | 1.665 |
| `documentation/update-docs` | command | Sincroniza doc com o estado real da implementação | 1.011 |
| `documentation/generate-api-documentation` | command | Referência de API em vários formatos | 499 |
| `utilities/explain-code` | command | Explica código existente | 725 |

`create-architecture-documentation` gera ADRs — decisões arquiteturais registradas.
É o que evita a pergunta "por que isso foi feito assim?" seis meses depois.

---

## 9. Hooks — automação que roda sozinha

| Componente | O que faz | Downloads |
|---|---|---|
| `automation/simple-notifications` | Notificação no desktop quando o Claude termina ou precisa de você | 2.723 |
| `development-tools/lint-on-save` | ESLint/pylint/rubocop após cada edição | 897 |
| `development-tools/smart-formatting` | Prettier, Black, gofmt, rustfmt conforme o tipo de arquivo | 847 |
| `post-tool/run-tests-after-changes` | Roda `npm run test:quick` após modificação de código | 436 |
| `git/conventional-commits` | **Bloqueia** commit fora do padrão Conventional Commits | 220 |
| `git/prevent-direct-push` | **Bloqueia** push direto em `main` e `develop` | 146 |

Os dois últimos bloqueiam de verdade. Testados: mensagem `"consertei umas coisas"` é
recusada, `"feat: adiciona login"` passa; `git push origin main` é recusado,
`git push origin feature/x` passa.

`simple-notifications` é o mais baixado dos 62 hooks do catálogo — resolve o
problema real de não saber quando a IA terminou.

---

## 10. MCPs

| Componente | O que faz | Requisito | Downloads |
|---|---|---|---|
| `devtools/context7` | Documentação atualizada da fonte, por versão | chave de API | 3.936 |
| `browser_automation/playwright-mcp-server` | Browser: abrir, screenshot, executar JS | nenhum | 1.752 |
| `database/postgresql-integration` | Query direto no Postgres | connection string | 1.299 |
| `integration/github-integration` | Repos, issues, PRs | token | 1.143 |
| `devtools/serena` | Busca e edição semântica de código | `uv` + instalação local | 264 |

Só `playwright` funciona sem configuração. Os outros quatro ficam em
`.mcp.optional.json` — se entrassem no `.mcp.json` com placeholder, dariam erro de
conexão a cada sessão.

---

## 11. Sintaxe de instalação

```bash
npx claude-code-templates@latest --skill   <categoria>/<nome> --yes
npx claude-code-templates@latest --agent   <categoria>/<nome> --yes
npx claude-code-templates@latest --command <categoria>/<nome> --yes
npx claude-code-templates@latest --hook    <categoria>/<nome> --yes
npx claude-code-templates@latest --mcp     <categoria>/<nome> --yes
```

> A API do GitHub limita a 60 requisições/hora sem autenticação. Instalar 94
> componentes de uma vez estoura o limite e falha com HTTP 403. Este kit foi
> instalado clonando o repositório
> (`git clone --depth 1 --filter=blob:none --sparse`), que não passa pela API REST.

---

## 12. Ressalvas honestas

1. **Sobreposição entre componentes com o mesmo nome.** `code-reviewer` existe como
   skill (`development/`, 8.384) **e** como agent (`development-tools/`, 8.333) —
   são componentes diferentes, ambos instalados, e fazem quase a mesma coisa.
   Idem `database-architect` (skill em `database/`, agent em `database/`),
   `sql-pro`, `database-optimizer`, `backend-architect`. Sempre instale com o
   caminho completo `categoria/nome`.

2. **Hooks de formatação rodam a cada edição.** `lint-on-save` e `smart-formatting`
   chamam `npx eslint` e `npx prettier` após cada Edit. Em projeto grande isso
   adiciona latência perceptível. Ambos falham em silêncio se a ferramenta não
   existir (`|| true`), então não quebram nada — mas também não avisam que não
   fizeram nada.

3. **`run-tests-after-changes` depende de um script `test:quick`.** Se o
   `package.json` não tiver esse script, o hook imprime "⚠️ Tests may need
   attention" em toda edição, sem ter rodado teste nenhum. Crie o script ou remova
   o hook.

4. **Os dois hooks de git impõem um fluxo.** Conventional Commits e proibição de
   push em `main` são boas práticas, mas se você trabalha sozinho commitando direto
   na main, vão atrapalhar. Instale com `--sem-hooks` se preferir.

5. **Popularidade desigual.** `astro` (34 downloads), `database-migration` (37),
   `react-state-management` (38), `zod-validation-expert` (44) e
   `tanstack-query-expert` (46) são pouco usados — provavelmente pouco testados.
   Já `frontend-developer` (10.867), `code-reviewer` (8.384) e `senior-frontend`
   (7.366) estão entre os mais baixados do catálogo inteiro.

6. **Não há skill de animação.** É intencional neste kit. O catálogo também não tem
   — ver `KIT-DEVWEB-MOTION-AITMPL`, que preenche essa lacuna com uma skill própria.

7. **Skill não substitui engenheiro.** O kit aumenta a chance de a IA lembrar de
   verificar algo. Não substitui revisão humana em decisão de arquitetura, migração
   de banco ou qualquer coisa difícil de reverter.

---

## 13. Resumo — o que instalar agora

```bash
# Espinha
npx claude-code-templates@latest --skill development/senior-architect --yes
npx claude-code-templates@latest --skill development/senior-frontend --yes
npx claude-code-templates@latest --skill development/senior-backend --yes
npx claude-code-templates@latest --skill development/senior-fullstack --yes
npx claude-code-templates@latest --skill development/code-reviewer --yes

# Método
npx claude-code-templates@latest --skill development/brainstorming --yes
npx claude-code-templates@latest --skill development/clean-code --yes
npx claude-code-templates@latest --skill development/writing-plans --yes
npx claude-code-templates@latest --skill development/systematic-debugging --yes
npx claude-code-templates@latest --skill development/test-driven-development --yes

# Agents
npx claude-code-templates@latest --agent development-team/frontend-developer --yes
npx claude-code-templates@latest --agent development-team/backend-architect --yes
npx claude-code-templates@latest --agent development-team/fullstack-developer --yes
npx claude-code-templates@latest --agent development-tools/debugger --yes
npx claude-code-templates@latest --agent development-tools/test-engineer --yes
npx claude-code-templates@latest --agent database/database-architect --yes
npx claude-code-templates@latest --agent expert-advisors/architect-review --yes

# Commands
npx claude-code-templates@latest --command utilities/code-review --yes
npx claude-code-templates@latest --command utilities/ultra-think --yes
npx claude-code-templates@latest --command testing/generate-tests --yes
npx claude-code-templates@latest --command git-workflow/commit --yes
npx claude-code-templates@latest --command documentation/create-architecture-documentation --yes

# Hooks
npx claude-code-templates@latest --hook automation/simple-notifications --yes
npx claude-code-templates@latest --hook development-tools/smart-formatting --yes
npx claude-code-templates@latest --hook git/conventional-commits --yes

# MCP
npx claude-code-templates@latest --mcp browser_automation/playwright-mcp-server --yes
```
