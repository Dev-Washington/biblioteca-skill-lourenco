#!/usr/bin/env bash
# Instala o Kit DevWeb em um projeto existente.
# Uso:  ./install.sh /caminho/do/seu/projeto [--sem-hooks]
set -euo pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:-}"
SKIP_HOOKS=0
[ "${2:-}" = "--sem-hooks" ] && SKIP_HOOKS=1

if [ -z "$DEST" ]; then
  echo "uso: $0 /caminho/do/projeto [--sem-hooks]" >&2
  echo "     --sem-hooks  instala skills/agents/commands, mas NÃO os hooks automáticos" >&2
  exit 1
fi
[ -d "$DEST" ] || { echo "erro: '$DEST' não é um diretório" >&2; exit 1; }
DEST="$(cd "$DEST" && pwd)"
[ "$DEST" != "$KIT" ] || { echo "erro: destino é o próprio kit" >&2; exit 1; }

echo "Kit:     $KIT"
echo "Destino: $DEST"
echo

mkdir -p "$DEST/.claude/skills" "$DEST/.claude/agents" "$DEST/.claude/commands"

copy_dir() {
  local src="$KIT/.claude/$1" name skipped=0 added=0
  [ -d "$src" ] || return 0
  for path in "$src"/*; do
    [ -e "$path" ] || continue
    name="$(basename "$path")"
    if [ -e "$DEST/.claude/$1/$name" ]; then skipped=$((skipped+1))
    else cp -R "$path" "$DEST/.claude/$1/$name"; added=$((added+1)); fi
  done
  echo "  $1: $added adicionado(s), $skipped já existia(m)"
}

copy_dir skills
copy_dir agents
copy_dir commands

echo
if [ "$SKIP_HOOKS" -eq 1 ]; then
  echo "hooks: PULADOS (--sem-hooks)"
else
  mkdir -p "$DEST/.claude/hooks"
  for f in "$KIT"/.claude/hooks/*; do
    [ -e "$f" ] || continue
    n="$(basename "$f")"
    if [ -e "$DEST/.claude/hooks/$n" ]; then echo "  pulado (já existe): .claude/hooks/$n"
    else cp "$f" "$DEST/.claude/hooks/$n"; chmod +x "$DEST/.claude/hooks/$n"; echo "  + .claude/hooks/$n"; fi
  done
  node -e '
    const fs=require("fs"), [dstF,srcF]=process.argv.slice(1);
    const src=JSON.parse(fs.readFileSync(srcF,"utf8"));
    const dst=fs.existsSync(dstF)?JSON.parse(fs.readFileSync(dstF,"utf8")):{};
    dst.hooks=dst.hooks||{}; let n=0;
    for(const [evt,arr] of Object.entries(src.hooks||{})){
      dst.hooks[evt]=dst.hooks[evt]||[];
      for(const e of arr){
        if(dst.hooks[evt].some(x=>JSON.stringify(x)===JSON.stringify(e))) continue;
        dst.hooks[evt].push(e); n++;
      }
    }
    if(src.env) dst.env=Object.assign({},src.env,dst.env||{});
    fs.writeFileSync(dstF,JSON.stringify(dst,null,2)+"\n");
    console.log("  settings.json: "+n+" hook(s) adicionado(s)");
  ' "$DEST/.claude/settings.json" "$KIT/.claude/settings.json"
fi

echo
if [ -f "$DEST/CLAUDE.md" ]; then
  cp "$KIT/CLAUDE.md" "$DEST/.claude/KIT-DEVWEB.md"
  if grep -q "KIT-DEVWEB.md" "$DEST/CLAUDE.md"; then
    echo "CLAUDE.md: referência ao kit já presente"
  else
    printf '\n@.claude/KIT-DEVWEB.md\n' >> "$DEST/CLAUDE.md"
    echo "CLAUDE.md: já existia — kit salvo em .claude/KIT-DEVWEB.md e referenciado via @import"
  fi
else
  cp "$KIT/CLAUDE.md" "$DEST/CLAUDE.md"; echo "CLAUDE.md: criado"
fi

if [ -f "$DEST/.mcp.json" ]; then
  node -e '
    const fs=require("fs"), [dstF,srcF]=process.argv.slice(1);
    const d=JSON.parse(fs.readFileSync(dstF,"utf8")), s=JSON.parse(fs.readFileSync(srcF,"utf8"));
    d.mcpServers=d.mcpServers||{}; let n=0;
    for(const [k,v] of Object.entries(s.mcpServers||{})){
      if(k in d.mcpServers) console.log("  pulado (já existe): mcp "+k);
      else { d.mcpServers[k]=v; n++; console.log("  + mcp "+k); }
    }
    if(n) fs.writeFileSync(dstF,JSON.stringify(d,null,2)+"\n");
  ' "$DEST/.mcp.json" "$KIT/.mcp.json"
  echo ".mcp.json: mesclado"
else
  cp "$KIT/.mcp.json" "$DEST/.mcp.json"; echo ".mcp.json: criado"
fi
cp "$KIT/.mcp.optional.json" "$DEST/.mcp.optional.json" 2>/dev/null || true

echo
if [ "$SKIP_HOOKS" -eq 0 ]; then
  echo "ATENÇÃO: 2 hooks BLOQUEIAM comandos:"
  echo "  · conventional-commits — exige 'tipo(escopo): descrição' na mensagem de commit"
  echo "  · prevent-direct-push  — proíbe push direto em main/develop"
  echo "Para desativar: edite .claude/settings.json"
  echo
fi
echo "Pronto. Abra '$DEST' no Claude Code e rode /kit-devweb."
