# Kit Pesquisa — time de pesquisa com orquestrador

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**18 componentes · 7.751 downloads somados.**

---

## 1. O que este kit é

Não é uma coleção de skills soltas — é um **time completo** com orquestrador.
`deep-research-team` tem 16 agents desenhados para trabalhar juntos: um coordena, os
outros pesquisam em frentes diferentes, um verifica, um sintetiza, um escreve o
relatório.

É a estrutura que os outros kits não têm. Onde uma skill responde a uma pergunta,
este time cobre um assunto por vários ângulos e confere o resultado.

Instalei 13 dos 16 — deixei de fora `agent-overview` (273, meta), `nia-oracle` (81,
depende de serviço específico) e `multi-source-searcher` (**2 downloads**).

---

## 2. Os agents, na ordem de uso

### Coordenar
| Componente | O que entrega | Downloads |
|---|---|---|
| `research-orchestrator` | Orquestra a pesquisa entre os especialistas | 620 |
| `research-coordinator` | Planeja e coordena pesquisa complexa entre especialistas | 467 |
| `query-clarifier` | Esclarece a pergunta antes de sair pesquisando | 244 |

`query-clarifier` é o que evita o desperdício maior: pesquisar bem a pergunta errada.

### Pesquisar
| Componente | O que entrega | Downloads |
|---|---|---|
| `technical-researcher` | Repositórios, documentação técnica, detalhe de implementação | 912 |
| `academic-researcher` | Literatura acadêmica | 481 |
| `data-researcher` | Pesquisa em dados | 126 |
| `competitive-intelligence-analyst` | Inteligência competitiva | 411 |

### Analisar e verificar
| Componente | O que entrega | Downloads |
|---|---|---|
| `data-analyst` | Análise quantitativa, insight estatístico | 822 |
| `fact-checker` | Verificação de fato | 473 |
| `research-analyst` | Análise de pesquisa | 121 |

`fact-checker` é o componente que separa este kit de uma busca no Google. Pesquisa
sem verificação é acúmulo de link.

### Entregar
| Componente | O que entrega | Downloads |
|---|---|---|
| `research-synthesizer` | Sintetiza achados de múltiplas fontes | 391 |
| `report-generator` | Gera o relatório final | 516 |
| `research-brief-generator` | Briefing de pesquisa | 288 |

### Apoio
`utilities/browser-automation` (111) — automação de browser confiável.
`web-data/bright-data-best-practices` (160) — integrações Bright Data.

### MCPs
`web/web-fetch` (1.308) — sem credencial. `devtools/firecrawl` (161) e
`web-data/brightdata` (139) — precisam de chave.

---

## 3. Ressalvas honestas

1. **Um time de 13 agents consome muito token.** Uma pesquisa completa com
   orquestrador, 4 pesquisadores, verificador e sintetizador é cara. Para uma
   pergunta simples, use um agent direto — `technical-researcher` sozinho resolve a
   maioria dos casos.

2. **`fact-checker` verifica contra fontes que ele encontra**, não contra a verdade.
   Se as fontes disponíveis estiverem erradas ou enviesadas, a verificação repete o
   erro com confiança. Ele reduz o risco; não o elimina.

3. **Scraping tem limite legal e técnico.** `firecrawl` e `brightdata` raspam sites
   de terceiros. Verifique `robots.txt` e termos de uso. Raspar dado pessoal tem
   implicação de LGPD.

4. **`multi-source-searcher` tem 2 downloads** — não instalei. É o componente menos
   usado de todo o catálogo.

5. **Pesquisa gerada por IA precisa de fonte rastreável.** Exija link e citação em
   cada afirmação. Sem isso, você tem um texto plausível, não uma pesquisa.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --agent deep-research-team/research-orchestrator --yes
npx claude-code-templates@latest --agent deep-research-team/technical-researcher --yes
npx claude-code-templates@latest --agent deep-research-team/fact-checker --yes
npx claude-code-templates@latest --agent deep-research-team/research-synthesizer --yes
npx claude-code-templates@latest --agent deep-research-team/report-generator --yes
npx claude-code-templates@latest --mcp web/web-fetch --yes
```
