# Kit Pesquisa — time de pesquisa com orquestrador

**2 skills, 13 agents, 2 commands e 3 MCPs.**

Origem: [aitmpl.com](https://aitmpl.com/) · **18 componentes, 7.751 downloads somados.**

---

## O que este kit é

Não é uma coleção de skills soltas — é um **time completo com orquestrador**.
`deep-research-team` tem agents desenhados para trabalhar juntos: um coordena,
outros pesquisam em frentes diferentes, um verifica, um sintetiza, um escreve.

É a estrutura que os outros kits não têm. Onde uma skill responde a uma pergunta,
este time cobre um assunto por vários ângulos e **confere o resultado**.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-pesquisa`. Ou instale num projeto: `./install.sh /caminho` · `./check.sh`.

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-pesquisa [pergunta]` | Mostra o time e **dimensiona** a pesquisa |
| `/pesquisar [pergunta]` | Esclarece → dimensiona → pesquisa → verifica → sintetiza → escreve |

Os dois começam **dimensionando**. Um time de 13 agents consome muito token — para
uma pergunta simples, `technical-researcher` sozinho resolve.

---

## O time

**Coordenar** — `research-orchestrator` (620), `research-coordinator` (467),
`query-clarifier` (244).

**Pesquisar** — `technical-researcher` (912), `academic-researcher` (481),
`competitive-intelligence-analyst` (411), `data-researcher` (126).

**Analisar e verificar** — `data-analyst` (822), `fact-checker` (473),
`research-analyst` (121).

**Entregar** — `report-generator` (516), `research-synthesizer` (391),
`research-brief-generator` (288).

**Apoio** — `browser-automation` (111), `bright-data-best-practices` (160).

Dois merecem destaque: `query-clarifier` evita o desperdício maior — pesquisar bem a
pergunta errada. E `fact-checker` é o que separa este kit de uma busca no Google:
pesquisa sem verificação é acúmulo de link.

Detalhe: [KIT-PESQUISA.md](KIT-PESQUISA.md).

---

## MCPs

**Ativo:** `fetch` (1.308) — busca conteúdo web, sem credencial.

**Opcionais:** `firecrawl` (161) e `brightdata` (139) — scraping profundo, ambos com
chave de API.

---

## Limitações

1. **O time completo é caro em token.** Orquestrador + 4 pesquisadores + verificador
   + sintetizador para uma pergunta simples é desperdício. Ambos os comandos
   dimensionam antes.

2. **`fact-checker` verifica contra as fontes que encontra**, não contra a verdade.
   Se as fontes estiverem erradas ou enviesadas, ele repete o erro com confiança.
   Reduz risco; não elimina.

3. **Scraping tem limite legal.** `firecrawl` e `brightdata` raspam sites de
   terceiros — verifique `robots.txt` e termos de uso. Dado pessoal tem implicação
   de LGPD (ver `KIT-SECURITY-SISTEM-AITMPL`).

4. **Instalei 13 dos 16 agents.** Deixei `agent-overview` (meta), `nia-oracle`
   (serviço específico) e `multi-source-searcher` — este último tem **2 downloads**,
   o componente menos usado de todo o catálogo.

---

## Arquivos

```
KIT-PESQUISA/
├── CLAUDE.md · README.md · KIT-PESQUISA.md
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/  skills/ 2 · agents/ 13 · commands/ 2
```
