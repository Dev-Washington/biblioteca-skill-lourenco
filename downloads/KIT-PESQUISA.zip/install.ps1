<#
.SYNOPSIS
  Instala este kit em um projeto existente (Windows, macOS ou Linux).
.DESCRIPTION
  Equivalente ao install.sh, em PowerShell nativo. Nao sobrescreve nada:
  arquivos que ja existem no destino sao preservados. Rodar duas vezes
  nao duplica.
.PARAMETER Destino
  Caminho do projeto onde o kit sera instalado.
.PARAMETER SemHooks
  Instala skills, agents e comandos, mas nao os hooks automaticos.
.EXAMPLE
  .\install.ps1 C:\meus-projetos\meu-app
.EXAMPLE
  .\install.ps1 /home/eu/meu-app -SemHooks
#>
[CmdletBinding()]
param(
  [Parameter(Mandatory = $true, Position = 0)]
  [string]$Destino,
  [switch]$SemHooks
)

$ErrorActionPreference = 'Stop'
$OutputEncoding = [System.Text.Encoding]::UTF8

$Kit = Split-Path -Parent $MyInvocation.MyCommand.Path

if (-not (Test-Path -LiteralPath $Destino -PathType Container)) {
  Write-Error "'$Destino' nao e um diretorio existente."
  exit 1
}
$Destino = (Resolve-Path -LiteralPath $Destino).Path
if ($Destino -eq $Kit) {
  Write-Error "O destino e o proprio kit. Escolha outro diretorio."
  exit 1
}

Write-Host "Kit:     $Kit"
Write-Host "Destino: $Destino"
Write-Host ""

foreach ($sub in 'skills', 'agents', 'commands') {
  $null = New-Item -ItemType Directory -Force -Path (Join-Path (Join-Path $Destino ".claude") $sub)
}

function Copy-Pasta {
  param([string]$Nome)
  $origem = Join-Path (Join-Path $Kit ".claude") $Nome
  if (-not (Test-Path -LiteralPath $origem)) { return }
  $add = 0; $skip = 0
  # -Force e obrigatorio: em Unix o PowerShell marca tudo sob uma pasta
  # iniciada por ponto (.claude) como oculto, e sem -Force nada e listado.
  foreach ($item in Get-ChildItem -LiteralPath $origem -Force) {
    $alvo = Join-Path (Join-Path (Join-Path $Destino ".claude") $Nome) $item.Name
    if (Test-Path -LiteralPath $alvo) { $skip++ }
    else { Copy-Item -LiteralPath $item.FullName -Destination $alvo -Recurse; $add++ }
  }
  Write-Host ("  {0}: {1} adicionado(s), {2} ja existia(m)" -f $Nome, $add, $skip)
}

Copy-Pasta 'skills'
Copy-Pasta 'agents'
Copy-Pasta 'commands'

# ---------- hooks + settings.json ----------
$kitSettings = Join-Path (Join-Path $Kit '.claude') 'settings.json'
$temHooks = Test-Path -LiteralPath $kitSettings
Write-Host ""
if ($temHooks -and $SemHooks) {
  Write-Host "  hooks: PULADOS (-SemHooks)"
}
elseif ($temHooks) {
  $kitHooksDir = Join-Path (Join-Path $Kit '.claude') 'hooks'
  if (Test-Path -LiteralPath $kitHooksDir) {
    $null = New-Item -ItemType Directory -Force -Path (Join-Path (Join-Path $Destino '.claude') 'hooks')
    foreach ($f in Get-ChildItem -LiteralPath $kitHooksDir -File -Force) {
      $alvo = Join-Path (Join-Path (Join-Path $Destino ".claude") "hooks") $f.Name
      if (Test-Path -LiteralPath $alvo) { Write-Host "  pulado (ja existe): .claude/hooks/$($f.Name)" }
      else { Copy-Item -LiteralPath $f.FullName -Destination $alvo; Write-Host "  + .claude/hooks/$($f.Name)" }
    }
  }

  $src = Get-Content -LiteralPath $kitSettings -Raw -Encoding UTF8 | ConvertFrom-Json
  $dstPath = Join-Path (Join-Path $Destino '.claude') 'settings.json'
  if (Test-Path -LiteralPath $dstPath) {
    $dst = Get-Content -LiteralPath $dstPath -Raw -Encoding UTF8 | ConvertFrom-Json
  } else {
    $dst = [pscustomobject]@{}
  }
  if (-not $dst.PSObject.Properties['hooks']) {
    $dst | Add-Member -NotePropertyName hooks -NotePropertyValue ([pscustomobject]@{}) -Force
  }

  $n = 0
  foreach ($evt in $src.hooks.PSObject.Properties.Name) {
    $existentes = @()
    if ($dst.hooks.PSObject.Properties[$evt]) { $existentes = @($dst.hooks.$evt) }
    $assinaturas = $existentes | ForEach-Object { $_ | ConvertTo-Json -Depth 20 -Compress }
    $lista = [System.Collections.ArrayList]@($existentes)
    foreach ($entrada in @($src.hooks.$evt)) {
      $a = $entrada | ConvertTo-Json -Depth 20 -Compress
      if ($assinaturas -notcontains $a) { $null = $lista.Add($entrada); $n++ }
    }
    $dst.hooks | Add-Member -NotePropertyName $evt -NotePropertyValue $lista.ToArray() -Force
  }

  if ($src.PSObject.Properties['env']) {
    if (-not $dst.PSObject.Properties['env']) {
      $dst | Add-Member -NotePropertyName env -NotePropertyValue ([pscustomobject]@{}) -Force
    }
    foreach ($k in $src.env.PSObject.Properties.Name) {
      if (-not $dst.env.PSObject.Properties[$k]) {
        $dst.env | Add-Member -NotePropertyName $k -NotePropertyValue $src.env.$k -Force
      }
    }
  }

  ($dst | ConvertTo-Json -Depth 20) | Set-Content -LiteralPath $dstPath -Encoding UTF8
  Write-Host "  settings.json: $n hook(s) adicionado(s)"
}

# ---------- CLAUDE.md ----------
Write-Host ""
$kitNome = Split-Path -Leaf $Kit
$claudeKit = Join-Path $Kit 'CLAUDE.md'
$claudeDst = Join-Path $Destino 'CLAUDE.md'
if (Test-Path -LiteralPath $claudeKit) {
  if (Test-Path -LiteralPath $claudeDst) {
    $marca = "$kitNome.md"
    Copy-Item -LiteralPath $claudeKit -Destination (Join-Path (Join-Path $Destino ".claude") $marca) -Force
    $conteudo = Get-Content -LiteralPath $claudeDst -Raw -Encoding UTF8
    if ($conteudo -like "*$marca*") {
      Write-Host "CLAUDE.md: referencia ao kit ja presente"
    } else {
      Add-Content -LiteralPath $claudeDst -Value "`n@.claude/$marca" -Encoding UTF8
      Write-Host "CLAUDE.md: ja existia - kit salvo em .claude/$marca e referenciado via @import"
    }
  } else {
    Copy-Item -LiteralPath $claudeKit -Destination $claudeDst
    Write-Host "CLAUDE.md: criado"
  }
}

# ---------- .mcp.json ----------
$mcpKit = Join-Path $Kit '.mcp.json'
if (Test-Path -LiteralPath $mcpKit) {
  $src = Get-Content -LiteralPath $mcpKit -Raw -Encoding UTF8 | ConvertFrom-Json
  $qtd = 0
  if ($src.PSObject.Properties['mcpServers']) { $qtd = @($src.mcpServers.PSObject.Properties).Count }
  if ($qtd -gt 0) {
    $mcpDst = Join-Path $Destino '.mcp.json'
    if (Test-Path -LiteralPath $mcpDst) {
      $dst = Get-Content -LiteralPath $mcpDst -Raw -Encoding UTF8 | ConvertFrom-Json
      if (-not $dst.PSObject.Properties['mcpServers']) {
        $dst | Add-Member -NotePropertyName mcpServers -NotePropertyValue ([pscustomobject]@{}) -Force
      }
      $n = 0
      foreach ($k in $src.mcpServers.PSObject.Properties.Name) {
        if ($dst.mcpServers.PSObject.Properties[$k]) { Write-Host "  pulado (ja existe): mcp $k" }
        else { $dst.mcpServers | Add-Member -NotePropertyName $k -NotePropertyValue $src.mcpServers.$k -Force; $n++; Write-Host "  + mcp $k" }
      }
      if ($n -gt 0) { ($dst | ConvertTo-Json -Depth 20) | Set-Content -LiteralPath $mcpDst -Encoding UTF8 }
      Write-Host ".mcp.json: mesclado"
    } else {
      Copy-Item -LiteralPath $mcpKit -Destination $mcpDst
      Write-Host ".mcp.json: criado"
    }
  }
}
$mcpOpt = Join-Path $Kit '.mcp.optional.json'
if (Test-Path -LiteralPath $mcpOpt) {
  Copy-Item -LiteralPath $mcpOpt -Destination (Join-Path $Destino '.mcp.optional.json') -Force
}

Write-Host ""
if ($temHooks -and -not $SemHooks) {
  Write-Host "ATENCAO: este kit instalou hooks que podem BLOQUEAR comandos."
  Write-Host "         Veja a tabela em CLAUDE.md. Para desativar: edite .claude/settings.json"
  Write-Host "         Os hooks em Python usam 'python3'. No Windows, confira se o comando"
  Write-Host "         existe (geralmente e 'python') e ajuste em .claude/settings.json."
  Write-Host ""
}
Write-Host "Pronto. Abra '$Destino' no Claude Code."
