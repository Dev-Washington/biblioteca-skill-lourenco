---
description: Mostra o que este kit tem e dimensiona a pesquisa
---

Leia `CLAUDE.md` e apresente, em português:

1. Verifique o que existe **de fato**: `ls .claude/agents` · `ls .claude/skills` ·
   `cat .mcp.json`. Não liste nada que não esteja lá.

2. Explique que este kit é um **time com orquestrador**, não skills soltas, e mostre
   o fluxo: esclarecer → planejar → pesquisar → analisar → verificar → sintetizar →
   escrever.

3. **Dimensione.** Se o usuário passou uma pergunta ($ARGUMENTS), diga qual escala
   recomenda — um agent só, alguns, ou o time completo — e o custo aproximado em
   esforço. Se não passou, pergunte o que ele quer pesquisar e **que decisão depende
   do resultado**.

Seja direto.
