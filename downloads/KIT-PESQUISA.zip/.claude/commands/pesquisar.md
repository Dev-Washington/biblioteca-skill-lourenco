---
description: Conduz uma pesquisa com verificação e fontes rastreáveis
---

Pergunta: $ARGUMENTS

1. **Esclareça antes de pesquisar** — agent `query-clarifier`. Se $ARGUMENTS for
   amplo, pergunte:
   - Que decisão depende do resultado
   - Qual o recorte: período, região, setor, tecnologia
   - Que profundidade serve: panorama ou análise a fundo
   - Há fontes que o usuário já confia ou já descartou

   Pesquisar bem a pergunta errada é o desperdício maior.

2. **Dimensione e avise.** Diga qual escala vai usar — um agent, alguns, ou o time
   completo com orquestrador — e por quê. Não rode 13 agents para uma pergunta que
   um resolve.

3. **Pesquise nas frentes que fazem sentido**: `technical-researcher` (repositório,
   doc), `academic-researcher` (literatura), `data-researcher` (dados),
   `competitive-intelligence-analyst` (concorrência).

4. **Verifique** — agent `fact-checker`. Não é opcional. Marque cada afirmação como:
   - confirmada por múltiplas fontes independentes
   - fonte única
   - não verificada

5. **Sintetize** — agent `research-synthesizer`. Separe explicitamente **o que as
   fontes dizem** de **o que você conclui a partir delas**.

6. **Escreva** — agent `report-generator`. Cada afirmação com link, autor e **data**.
   Informação antiga sobre tecnologia pode estar errada hoje — marque o que é
   recente e o que não é.

7. **Feche com as lacunas**: o que você não encontrou, onde as fontes divergem, e o
   que exigiria acesso pago ou dado interno. Pesquisa que não diz onde ficou cega dá
   falsa sensação de completude.

Nunca preencha um vazio com o que parece razoável. "Não encontrei" é uma resposta
válida e útil.
