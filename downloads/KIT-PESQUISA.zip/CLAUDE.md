# Kit Pesquisa — time de pesquisa com orquestrador

**2 skills, 13 agents e 3 MCPs** em `.claude/`. Não é uma coleção de skills soltas:
é um **time** desenhado para trabalhar junto.

Fonte: [aitmpl.com](https://aitmpl.com/).

---

## Escolha a escala antes de começar

Um time de 13 agents consome muito token. **Não use o time completo para uma
pergunta simples.**

| Tamanho da pergunta | Use |
|---|---|
| Pergunta pontual, uma fonte resolve | agent `technical-researcher` sozinho |
| Assunto com alguns ângulos | 2–3 pesquisadores + `research-synthesizer` |
| Pesquisa que sustenta decisão importante | time completo com `research-orchestrator` |

Diga ao usuário qual escala você escolheu e por quê.

---

## Fluxo do time completo

| Etapa | Agent |
|---|---|
| 1. Esclarecer a pergunta | `query-clarifier` |
| 2. Planejar as frentes | `research-coordinator` ou `research-orchestrator` |
| 3. Pesquisar — técnico | `technical-researcher` |
| 3. Pesquisar — acadêmico | `academic-researcher` |
| 3. Pesquisar — dados | `data-researcher` |
| 3. Pesquisar — concorrência | `competitive-intelligence-analyst` |
| 4. Analisar quantitativo | `data-analyst`, `research-analyst` |
| 5. **Verificar** | `fact-checker` |
| 6. Sintetizar | `research-synthesizer` |
| 7. Escrever | `report-generator`, `research-brief-generator` |

A etapa 5 não é opcional. Pesquisa sem verificação é acúmulo de link.

---

## Regras

**Esclareça a pergunta antes de pesquisar.** O desperdício maior não é pesquisar
mal — é pesquisar bem a pergunta errada. Use `query-clarifier` ou pergunte
diretamente: o que o usuário vai **decidir** com o resultado.

**Toda afirmação precisa de fonte rastreável.** Link, autor, data. Sem isso você tem
um texto plausível, não uma pesquisa. Se não encontrou fonte para algo, diga
"não encontrei" em vez de preencher com o que parece razoável.

**Diga a data das fontes.** Informação de 2019 sobre tecnologia pode estar
completamente errada hoje. Marque o que é recente e o que é antigo.

**`fact-checker` não garante verdade.** Ele verifica contra as fontes que encontra.
Se as fontes estiverem erradas ou enviesadas, ele repete o erro com confiança.
Reduz risco, não elimina — diga isso quando o assunto for sensível.

**Separe achado de interpretação.** "As fontes dizem X" é diferente de "portanto Y".
Marque qual é qual no relatório.

**Declare o que não encontrou.** Uma pesquisa que não diz onde ficou cega é pior
que nenhuma — dá falsa sensação de completude.

**Scraping tem limite.** `firecrawl` e `brightdata` raspam sites de terceiros.
Verifique `robots.txt` e termos de uso. Dado pessoal tem implicação de LGPD.

## Convenções

- Declare a escala escolhida e quais agents usou.
- Ordene os achados por relevância para a decisão, não por ordem de descoberta.
