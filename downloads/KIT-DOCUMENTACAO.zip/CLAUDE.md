# Kit Documentação — API, guias e diagramas

**4 skills, 7 agents e 6 commands** em `.claude/`, para documentação técnica e
diagramas.

Fonte: [aitmpl.com](https://aitmpl.com/).

---

## Roteamento

| Assunto da tarefa | Use |
|---|---|
| Documentar API, OpenAPI, portal interativo | agent `api-documenter`, command `/doc-api` |
| Guia de usuário, referência, doc de SDK | agent `technical-writer` |
| Changelog a partir dos commits | agent `changelog-generator` |
| Site de documentação | agent `docusaurus-expert`, command `/interactive-documentation` |
| Manter a doc sincronizada com o código | command `/docs-maintenance` |
| Guia de entrada para dev novo | command `/create-onboarding-guide` |
| Guia de solução de problema | command `/troubleshooting-guide` |
| Guia de migração | command `/migration-guide` |
| Templates: README, doc de API, ADR | skill `documentation-templates` |

### Diagramas
| Assunto da tarefa | Use |
|---|---|
| Fluxo, sequência, classe, ER, estado | skill `mermaid-diagrams` |
| Arquitetura em 4 níveis (contexto → código) | skill `c4-architecture` |
| Desenhar diagrama de arquitetura | agent `diagram-architect` |
| Editar .drawio, converter PNG, ícones AWS | skill `draw-io` |

---

## Regras

**Prefira Mermaid a imagem.** Diagrama em Mermaid é texto: versiona em git, mostra
diff, qualquer um edita. Imagem PNG num repositório fica desatualizada em três meses
e ninguém tem o arquivo-fonte.

**Doc desatualizada é pior que nenhuma.** É lida com confiança e leva a decisão
errada. Antes de gerar documentação nova, pergunte quem vai manter e como. Se a
resposta for "ninguém", proponha algo menor que se sustente.

**Leia o código antes de documentar.** `api-documenter` não inventa semântica que
não existe. Se um parâmetro se chama `flag` sem descrição, a documentação vai dizer
"flag" — o problema está no código, e vale apontar isso.

**Documente a decisão, não só o resultado.** ADR — o que foi decidido, que
alternativas foram consideradas, por quê. É o que responde "por que isso foi feito
assim?" seis meses depois.

**Escreva para quem não tem o contexto.** O maior erro em doc técnica é assumir
conhecimento que só o autor tem. Nome de sistema interno, sigla, convenção do time —
explique na primeira ocorrência.

## Convenções

- Declare qual skill/agent está usando.
- Todo exemplo de código na doc precisa ter sido executado. Exemplo que não roda é
  pior que exemplo nenhum.
- Diga o que a doc **não** cobre.
