---
description: Mostra o que este kit tem e o que se aplica à sua documentação
---

Leia `CLAUDE.md` e apresente, em português:

1. Verifique o que existe **de fato**: `ls .claude/skills` · `ls .claude/agents` ·
   `ls .claude/commands`. Não liste nada que não esteja lá.

2. Resuma agrupado: escrever, manter, e diagramas.

3. Se o usuário passou um assunto ($ARGUMENTS), diga o que se aplica. Se não passou,
   pergunte **quem vai ler** a documentação e **quem vai mantê-la**. A segunda
   pergunta decide o tamanho do que vale a pena gerar.

Seja direto.
