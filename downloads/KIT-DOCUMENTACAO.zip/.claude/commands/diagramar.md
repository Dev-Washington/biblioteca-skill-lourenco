---
description: Cria diagrama do sistema — em Mermaid, versionável
---

O que diagramar: $ARGUMENTS

1. **Entenda o que o diagrama precisa comunicar e para quem.** Diagrama que tenta
   mostrar tudo não mostra nada. Pergunte:
   - Quem vai olhar (dev novo, arquiteto, cliente, auditor)
   - Que pergunta o diagrama responde
   - Que nível de detalhe importa

2. **Escolha o tipo** — skill `mermaid-diagrams`:
   - Como os componentes se relacionam → `flowchart` ou C4
   - Quem chama quem, em que ordem → `sequenceDiagram`
   - Estrutura de dados → `erDiagram`
   - Estados e transições → `stateDiagram`
   - Classes e herança → `classDiagram`

3. **Para arquitetura, use C4** — skill `c4-architecture`. Quatro níveis: contexto
   (sistema e quem usa), container (aplicações e bancos), componente (dentro de um
   container), código. **Escolha um nível.** Misturar níveis no mesmo diagrama é o
   erro mais comum.

4. **Leia o código antes de desenhar.** Diagrama que descreve a arquitetura
   pretendida em vez da real é pior que nenhum. Se o código divergir do que o
   usuário descreveu, diga.

5. **Entregue em Mermaid**, não imagem. Versiona em git, mostra diff, qualquer um
   edita. Só use `draw-io` se o usuário precisar de ícones AWS específicos ou de um
   layout que Mermaid não faz.

6. Se o diagrama ficar com mais de ~15 nós, quebre em dois. Legibilidade importa
   mais que completude.
