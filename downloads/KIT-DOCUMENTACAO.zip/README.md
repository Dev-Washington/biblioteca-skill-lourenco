# Kit Documentação — API, guias e diagramas

**4 skills, 7 agents, 8 commands** para documentação técnica e diagramas.

Origem: [aitmpl.com](https://aitmpl.com/) · **17 componentes, 5.752 downloads somados.**

---

## O recorte

O `KIT-DEVWEB-AITMPL` já tem os commands de documentação mais baixados e o agent
`documentation-expert`. Este kit é o aprofundamento: o resto da categoria
`documentation` e as skills de **diagrama**, que nenhum outro kit cobre.

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-doc`. Ou instale num projeto: `./install.sh /caminho` · `./check.sh`.

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-doc [assunto]` | Mostra o que tem; pergunta **quem lê** e **quem mantém** |
| `/diagramar [o quê]` | Diagrama em Mermaid — escolhe o tipo e o nível, lê o código antes |
| `/doc-api` · `/docs-maintenance` · `/create-onboarding-guide` | Do catálogo |
| `/troubleshooting-guide` · `/migration-guide` · `/interactive-documentation` | Do catálogo |

---

## O que está instalado

**Escrever** — `api-documenter` (1.738), `technical-writer` (1.173),
`changelog-generator` (446), `docusaurus-expert` (316),
`documentation-engineer` (189), `se-technical-writer` (65),
`documentation-templates` (68).

**Diagramas** — `mermaid-diagrams` (277), `diagram-architect` (252),
`draw-io` (191), `c4-architecture` (66).

O modelo **C4** é a forma mais útil de documentar arquitetura: quatro níveis de
zoom, do sistema no contexto até o código. `c4-architecture` gera direto em Mermaid,
que versiona em git como texto.

`create-onboarding-guide` (204) é o mais subestimado: resolve a pergunta que todo
time responde por Slack, uma pessoa por vez.

Detalhe: [KIT-DOCUMENTACAO.md](KIT-DOCUMENTACAO.md).

---

## Limitações

1. **Doc desatualizada é pior que nenhuma.** É lida com confiança e leva a decisão
   errada. O `CLAUDE.md` instrui a IA a perguntar **quem vai manter** antes de gerar.

2. **`api-documenter` não inventa semântica.** Se o parâmetro se chama `flag` e não
   tem descrição, a doc vai dizer "flag". O problema está no código.

3. **Sem MCP.** Este kit não tem MCP — `.mcp.json` está vazio de propósito.

4. **`documentation-templates` (68) e `se-technical-writer` (65)** são pouco
   testados. Os pesos são `api-documenter` (1.738) e `technical-writer` (1.173).

---

## Arquivos

```
KIT-DOCUMENTACAO/
├── CLAUDE.md · README.md · KIT-DOCUMENTACAO.md
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/  skills/ 4 · agents/ 7 · commands/ 8
```
