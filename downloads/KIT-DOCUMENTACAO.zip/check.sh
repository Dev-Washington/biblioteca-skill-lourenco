#!/usr/bin/env bash
# Verifica se o KIT-DOCUMENTACAO esta completo.
cd "$(dirname "${BASH_SOURCE[0]}")"
ok=0; fail=0
chk(){ if [ -e "$2" ]; then ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }
echo "== Skills (4) =="
for s in c4-architecture documentation-templates draw-io mermaid-diagrams; do chk "skill $s" ".claude/skills/$s/SKILL.md"; done
echo "== Agents (7) =="
for a in api-documenter changelog-generator diagram-architect documentation-engineer docusaurus-expert se-technical-writer technical-writer; do chk "agent $a" ".claude/agents/$a.md"; done
echo "== Commands (8) =="
for c in create-onboarding-guide diagramar doc-api docs-maintenance interactive-documentation kit-doc migration-guide troubleshooting-guide; do chk "/$c" ".claude/commands/$c.md"; done
echo "== Config =="
chk "CLAUDE.md" "CLAUDE.md"
chk "README.md" "README.md"
chk "KIT-DOCUMENTACAO.md" "KIT-DOCUMENTACAO.md"
chk ".mcp.json" ".mcp.json"
chk ".mcp.optional.json" ".mcp.optional.json"
node -e 'JSON.parse(require("fs").readFileSync(".mcp.json","utf8"))' 2>/dev/null \
  && echo "  .mcp.json: JSON valido" || { echo "  .mcp.json: INVALIDO"; fail=$((fail+1)); }

echo
echo "  ativos:   $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo "  opcionais: $(node -e 'const m=JSON.parse(require("fs").readFileSync(".mcp.optional.json","utf8"));console.log(Object.keys(m.mcpServers||{}).join(", ")||"(nenhum)")')"
echo
echo "== Ferramentas =="
for t in node npx; do
  if command -v "$t" >/dev/null 2>&1; then echo "  ok       $t"; else echo "  ausente  $t"; fi
done
echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
