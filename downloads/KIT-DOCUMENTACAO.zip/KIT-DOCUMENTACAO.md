# Kit Documentação — API, guias e diagramas

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) · Data: 26/08/2026
> Repositório: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)

**17 componentes · 5.752 downloads somados.**

---

## 1. O recorte

O `KIT-DEVWEB-AITMPL` já tem os commands de documentação mais baixados
(`create-architecture-documentation`, `update-docs`, `generate-api-documentation`) e
o agent `documentation-expert`. Este kit é o aprofundamento: o resto da categoria
`documentation` (11 agents) e as skills de **diagrama**, que nenhum outro kit cobre.

---

## 2. Componentes

### Escrever
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `documentation/api-documenter` | agent | OpenAPI, portal interativo, referência de API | 1.738 |
| `documentation/technical-writer` | agent | Referência, guia de usuário, doc de SDK | 1.173 |
| `documentation/changelog-generator` | agent | Changelog a partir do histórico de commit | 446 |
| `documentation/docusaurus-expert` | agent | Site de documentação com Docusaurus | 316 |
| `documentation/documentation-engineer` | agent | Engenharia de documentação | 189 |
| `documentation/se-technical-writer` | agent | Escrita técnica | 65 |
| `document-processing/documentation-templates` | skill | Templates: README, doc de API, ADR | 68 |

### Diagramas — o que nenhum outro kit tem
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `creative-design/mermaid-diagrams` | skill | Mermaid: classe, sequência, fluxo, ER, estado | 277 |
| `documentation/diagram-architect` | agent | Desenho de diagrama de arquitetura | 252 |
| `creative-design/draw-io` | skill | draw.io: editar XML, converter PNG, ícones AWS | 191 |
| `creative-design/c4-architecture` | skill | Modelo C4 em Mermaid — contexto, container, componente | 66 |

O modelo C4 é a forma mais útil de documentar arquitetura: quatro níveis de zoom, do
sistema no contexto até o código. `c4-architecture` gera direto em Mermaid, que
versiona em git como texto.

### Commands
`docs-maintenance` (304) · `create-onboarding-guide` (204) · `doc-api` (195) ·
`troubleshooting-guide` (97) · `interactive-documentation` (95) ·
`migration-guide` (76)

`create-onboarding-guide` é o mais subestimado: guia de entrada para desenvolvedor
novo, com setup de ambiente e fluxo de trabalho. Resolve a pergunta que todo time
responde por Slack, uma pessoa por vez.

---

## 3. Ressalvas honestas

1. **Documentação desatualizada é pior que nenhuma.** Ela é lida com confiança e
   leva a decisão errada. Se você não vai manter, não gere. O command
   `docs-maintenance` existe justamente para isso — use-o de verdade.

2. **Gerar doc de API a partir do código só funciona se o código tiver os tipos e
   comentários certos.** `api-documenter` não inventa semântica que não existe: se o
   parâmetro se chama `flag` e não tem descrição, a doc vai dizer "flag".

3. **`documentation-templates` tem 68 downloads** e `se-technical-writer` tem 65 —
   pouco testados. Os pesos do kit são `api-documenter` (1.738) e
   `technical-writer` (1.173).

4. **Overlap com o `KIT-DEVWEB-AITMPL`.** Se você já instalou aquele, os commands
   `create-architecture-documentation`, `update-docs` e `generate-api-documentation`
   já estão lá — não estão duplicados aqui.

---

## 4. Instalação

```bash
npx claude-code-templates@latest --agent documentation/api-documenter --yes
npx claude-code-templates@latest --agent documentation/technical-writer --yes
npx claude-code-templates@latest --skill creative-design/mermaid-diagrams --yes
npx claude-code-templates@latest --skill creative-design/c4-architecture --yes
```
