# Kit Mobile — iOS + Android

Este projeto tem um kit de skills, agents e MCPs instalado em `.claude/`, voltado
a construir, testar e publicar um app para **iOS e Android**.

Fonte: [aitmpl.com](https://aitmpl.com/) (`claude-code-templates`).

---

## Como usar este kit

As skills abaixo **não** precisam ser instaladas nem carregadas manualmente: elas já
estão em `.claude/skills/` e são ativadas sozinhas quando o assunto aparece na
conversa. Os agents em `.claude/agents/` são despachados via Task/Agent.

**Antes de escrever código de app, consulte a tabela de roteamento.** Se o assunto
da tarefa bate com uma linha, use a skill/agent correspondente em vez de improvisar.

---

## Roteamento — qual usar para quê

### Decisão e arquitetura
| Assunto da tarefa | Use |
|---|---|
| Escolher stack, desenhar arquitetura, trade-offs, diagramas | skill `senior-architect` |
| Navegação, state management, native modules, offline-first em RN/Expo | skill `react-native-architecture` |
| App cross-platform (RN/Flutter), performance nativa, deep linking, push | agent `mobile-developer` |
| iOS nativo: Swift, SwiftUI, UIKit, Core Data, ciclo de vida | agent `ios-developer` |
| Android/Kotlin: coroutines, Flow, Multiplatform (KMM), Compose | agent `kotlin-specialist` |

### Design e interface
| Assunto da tarefa | Use |
|---|---|
| Design mobile-first: toque, gestos, convenções iOS vs Android, performance percebida | skill `mobile-design` |
| Construir/revisar UI: estilos, paletas, tipografia, componentes, acessibilidade visual | skill `ui-ux-pro-max` |

### Backend, auth e pagamento
| Assunto da tarefa | Use |
|---|---|
| Firebase: CLI, config de projeto, auth, push, banco | skill `firebase-basics` |
| Postgres/Supabase: schema, índices, RLS, performance de query | skill `supabase-postgres-best-practices` |
| Pagamentos, assinaturas, billing portal, webhooks, dunning | skill `stripe-integration` |

### Qualidade
| Assunto da tarefa | Use |
|---|---|
| Review de código (TS, JS, Swift, Kotlin, Go), segurança, boas práticas | skill `code-reviewer` |
| Padrões de teste end-to-end confiáveis | skill `e2e-testing-patterns` |
| Montar suíte unit + integração + e2e com CI | agent `test-automator` |
| Auditoria de acessibilidade WCAG 2.2 (exigido pelas duas lojas) | agent `accessibility-tester` |

### Publicação e crescimento
| Assunto da tarefa | Use |
|---|---|
| Deploy Expo/EAS para produção | skill `expo-deployment` |
| Pipeline Android → Google Play: keystore, secrets, trilhas, versionCode | skill `android-cicd` |
| ASO: título, keywords, screenshots, ranking nas duas lojas | skill `app-store-optimization` |
| Onboarding pós-cadastro, ativação, time-to-value | skill `onboarding-cro` |
| Plano de medição, eventos, GA4/GTM, tracking | skill `analytics-tracking` |

---

## MCPs

`.mcp.json` traz o **ios-simulator** ativo — permite abrir o app no Simulator,
tirar screenshot e inspecionar a tela. Use-o para **verificar visualmente** o que
você construiu, em vez de só entregar código sem conferir.

`.mcp.optional.json` guarda os que exigem setup (`android-mcp`, `supabase`,
`stripe`). Veja `README.md` para ativá-los.

---

## Lacunas conhecidas — não invente que existe skill para isso

- **Não há skill de CI/CD para iOS** no catálogo. Fastlane, certificados,
  provisioning profiles e TestFlight precisam ser feitos manualmente.
- `android-cicd`, `expo-deployment`, `firebase-basics` e `e2e-testing-patterns`
  têm pouquíssimos downloads na origem — trate como ponto de partida, valide
  antes de confiar.

## Convenções

- Sempre declare qual skill/agent está usando antes de aplicar a recomendação.
- Se duas skills conflitarem, `senior-architect` decide arquitetura e
  `mobile-design` decide interação; diga o conflito ao usuário.
- Não instale novos componentes do aitmpl.com sem o usuário pedir.
