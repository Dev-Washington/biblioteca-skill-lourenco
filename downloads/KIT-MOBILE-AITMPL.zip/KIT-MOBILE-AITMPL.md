# Kit de Skills para App iOS + Android — aitmpl.com

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) (arquivo `components.json`, que alimenta o site).
> Repositório de origem: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)
> Data da análise: 26/08/2026

---

## 1. O que existe no catálogo

| Tipo | Quantidade |
|---|---|
| Skills | 872 |
| Agents | 422 |
| Commands | 286 |
| MCPs | 101 |
| Settings | 71 |
| Hooks | 62 |
| Loops | 18 |
| Templates | 14 |

Categorias de skills mais relevantes para o nosso caso: `development` (227), `web-development` (30), `creative-design` (33), `business-marketing` (48), `database` (12).

Depois de filtrar todo o catálogo por termos mobile (`ios`, `android`, `flutter`, `react native`, `swift`, `kotlin`, `expo`, `app store`, `play store`, etc.), sobraram **31 skills, 57 agents, 4 MCPs, 5 hooks e 11 settings** com alguma relevância. Abaixo está a seleção do que realmente vale a pena.

---

## 2. Kit essencial — instale estes primeiro

São os cinco componentes de maior impacto e maior base de uso. Servem para qualquer stack (React Native, Flutter ou nativo).

| Componente | Tipo | Por quê | Downloads |
|---|---|---|---|
| `creative-design/mobile-design` | skill | Design mobile-first: toque, gestos, performance, convenções iOS vs Android. Ensina princípios, não valores fixos | 2.263 |
| `development-team/mobile-developer` | agent | Cross-platform (RN/Flutter) com foco em >80% de código compartilhado e arquitetura offline-first | 2.006 |
| `creative-design/ui-ux-pro-max` | skill | 50 estilos, 21 paletas, 50 pares de fontes, 20 gráficos. Já suporta SwiftUI, React Native e Flutter | 6.790 |
| `development/senior-architect` | skill | Decide o stack e desenha a arquitetura (RN, Swift, Kotlin, Flutter, Postgres, GraphQL). Gera diagramas | 5.217 |
| `development/code-reviewer` | skill | Review em TypeScript, JavaScript, Swift, Kotlin, Go — cobre os três mundos do app | 8.384 |

```bash
npx claude-code-templates@latest --skill creative-design/mobile-design --yes
npx claude-code-templates@latest --agent development-team/mobile-developer --yes
npx claude-code-templates@latest --skill creative-design/ui-ux-pro-max --yes
npx claude-code-templates@latest --skill development/senior-architect --yes
npx claude-code-templates@latest --skill development/code-reviewer --yes
```

---

## 3. Escolha por stack

### React Native / Expo — recomendado
Um código, duas lojas. Melhor relação esforço/resultado para MVP.

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `web-development/react-native-architecture` | skill | Navegação, state management, native modules, offline-first | 55 |
| `web-development/expo-deployment` | skill | Deploy para produção via EAS | 14 |
| `development-team/mobile-developer` | agent | Já está no kit essencial | 2.006 |

```bash
npx claude-code-templates@latest --skill web-development/react-native-architecture --yes
npx claude-code-templates@latest --skill web-development/expo-deployment --yes
```

### Flutter

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development/flutter-expert` | skill | Dart 3, widgets avançados, deploy multi-plataforma | 93 |
| `programming-languages/flutter-expert` | agent | State management complexo, integrações nativas, performance iOS/Android/Web | 161 |

```bash
npx claude-code-templates@latest --skill development/flutter-expert --yes
npx claude-code-templates@latest --agent programming-languages/flutter-expert --yes
```

### Nativo — só se precisar de performance ou APIs específicas

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development-team/ios-developer` | agent | Swift/SwiftUI, UIKit, Core Data, ciclo de vida do app | 664 |
| `programming-languages/swift-expert` | agent | Concorrência avançada, protocol-oriented, actors, memory safety | 82 |
| `programming-languages/kotlin-specialist` | agent | Coroutines, Kotlin Multiplatform, Android + server-side | 124 |
| `development/swift-concurrency-expert` | skill | Corrige actor isolation e violações de Sendable | 9 |
| `development/kotlin-coroutines-expert` | skill | Structured concurrency, Flow, tratamento de erro, testes | 9 |
| `development-team/mobile-app-developer` | agent | Cobre nativo iOS + nativo Android no mesmo projeto | 305 |

```bash
npx claude-code-templates@latest --agent development-team/ios-developer --yes
npx claude-code-templates@latest --agent programming-languages/kotlin-specialist --yes
npx claude-code-templates@latest --skill development/swift-concurrency-expert --yes
npx claude-code-templates@latest --skill development/kotlin-coroutines-expert --yes
```

---

## 4. MCPs — controle real dos dispositivos

Maior ganho prático do kit: com estes dois a IA roda o app, tira screenshot e verifica o resultado sozinha, em vez de só escrever código no escuro.

| Componente | O que faz | Downloads |
|---|---|---|
| `devtools/ios-simulator-mcp` | Controla o iOS Simulator: abre apps, screenshots, gerencia estados de device | 311 |
| `devtools/android-mcp` | Controla dispositivos Android via ADB: inspeção e automação | 22 |

```bash
npx claude-code-templates@latest --mcp devtools/ios-simulator-mcp --yes
npx claude-code-templates@latest --mcp devtools/android-mcp --yes
```

---

## 5. Backend, autenticação e pagamento

Escolha **um** dos dois caminhos.

### Caminho rápido — Firebase
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development/firebase-basics` | skill | Firebase CLI, configuração de projeto, auth, push, banco | 6 |

### Caminho Postgres — Supabase + Stripe
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `database/supabase` | MCP | Conecta a IA direto ao seu projeto Supabase | — |
| `database/supabase-postgres-best-practices` | skill | Performance e boas práticas de Postgres | — |
| `development/stripe-integration` | skill | Pagamentos, assinaturas, billing portal, webhooks | — |
| `devtools/stripe` | MCP | Acesso à API do Stripe pela IA | — |

```bash
# Firebase
npx claude-code-templates@latest --skill development/firebase-basics --yes

# ou Supabase + Stripe
npx claude-code-templates@latest --mcp database/supabase --yes
npx claude-code-templates@latest --skill development/stripe-integration --yes
```

---

## 6. Publicação, qualidade e crescimento

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `development/android-cicd` | skill | Pipeline para Google Play: keystore, GitHub Secrets, trilhas internal/alpha/beta/production, auto-bump de versionCode | 11 |
| `business-marketing/app-store-optimization` | skill | ASO para App Store e Play Store: pesquisa, otimização, acompanhamento | 101 |
| `accessibility/accessibility-tester` | agent | Auditoria WCAG 2.2 — exigência prática nas duas lojas | 59 |
| `performance-testing/test-automator` | agent | Suíte unit + integração + e2e, com CI | 825 |
| `development/e2e-testing-patterns` | skill | Testes end-to-end confiáveis e rápidos | — |
| `business-marketing/onboarding-cro` | skill | Otimiza o onboarding pós-cadastro e o time-to-value | — |
| `business-marketing/analytics-tracking` | skill | Define e audita o plano de medição do app | — |

```bash
npx claude-code-templates@latest --skill development/android-cicd --yes
npx claude-code-templates@latest --skill business-marketing/app-store-optimization --yes
npx claude-code-templates@latest --agent accessibility/accessibility-tester --yes
npx claude-code-templates@latest --agent performance-testing/test-automator --yes
```

---

## 7. Sintaxe de instalação

```bash
npx claude-code-templates@latest --skill   <categoria>/<nome> --yes
npx claude-code-templates@latest --agent   <categoria>/<nome> --yes
npx claude-code-templates@latest --mcp     <categoria>/<nome> --yes
npx claude-code-templates@latest --command <categoria>/<nome> --yes
npx claude-code-templates@latest --setting <categoria>/<nome> --yes
```

---

## 8. Ressalvas honestas

1. **Popularidade varia muito.** `android-cicd` (11 downloads), `expo-deployment` (14), `firebase-basics` (6), `swift-concurrency-expert` (9) e `kotlin-coroutines-expert` (9) são pouco usados — provavelmente pouco testados na prática. Trate-os como ponto de partida, não como verdade. Os cinco do kit essencial têm de 2 mil a 8 mil instalações.
2. **Não existe skill de CI/CD para iOS no catálogo.** Só o lado Android está coberto. Fastlane, certificados, provisioning profiles e TestFlight terão que ser montados manualmente.
3. **Há duplicatas com o mesmo nome em categorias diferentes** (`flutter-expert` existe como skill e como agent; `accessibility-tester` e `test-automator` aparecem em duas categorias cada). Sempre instale usando o caminho completo `categoria/nome`.
4. **Skill vs agent.** Skill é conhecimento que a IA carrega no contexto quando o assunto aparece. Agent é um executor separado, com prompt e ferramentas próprias, que recebe uma tarefa e devolve o resultado. Para montar um app você quer os dois: skills para as decisões, agents para as execuções longas.

---

## 9. Resumo — o que instalar agora

Para um app iOS + Android em React Native/Expo com login e pagamento, este é o conjunto mínimo completo:

```bash
# Base
npx claude-code-templates@latest --skill creative-design/mobile-design --yes
npx claude-code-templates@latest --skill creative-design/ui-ux-pro-max --yes
npx claude-code-templates@latest --skill development/senior-architect --yes
npx claude-code-templates@latest --skill development/code-reviewer --yes
npx claude-code-templates@latest --agent development-team/mobile-developer --yes

# Stack
npx claude-code-templates@latest --skill web-development/react-native-architecture --yes
npx claude-code-templates@latest --skill web-development/expo-deployment --yes

# Dispositivos
npx claude-code-templates@latest --mcp devtools/ios-simulator-mcp --yes
npx claude-code-templates@latest --mcp devtools/android-mcp --yes

# Backend e pagamento
npx claude-code-templates@latest --mcp database/supabase --yes
npx claude-code-templates@latest --skill development/stripe-integration --yes

# Publicação e qualidade
npx claude-code-templates@latest --skill development/android-cicd --yes
npx claude-code-templates@latest --skill business-marketing/app-store-optimization --yes
npx claude-code-templates@latest --agent performance-testing/test-automator --yes
npx claude-code-templates@latest --agent accessibility/accessibility-tester --yes
```
