#!/usr/bin/env bash
# Instala o Kit Mobile em um projeto existente.
# Uso:  ./install.sh /caminho/do/seu/projeto
set -euo pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:-}"

if [ -z "$DEST" ]; then
  echo "uso: $0 /caminho/do/projeto" >&2
  exit 1
fi
if [ ! -d "$DEST" ]; then
  echo "erro: '$DEST' não é um diretório" >&2
  exit 1
fi
DEST="$(cd "$DEST" && pwd)"
if [ "$DEST" = "$KIT" ]; then
  echo "erro: destino é o próprio kit; nada a fazer" >&2
  exit 1
fi

echo "Kit:     $KIT"
echo "Destino: $DEST"
echo

mkdir -p "$DEST/.claude/skills" "$DEST/.claude/agents" "$DEST/.claude/commands"

copy_dir() { # $1 = subpasta de .claude
  local src="$KIT/.claude/$1" name
  [ -d "$src" ] || return 0
  for path in "$src"/*; do
    [ -e "$path" ] || continue
    name="$(basename "$path")"
    if [ -e "$DEST/.claude/$1/$name" ]; then
      echo "  pulado (já existe): .claude/$1/$name"
    else
      cp -R "$path" "$DEST/.claude/$1/$name"
      echo "  + .claude/$1/$name"
    fi
  done
}

echo "skills:";   copy_dir skills
echo "agents:";   copy_dir agents
echo "commands:"; copy_dir commands

# CLAUDE.md — nunca sobrescreve o do projeto
echo
if [ -f "$DEST/CLAUDE.md" ]; then
  cp "$KIT/CLAUDE.md" "$DEST/.claude/KIT-MOBILE.md"
  if grep -q "KIT-MOBILE.md" "$DEST/CLAUDE.md"; then
    echo "CLAUDE.md: referência ao kit já presente"
  else
    printf '\n@.claude/KIT-MOBILE.md\n' >> "$DEST/CLAUDE.md"
    echo "CLAUDE.md: já existia — kit salvo em .claude/KIT-MOBILE.md e referenciado via @import"
  fi
else
  cp "$KIT/CLAUDE.md" "$DEST/CLAUDE.md"
  echo "CLAUDE.md: criado"
fi

# .mcp.json — merge sem sobrescrever servidores existentes
if [ -f "$KIT/.mcp.json" ]; then
  if [ -f "$DEST/.mcp.json" ]; then
    node -e '
      const fs=require("fs"), [dst,src]=process.argv.slice(1);
      const d=JSON.parse(fs.readFileSync(dst,"utf8"));
      const s=JSON.parse(fs.readFileSync(src,"utf8"));
      d.mcpServers=d.mcpServers||{};
      let n=0;
      for(const [k,v] of Object.entries(s.mcpServers||{})){
        if(k in d.mcpServers){ console.log("  pulado (já existe): mcp "+k); }
        else { d.mcpServers[k]=v; n++; console.log("  + mcp "+k); }
      }
      if(n) fs.writeFileSync(dst,JSON.stringify(d,null,2)+"\n");
    ' "$DEST/.mcp.json" "$KIT/.mcp.json"
    echo ".mcp.json: mesclado"
  else
    cp "$KIT/.mcp.json" "$DEST/.mcp.json"
    echo ".mcp.json: criado"
  fi
fi
cp "$KIT/.mcp.optional.json" "$DEST/.mcp.optional.json" 2>/dev/null || true

echo
echo "Pronto. Abra '$DEST' no Claude Code e rode /kit-mobile."
