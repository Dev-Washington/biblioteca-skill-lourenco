---
description: Inicia um app iOS + Android do zero usando as skills do kit, na ordem certa
---

O usuário quer começar um app mobile novo. Descrição: $ARGUMENTS

Conduza assim, **usando as skills instaladas em `.claude/skills/`** a cada passo e
dizendo qual está usando:

1. **Entender o escopo.** Se $ARGUMENTS estiver vazio ou vago, pergunte: o que o
   app faz, quem usa, precisa de login, precisa de pagamento, precisa funcionar
   offline. Não avance sem isso.

2. **Arquitetura** — skill `senior-architect` + skill `react-native-architecture`
   (ou o agent nativo, se o caso pedir). Recomende **um** stack e justifique.
   Entregue a estrutura de pastas e as decisões principais.

3. **Backend e auth** — skill `firebase-basics` **ou**
   `supabase-postgres-best-practices`. Escolha um caminho, não os dois. Se houver
   cobrança, some a skill `stripe-integration`.

4. **Design** — skill `mobile-design` para as decisões de interação e convenção
   de plataforma, skill `ui-ux-pro-max` para o visual concreto.

5. **Scaffold.** Só depois dos passos acima, crie o projeto de fato.

6. **Verificação.** Se o MCP `ios-simulator` estiver disponível, rode o app e tire
   screenshot para confirmar o resultado. Se não estiver, diga isso ao usuário em
   vez de afirmar que funcionou.

Ao final, liste o que ficou pendente (testes, CI/CD, ASO) e aponte a skill de cada.
