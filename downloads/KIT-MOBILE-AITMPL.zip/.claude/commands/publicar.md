---
description: Prepara o app para publicação na App Store e Google Play
---

Alvo: $ARGUMENTS  (ex.: "ios", "android", "ambos" — se vazio, pergunte)

Use as skills do kit e diga qual está aplicando em cada etapa:

1. **Qualidade antes de publicar**
   - skill `code-reviewer` — passe pelo código que vai à loja.
   - agent `accessibility-tester` — auditoria WCAG 2.2. As duas lojas cobram isso.
   - agent `test-automator` + skill `e2e-testing-patterns` — cobertura mínima.

2. **Build e distribuição**
   - Expo/EAS → skill `expo-deployment`.
   - Android → skill `android-cicd` (keystore, GitHub Secrets, trilhas
     internal/alpha/beta/production, auto-bump de versionCode).
   - **iOS:** não existe skill de CI/CD para iOS neste kit. Fastlane, certificados,
     provisioning profiles e TestFlight precisam ser montados à mão — avise o
     usuário disso explicitamente, não finja que há automação pronta.

3. **Ficha da loja** — skill `app-store-optimization`: título, subtítulo, keywords,
   screenshots, descrição, para App Store e Play Store.

4. **Pós-lançamento** — skill `analytics-tracking` (plano de medição) e skill
   `onboarding-cro` (ativação dos primeiros usuários).

Entregue um checklist final com o que está pronto e o que falta.
