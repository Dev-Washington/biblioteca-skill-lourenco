---
description: Mostra o que o Kit Mobile tem instalado e como cada peça se aplica à tarefa atual
---

Leia `CLAUDE.md` na raiz do projeto e apresente ao usuário, em português:

1. Um resumo do que está instalado — quantas skills, agents e MCPs, agrupados por
   finalidade (arquitetura, design, backend, qualidade, publicação).
2. Verifique de fato o que existe em disco antes de responder:
   - `ls .claude/skills`
   - `ls .claude/agents`
   - `cat .mcp.json`
   Não liste nada que não esteja lá.
3. Se o usuário passou um assunto como argumento ($ARGUMENTS), diga exatamente
   quais skills/agents se aplicam a ele e por quê. Se não passou, pergunte em que
   ponto do app ele está (ideia, arquitetura, UI, backend, testes, publicação) e
   recomende o caminho.

Seja direto. Sem repetir a tabela inteira do CLAUDE.md — só o que é relevante.
