# Kit Mobile — iOS + Android

Kit pronto de skills, agents e MCPs para construir, testar e publicar um app
mobile com o Claude Code. Tudo já instalado nesta pasta — não precisa rodar `npx`
de novo.

Origem dos componentes: [aitmpl.com](https://aitmpl.com/) · repositório
[davila7/claude-code-templates](https://github.com/davila7/claude-code-templates).

---

## Como usar

### Opção A — trabalhar dentro desta pasta
Abra esta pasta no Claude Code. As skills, agents e comandos carregam sozinhos.

```
claude
```
Depois rode `/kit-mobile` para ver o que está disponível.

### Opção B — instalar num projeto existente

```bash
./install.sh /caminho/do/seu/projeto
```

### Windows (PowerShell)

```powershell
.\install.ps1 C:\caminho\do\seu\projeto
```

Se o Windows bloquear a execução do script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Isso libera só a sessão atual — não altera a política da máquina.

### macOS e Linux

```bash
chmod +x install.sh check.sh    # só na primeira vez
./install.sh /caminho/do/seu/projeto
./check.sh
```

O `install.ps1` também roda no macOS e no Linux, se você tiver PowerShell 7+.

O script copia skills, agents e comandos, e é seguro: **não sobrescreve nada**.
Se o destino já tiver `CLAUDE.md`, o do kit vai para `.claude/KIT-MOBILE.md` e
é referenciado por `@import` no final do arquivo existente. Se já tiver
`.mcp.json`, os servidores são mesclados sem apagar os seus. Rodar duas vezes não
duplica nada.

### Conferir a instalação

```bash
./check.sh
```

Lista o que está presente e quais dependências externas faltam na sua máquina.

---

## Comandos disponíveis

| Comando | O que faz |
|---|---|
| `/kit-mobile [assunto]` | Mostra o que está instalado e o que se aplica ao seu caso |
| `/novo-app [descrição]` | Conduz um app do zero: arquitetura → backend → design → scaffold |
| `/publicar [ios\|android\|ambos]` | Checklist de qualidade, build e ficha da loja |

Fora dos comandos, é só conversar normalmente — as skills ativam sozinhas quando
o assunto aparece.

---

## O que está instalado

**14 skills** (`.claude/skills/`)

| Skill | Para quê |
|---|---|
| `mobile-design` | Design mobile-first: toque, gestos, convenções iOS vs Android |
| `ui-ux-pro-max` | Estilos, paletas, tipografia, componentes; suporta SwiftUI/RN/Flutter |
| `senior-architect` | Escolha de stack, arquitetura, trade-offs, diagramas |
| `code-reviewer` | Review em TS, JS, Python, Swift, Kotlin, Go |
| `react-native-architecture` | Navegação, state, native modules, offline-first |
| `expo-deployment` | Deploy via EAS |
| `android-cicd` | Pipeline Google Play: keystore, secrets, trilhas, versionCode |
| `app-store-optimization` | ASO nas duas lojas |
| `firebase-basics` | Firebase CLI, auth, push, banco |
| `supabase-postgres-best-practices` | Schema, índices, RLS, performance |
| `stripe-integration` | Pagamentos, assinaturas, webhooks, dunning |
| `e2e-testing-patterns` | Testes end-to-end confiáveis |
| `onboarding-cro` | Ativação e time-to-value |
| `analytics-tracking` | Plano de medição e eventos |

**5 agents** (`.claude/agents/`)

| Agent | Para quê |
|---|---|
| `mobile-developer` | Cross-platform RN/Flutter, performance, push, deep linking |
| `ios-developer` | Swift, SwiftUI, UIKit, Core Data |
| `kotlin-specialist` | Coroutines, Flow, KMM, Android |
| `test-automator` | Suíte unit + integração + e2e com CI |
| `accessibility-tester` | Auditoria WCAG 2.2 |

---

## MCPs

### Ativo — `.mcp.json`

| Servidor | O que faz | Requisitos |
|---|---|---|
| `ios-simulator` | Abre apps no Simulator, tira screenshot, gerencia devices | Xcode instalado |

Com ele a IA **verifica visualmente** o que construiu, em vez de entregar código
sem conferir.

### Opcionais — `.mcp.optional.json`

Ficam fora do `.mcp.json` de propósito: exigem credenciais ou dependências que
você ainda pode não ter, e apareceriam como erro de conexão a cada sessão.

| Servidor | Requisitos |
|---|---|
| `android-mcp` | `brew install uv` + Android SDK Platform-Tools (`adb`) + device/emulador |
| `supabase` | Personal access token e project-ref do Supabase |
| `stripe` | Chave secreta do Stripe |

Para ativar um deles: preencha os placeholders em `.mcp.optional.json` e mova o
bloco para `.mcp.json`. Ou use a CLI:

```bash
npx claude-code-templates@latest --mcp devtools/android-mcp --yes
```

> **Segurança:** o bloco do `supabase` vem com `--read-only` e o do `stripe` pede
> uma chave secreta. Use chave de teste (`sk_test_...`) enquanto desenvolve e não
> versione o `.mcp.json` preenchido.

---

## Limitações — leia antes de confiar

1. **Não existe skill de CI/CD para iOS neste catálogo.** Só o lado Android está
   coberto. Fastlane, certificados, provisioning profiles e TestFlight terão que
   ser feitos manualmente.
2. **Popularidade desigual.** `firebase-basics` (6 downloads na origem),
   `android-cicd` (11), `expo-deployment` (14) e `e2e-testing-patterns` (18) são
   pouco usados — provavelmente pouco testados na prática. Trate como ponto de
   partida, não como verdade. Já `code-reviewer` (8.4k), `ui-ux-pro-max` (6.8k),
   `senior-architect` (5.2k) e `mobile-design` (2.3k) têm base larga.
3. **Firebase e Supabase estão os dois instalados.** São caminhos alternativos —
   escolha um por projeto; o `/novo-app` força essa escolha.
4. Componentes vêm de terceiros. Revise o que for executar, especialmente scripts.

---

## Arquivos

```
KIT-MOBILE-AITMPL/
├── CLAUDE.md               contexto carregado automaticamente (tabela de roteamento)
├── README.md               este arquivo
├── KIT-MOBILE-AITMPL.md    análise do catálogo que originou a seleção
├── install.sh              instala o kit em outro projeto
├── check.sh                verifica instalação e dependências
├── .mcp.json               MCP pronto para uso
├── .mcp.optional.json      MCPs que precisam de setup
└── .claude/
    ├── skills/             14 skills
    ├── agents/             5 agents
    └── commands/           /kit-mobile, /novo-app, /publicar
```

## Atualizar um componente

```bash
npx claude-code-templates@latest --skill <categoria>/<nome> --yes
npx claude-code-templates@latest --agent <categoria>/<nome> --yes
```

Rode a partir desta pasta — a CLI escreve em `.claude/` do diretório atual.
