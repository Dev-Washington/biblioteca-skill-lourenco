#!/usr/bin/env bash
# Verifica se o kit está completo e quais dependências externas faltam.
cd "$(dirname "${BASH_SOURCE[0]}")"

ok=0; fail=0
chk() { if [ -e "$2" ]; then echo "  ok    $1"; ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }

echo "== Skills =="
for s in mobile-design ui-ux-pro-max senior-architect code-reviewer \
         react-native-architecture expo-deployment stripe-integration android-cicd \
         app-store-optimization supabase-postgres-best-practices e2e-testing-patterns \
         onboarding-cro analytics-tracking firebase-basics; do
  chk "$s" ".claude/skills/$s/SKILL.md"
done

echo "== Agents =="
for a in mobile-developer test-automator accessibility-tester ios-developer kotlin-specialist; do
  chk "$a" ".claude/agents/$a.md"
done

echo "== Commands =="
for c in kit-mobile novo-app publicar; do chk "/$c" ".claude/commands/$c.md"; done

echo "== Config =="
chk "CLAUDE.md"          "CLAUDE.md"
chk ".mcp.json"          ".mcp.json"
chk ".mcp.optional.json" ".mcp.optional.json"

echo
echo "== Dependências externas =="
dep() { if command -v "$1" >/dev/null 2>&1; then echo "  ok       $1 — $2"; else echo "  ausente  $1 — $2 ($3)"; fi; }
dep node  "necessário para tudo"                 "instale via https://nodejs.org"
dep npx   "roda os MCPs em Node"                 "vem com o node"
dep xcrun "MCP ios-simulator"                    "instale o Xcode"
dep uvx   "MCP android-mcp (opcional)"           "brew install uv"
dep adb   "MCP android-mcp (opcional)"           "instale o Android SDK Platform-Tools"

echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
