# Kit de Segurança — App, Sistema, CRM e Site

Kit pronto de segurança para o Claude Code: **29 skills, 15 agents, 13 commands,
8 hooks e 4 MCPs**. Tudo já instalado nesta pasta — não precisa rodar `npx` de novo.

Origem: [aitmpl.com](https://aitmpl.com/) · repositório
[davila7/claude-code-templates](https://github.com/davila7/claude-code-templates).

---

## Leia isto primeiro

**1. Este kit instala 8 hooks que bloqueiam comandos de verdade.** Não são avisos —
são bloqueios. `rm -rf /`, `git push --force`, escrita em `.env`, edição de
`*.production.*` param de funcionar. É o objetivo, mas você precisa saber disso antes.
Se preferir só o conhecimento sem as travas, instale com `--sem-hooks`.

**2. Parte do kit testa vulnerabilidades ativamente.** Use somente contra sistemas
que você é dono ou tem autorização escrita para testar. No Brasil, invadir sistema de
terceiro sem autorização é crime — Lei 12.737/2012 (art. 154-A do Código Penal).
O `CLAUDE.md` instrui a IA a pedir confirmação antes de qualquer teste ativo fora de
`localhost`.

---

## Como usar

### Opção A — trabalhar dentro desta pasta

```bash
claude
```
Skills, agents, comandos e hooks carregam sozinhos. Rode `/kit-security` para ver o
que está disponível.

### Opção B — instalar num projeto existente

```bash
./install.sh /caminho/do/seu/projeto              # com as proteções
./install.sh /caminho/do/seu/projeto --sem-hooks  # só o conhecimento
```

O script **não sobrescreve nada**. `CLAUDE.md` existente ganha um `@import`;
`settings.json` e `.mcp.json` são mesclados preservando o que já era seu. Rodar duas
vezes não duplica.

### Conferir

```bash
./check.sh
```

---

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-security [assunto]` | Mostra o que está instalado e o que se aplica ao seu caso |
| `/auditar-sistema [alvo]` | Auditoria priorizada por risco, com evidência e nível de confiança |
| `/blindar [alvo]` | Hardening — implementa as correções, não só aponta |
| `/compliance [framework]` | Avalia contra GDPR, ISO 27001, SOC 2, PCI DSS, HIPAA |
| `/security-audit` · `/security-hardening` · `/penetration-test` | Vindos do catálogo |
| `/secrets-scanner` · `/dependency-audit` · `/supply-chain-audit` | Varreduras |
| `/add-authentication-system` · `/setup-rate-limiting` | Implementação |
| `/supabase-security-audit` | Auditoria de RLS no Supabase |

Fora dos comandos, é só conversar — as skills ativam sozinhas.

---

## Proteções automáticas (hooks)

A parte mais valiosa do kit. Skills dependem de a IA lembrar; hooks rodam sempre.

| Hook | Dispara em | O que faz |
|---|---|---|
| `dangerous-command-blocker` | Bash | Bloqueia `rm -rf /`, `dd`, `mkfs`; protege `.git/`, `.claude/` |
| `shell-wrapper-guard` | Bash | Pega destrutivo em `sh -c`, `python3 -c`, `node -e` |
| `secret-scanner` | Bash | Bloqueia commit com chave hardcoded (30+ provedores) |
| `force-push-blocker` | Bash | Bloqueia `git push --force` e `-f` |
| `file-protection` | Edit/Write | Bloqueia `/etc/*`, `*.production.*`, `*prod*config*` |
| `env-file-protection` | Write | Bloqueia escrita em `.env*` |
| `security-scanner` | pós Edit/Write | Roda semgrep, bandit, gitleaks **se instalados** |
| `dependency-checker` | Edit em manifesto | Roda `npm audit`, `safety`, `cargo audit` |

Testados nesta máquina: bloqueio confirmado (exit 2) para `rm -rf /` e para
`sh -c "rm -rf /"`; comando normal passa (exit 0).

Para desativar um: edite `.claude/settings.json`.

**Ferramentas opcionais.** `security-scanner` só age se as ferramentas existirem —
sem elas ele passa em silêncio, o que dá falsa sensação de cobertura. Para ativar
de verdade:

```bash
brew install semgrep gitleaks trivy
pipx install bandit
```

---

## O que está instalado

**29 skills** — construir seguro (`senior-security`, `api-security-best-practices`,
`broken-authentication`, `secrets-management`, `file-uploads`, `nextjs-supabase-auth`,
`senior-secops`), modelar ameaça (`security-threat-model`, `threat-modeling-expert`),
auditar (`vulnerability-scanner`, `top-web-vulnerabilities`, `security-best-practices`,
`security-audit`, `security-ownership-map`, `sast-configuration`), testar
(`web-security-testing`, `api-security-testing`, `sql-injection-testing`,
`xss-html-injection`, `idor-testing`, `file-path-traversal`, `api-fuzzing-bug-bounty`,
`webapp-testing`, `pentest-checklist`), cadeia de suprimentos (`supply-chain-guard`) e
compliance (`security-compliance`, `data-privacy-compliance`, `gdpr-dsgvo-expert`,
`information-security-manager-iso27001`).

**15 agents** — `security-auditor`, `api-security-audit`, `security-engineer`,
`penetration-tester`, `read-only-auditor`, `se-security-reviewer`, `wg-code-sentinel`,
`dependency-manager`, `supply-chain-security`, `github-actions-expert`,
`mcp-security-auditor`, `compliance-specialist`, `compliance-auditor`, `legal-advisor`,
`incident-responder`.

`read-only-auditor` merece destaque: tem hooks que bloqueiam Write, Edit e Bash por
construção. É o único que garante que a auditoria não altera nada. Use em produção.

Lista completa com downloads e justificativa: [KIT-SECURITY-SISTEM-AITMPL.md](KIT-SECURITY-SISTEM-AITMPL.md).

---

## MCPs

### Ativo — `.mcp.json`

| Servidor | O que faz | Requisitos |
|---|---|---|
| `playwright` | Automação de browser: testar seu próprio app, screenshot | nenhum |

### Opcionais — `.mcp.optional.json`

Fora do `.mcp.json` de propósito: exigem credencial e apareceriam como erro a cada
sessão.

| Servidor | Requisitos |
|---|---|
| `github` | Personal access token — dá acesso a alertas e Dependabot |
| `postgresql` | Connection string — conferir RLS e permissões direto no banco |
| `sentry` | Conta Sentry (autenticação via OAuth no primeiro uso) |

Preencha os placeholders e mova o bloco para `.mcp.json`.

> **Cuidado com o token do GitHub.** Um PAT com escopo amplo dá à IA acesso de escrita
> aos seus repositórios. Use escopo mínimo (`repo:status`, `security_events` para
> leitura de alertas) e não versione o `.mcp.json` preenchido.

---

## Configuração de privacidade

O kit aplica o setting `privacy-focused` em `.claude/settings.json`: desliga
telemetria, relatório de erro e tráfego não essencial. **Também desliga o
auto-updater** (`DISABLE_AUTOUPDATER`) — se você quer continuar recebendo
atualizações automáticas do Claude Code, remova essa linha do `env`.

---

## Limitações — leia antes de confiar

1. **Não existe MCP de scanner de segurança no catálogo.** Sem Semgrep, Snyk, Trivy
   ou SonarQube como MCP. A skill `sast-configuration` ensina a configurar; a
   ferramenta você instala e roda por fora.

2. **Não existe componente de LGPD.** Só GDPR. As skills de GDPR cobrem os princípios
   gerais — a LGPD foi modelada sobre ele — mas não cobrem ANPD, bases legais do
   art. 7º nem prazos de notificação brasileiros. Valide com jurídico.

3. **Popularidade muito desigual.** `sast-configuration` (14 downloads na origem),
   `supply-chain-guard` (18), `read-only-auditor` (19), `security-ownership-map` (20)
   e `gdpr-dsgvo-expert` (20) são pouco usados, provavelmente pouco testados. Já
   `security-auditor` (2.788), `senior-security` (2.233) e `api-security-audit` (818)
   têm base larga.

4. **Hooks executam código na sua máquina a cada ação.** Os três scripts estão em
   `.claude/hooks/` — leia antes de instalar em máquina de trabalho.

5. **Skill não substitui pentest.** Melhora a chance de a IA lembrar de verificar
   algo. Em sistema que trata dado sensível ou dinheiro, contrate auditoria de verdade.

6. **Pentest de infraestrutura não está aqui.** Active Directory, Metasploit, Shodan,
   privesc Windows/Linux existem no catálogo mas ficaram de fora por não terem relação
   com montar aplicação. Ver seção 9 do `.md` de análise.

---

## Arquivos

```
KIT-SECURITY-SISTEM-AITMPL/
├── CLAUDE.md                      contexto automático: roteamento + regra de autorização
├── README.md                      este arquivo
├── KIT-SECURITY-SISTEM-AITMPL.md  análise do catálogo que originou a seleção
├── install.sh                     instala em outro projeto (--sem-hooks disponível)
├── check.sh                       verifica instalação e ferramentas
├── .mcp.json                      MCP pronto para uso
├── .mcp.optional.json             MCPs que precisam de credencial
└── .claude/
    ├── settings.json              8 hooks + config de privacidade
    ├── hooks/                     3 scripts (python/bash)
    ├── skills/                    29 skills
    ├── agents/                    15 agents
    └── commands/                  13 commands
```

## Atualizar um componente

```bash
npx claude-code-templates@latest --skill <categoria>/<nome> --yes
npx claude-code-templates@latest --agent <categoria>/<nome> --yes
npx claude-code-templates@latest --hook  <categoria>/<nome> --yes
```

Rode a partir desta pasta. A API do GitHub limita a 60 requisições/hora sem
autenticação — se falhar com HTTP 403, espere ou use `gh auth login`.
