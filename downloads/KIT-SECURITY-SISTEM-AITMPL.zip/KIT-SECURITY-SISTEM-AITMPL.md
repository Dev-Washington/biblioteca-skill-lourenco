# Kit de Segurança para App, Sistema, CRM e Site — aitmpl.com

> Análise do catálogo real do [aitmpl.com](https://aitmpl.com/) (arquivo `components.json`, que alimenta o site).
> Repositório de origem: [davila7/claude-code-templates](https://github.com/davila7/claude-code-templates)
> Data da análise: 26/08/2026

---

## 1. O que existe no catálogo

O catálogo tem **categorias dedicadas a segurança**, o que facilitou o recorte:

| Tipo | Total no catálogo | Categoria `security` | Selecionados aqui |
|---|---|---|---|
| Skills | 872 | 47 | 29 |
| Agents | 422 | 25 | 15 |
| Commands | 286 | 6 | 9 |
| Hooks | 62 | 8 | 8 |
| MCPs | 101 | 0 | 4 |
| Settings | 71 | 0 | 1 |

Varrendo o catálogo inteiro por termos de segurança (`owasp`, `auth`, `xss`, `injection`,
`encrypt`, `secret`, `rbac`, `gdpr`, `lgpd`, `pci`, `threat`, `hardening`, `supply chain`,
`compliance` e outros 50), apareceram 497 candidatos. Depois de descartar menções de
passagem — skills que só citam "security" numa linha da descrição — sobraram **66
componentes** com segurança como tema central. Todos os 66 foram validados contra o
catálogo antes de entrar aqui.

**Recorte adotado:** segurança para **construir e defender** um sistema (app, CRM, site,
API). O catálogo também tem pentest de infraestrutura — Active Directory, Metasploit,
Shodan, privilege escalation em Windows/Linux, SMTP, SSH. Isso ficou de fora por não ter
relação com montar uma aplicação. A seção 9 lista o que existe e como instalar, caso você
precise.

---

## 2. Kit essencial — instale estes primeiro

Os seis de maior impacto e maior base de uso. Servem para qualquer stack.

| Componente | Tipo | Por quê | Downloads |
|---|---|---|---|
| `security/security-auditor` | agent | Auditoria sistemática de vulnerabilidades, compliance e risco. O componente de segurança mais usado do catálogo | 2.788 |
| `development/senior-security` | skill | Base ampla: application security, arquitetura segura, compliance. É a skill "guarda-chuva" | 2.233 |
| `security/api-security-audit` | agent | Auditoria de API REST: autenticação, autorização, injection | 818 |
| `devops-infrastructure/security-engineer` | agent | Arquitetura de segurança e controles automatizados no CI/CD | 817 |
| `security/vulnerability-scanner` | skill | OWASP 2025, supply chain, mapa de superfície de ataque, priorização de risco | 551 |
| `security/api-security-best-practices` | skill | Design seguro de API: authn, authz, validação de input, rate limiting | 403 |

```bash
npx claude-code-templates@latest --agent security/security-auditor --yes
npx claude-code-templates@latest --skill development/senior-security --yes
npx claude-code-templates@latest --agent security/api-security-audit --yes
npx claude-code-templates@latest --agent devops-infrastructure/security-engineer --yes
npx claude-code-templates@latest --skill security/vulnerability-scanner --yes
npx claude-code-templates@latest --skill security/api-security-best-practices --yes
```

---

## 3. Hooks — a camada que age sozinha

**Esta é a parte mais subestimada do kit.** Skills só entram em ação quando o assunto
aparece na conversa. Hooks rodam automaticamente a cada ação, sem depender de a IA
lembrar. Para um sistema em produção, valem mais que qualquer skill.

| Componente | O que faz | Downloads |
|---|---|---|
| `automation/dependency-checker` | Monitora pacotes desatualizados e vulnerabilidades nas dependências | 716 |
| `security/security-scanner` | Escaneia o código em busca de vulnerabilidades e segredos após cada modificação | 586 |
| `security/dangerous-command-blocker` | Bloqueia `rm -rf /`, `dd`, `mkfs` e protege caminhos críticos (`.git/`, `.claude/`) | 366 |
| `security/file-protection` | Impede edição acidental de arquivos de sistema, config e código de produção | 355 |
| `security/secret-scanner` | Detecta chaves hardcoded antes do commit — 30+ provedores (`sk-ant-`, `AKIA`, `sk_live_`, `AIza`) | 339 |
| `security/env-file-protection` | Bloqueia qualquer escrita em `.env*` | 69 |
| `security/shell-wrapper-guard` | Pega comandos destrutivos escondidos em `sh -c`, `python3 -c`, `node -e` | 45 |
| `security/force-push-blocker` | Bloqueia `git push --force` e variantes | 41 |

```bash
npx claude-code-templates@latest --hook automation/dependency-checker --yes
npx claude-code-templates@latest --hook security/security-scanner --yes
npx claude-code-templates@latest --hook security/secret-scanner --yes
npx claude-code-templates@latest --hook security/dangerous-command-blocker --yes
npx claude-code-templates@latest --hook security/file-protection --yes
npx claude-code-templates@latest --hook security/env-file-protection --yes
npx claude-code-templates@latest --hook security/shell-wrapper-guard --yes
npx claude-code-templates@latest --hook security/force-push-blocker --yes
```

---

## 4. Construir seguro — autenticação, API, dados

O que você usa **enquanto escreve** o sistema.

### Autenticação e sessão
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `security/broken-authentication` | skill | O que dá errado em autenticação e sessão: credential stuffing, política de senha, fixação de sessão | 77 |
| `development/nextjs-supabase-auth` | skill | Supabase Auth com Next.js App Router, feito direito | 102 |
| `security/add-authentication-system` | command | Implementa um sistema de login com boas práticas desde o início | 97 |

### API e superfície de entrada
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `security/api-security-best-practices` | skill | Já está no kit essencial | 403 |
| `setup/setup-rate-limiting` | command | Rate limiting com algoritmos e políticas por usuário | 56 |
| `security/file-uploads` | skill | Upload seguro: S3, R2, presigned URLs, multipart, arquivos grandes | 39 |
| `security/file-path-traversal` | skill | Directory traversal e LFI — o risco direto de quem serve arquivos | 22 |

### Dados e segredos
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `security/secrets-management` | skill | Vault, AWS Secrets Manager, segredos em CI/CD | 44 |
| `database/supabase-security-audit` | command | Auditoria de RLS (Row Level Security) e vulnerabilidades no Supabase | 266 |
| `security/sql-injection-testing` | skill | Como SQLi funciona — para escrever query que resiste | 157 |

### Arquitetura
| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `security/security-threat-model` | skill | Modelagem de ameaça ancorada no repositório: trust boundaries, ativos, caminhos de abuso | 48 |
| `security/threat-modeling-expert` | skill | STRIDE, PASTA, attack trees, extração de requisito de segurança | 23 |
| `development/senior-secops` | skill | SecOps: gestão de vulnerabilidade e desenvolvimento seguro | 64 |
| `mcp-dev-team/mcp-security-auditor` | agent | OAuth, RBAC e compliance — útil se seu sistema expõe MCP | 245 |

---

## 5. Testar o próprio sistema

> **Autorização.** As skills abaixo testam vulnerabilidades ativamente. Use **somente**
> contra sistemas que você é dono ou tem autorização escrita para testar. Testar sistema
> de terceiro sem autorização é crime — no Brasil, Lei 12.737/2012 (art. 154-A do Código
> Penal). Isso não é formalidade: a diferença entre auditoria e invasão é a autorização.

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `security/security-audit` | command | Avaliação completa de segurança e análise de vulnerabilidade | 382 |
| `security/top-web-vulnerabilities` | skill | Categorias de falha web e como reconhecê-las | 271 |
| `security/secrets-scanner` | command | Varre o código por segredos e credenciais expostas | 156 |
| `security/security-audit` | skill | Workflow de auditoria: web, API, pentest, hardening | 143 |
| `security/security-hardening` | command | Aplica controles de segurança na configuração | 141 |
| `security/penetration-test` | command | Pentest e avaliação de vulnerabilidade na aplicação | 125 |
| `security/pentest-checklist` | skill | Planeja escopo e checklist de um teste — a parte que evita sair atirando | 91 |
| `security/xss-html-injection` | skill | XSS e HTML injection | 71 |
| `security/webapp-testing` | skill | Playwright para testar app local: screenshot, verificação de comportamento | 70 |
| `security/web-security-testing` | skill | Workflow OWASP Top 10 | 41 |
| `security/idor-testing` | skill | IDOR e broken access control — a falha mais comum em CRM | 28 |
| `security/api-fuzzing-bug-bounty` | skill | Fuzzing de REST e GraphQL | 24 |
| `security/api-security-testing` | skill | Authn, authz, rate limiting e validação em REST/GraphQL | 23 |
| `security/penetration-tester` | agent | Executor de pentest autorizado, com exploração e validação ativa | 549 |
| `security/read-only-auditor` | agent | Auditoria com hooks que **bloqueiam** Write, Edit e Bash — garantido sem alterar nada | 19 |

`read-only-auditor` merece destaque: é o único do conjunto que garante por construção que
a auditoria não modifica o código. Use quando for auditar produção.

---

## 6. Revisão de código e cadeia de suprimentos

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `expert-advisors/dependency-manager` | agent | Análise de dependência e varredura de vulnerabilidade | 313 |
| `security/dependency-audit` | command | Vulnerabilidades, licenças e recomendações de atualização | 173 |
| `security/security-best-practices` | skill | Review de boas práticas por linguagem e framework | 190 |
| `security/github-actions-expert` | agent | CI/CD seguro: action pinning, OIDC, least privilege, supply chain | 83 |
| `security/se-security-reviewer` | agent | Review com OWASP Top 10, Zero Trust e segurança de LLM | 80 |
| `security/supply-chain-security` | agent | Segurança da cadeia de suprimentos | 36 |
| `security/wg-code-sentinel` | agent | Review de código focado em falha de segurança | 32 |
| `security/supply-chain-guard` | skill | Detecta pacotes comprometidos em npm, PyPI, crates.io, GitHub Actions | 18 |
| `analysis/supply-chain-audit` | command | Auditoria da cadeia de suprimentos | 21 |
| `security/sast-configuration` | skill | Configura SAST e regras customizadas multi-linguagem | 14 |
| `security/security-ownership-map` | skill | Quem é dono de qual código sensível, bus factor, exporta CSV/JSON | 20 |

---

## 7. Compliance, privacidade e jurídico

Onde CRM e sistema com dado pessoal costumam quebrar — e onde a multa mora.

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `business-marketing/legal-advisor` | agent | Política de privacidade, termos de uso, avisos legais, GDPR/CCPA | 473 |
| `security/compliance-specialist` | agent | Avaliação de compliance, requisitos regulatórios, preparação de auditoria | 259 |
| `development/security-compliance` | skill | Defesa em profundidade + compliance | 223 |
| `security/compliance-auditor` | agent | GDPR, HIPAA, PCI DSS, SOC 2, ISO | 91 |
| `enterprise-communication/information-security-manager-iso27001` | skill | ISO 27001 e 27002 na prática | 61 |
| `enterprise-communication/data-privacy-compliance` | skill | GDPR, CCPA, HIPAA e leis internacionais de proteção de dados | 60 |
| `enterprise-communication/gdpr-dsgvo-expert` | skill | GDPR/DSGVO na visão de auditor | 20 |

> **Sobre LGPD:** não há componente específico de LGPD no catálogo. As skills de GDPR
> cobrem a maior parte dos princípios — a LGPD foi modelada sobre o GDPR — mas **não**
> cobrem o que é próprio do Brasil: papel da ANPD, bases legais do art. 7º, prazos de
> notificação de incidente. Trate como base, valide com jurídico brasileiro.

---

## 8. Resposta a incidente e monitoramento

| Componente | Tipo | O que entrega | Downloads |
|---|---|---|---|
| `security/incident-responder` | agent | Incidente em produção: coordena debug, aplica correção, escreve post-mortem | 185 |
| `devtools/sentry` | MCP | Erros e problemas de produção acessíveis à IA | 97 |
| `integration/github-integration` | MCP | Alertas de segurança e Dependabot do repositório | 1.143 |
| `browser_automation/playwright-mcp-server` | MCP | Automação de browser — testar seu próprio app de verdade | 1.752 |
| `database/postgresql-integration` | MCP | Conferir RLS, permissões e schema direto no banco | 1.299 |
| `environment/privacy-focused` | setting | Desliga telemetria e tráfego não essencial. Para trabalhar com código sensível | 221 |

---

## 9. O que existe mas ficou de fora

Pentest de infraestrutura e rede. Não tem relação com montar app, CRM ou site — mas está
no catálogo se você precisar. **Mesma regra de autorização da seção 5 se aplica.**

| Componente | Downloads |
|---|---|
| `security/wordpress-penetration-testing` | 72 |
| `security/ethical-hacking-methodology` | 76 |
| `security/scanning-tools` | 62 |
| `security/pentest-commands` (nmap, metasploit, hydra, nikto) | 61 |
| `security/red-team-tools` | 58 |
| `security/ssh-penetration-testing` | 39 |
| `security/red-team-tactics` (MITRE ATT&CK) | 38 |
| `security/aws-penetration-testing` | 37 |
| `security/cloud-penetration-testing` | 37 |
| `security/active-directory-attacks` | 32 |
| `security/linux-privilege-escalation` | 31 |
| `security/burp-suite-testing` | 30 |
| `security/metasploit-framework` | 26 |
| `security/sqlmap-database-pentesting` | 24 |
| `security/smtp-penetration-testing` | 23 |
| `security/windows-privilege-escalation` | 23 |
| `security/privilege-escalation-methods` | 17 |
| `security/wireshark-analysis` | 16 |
| `security/shodan-reconnaissance` | 14 |

Se você hospeda WordPress ou roda infra própria em AWS, os dois primeiros de cada bloco
valem a instalação:

```bash
npx claude-code-templates@latest --skill security/wordpress-penetration-testing --yes
npx claude-code-templates@latest --skill security/aws-penetration-testing --yes
```

---

## 10. Sintaxe de instalação

```bash
npx claude-code-templates@latest --skill   <categoria>/<nome> --yes
npx claude-code-templates@latest --agent   <categoria>/<nome> --yes
npx claude-code-templates@latest --command <categoria>/<nome> --yes
npx claude-code-templates@latest --hook    <categoria>/<nome> --yes
npx claude-code-templates@latest --mcp     <categoria>/<nome> --yes
npx claude-code-templates@latest --setting <categoria>/<nome> --yes
```

A CLI escreve em `.claude/` do diretório atual. Rode a partir da pasta do kit.

---

## 11. Ressalvas honestas

1. **Não existe MCP de scanner de segurança no catálogo.** Nada de Semgrep, Snyk,
   Trivy ou SonarQube. A skill `sast-configuration` ensina a configurar SAST, mas a
   ferramenta você instala e roda por fora. Isso é uma lacuna real do catálogo.

2. **Não existe componente de LGPD.** Só GDPR. Ver a nota na seção 7.

3. **Popularidade muito desigual.** `sast-configuration` (14 downloads),
   `supply-chain-guard` (18), `read-only-auditor` (19), `security-ownership-map` (20) e
   `gdpr-dsgvo-expert` (20) são pouco usados — provavelmente pouco testados na prática.
   Já `security-auditor` (2.788), `senior-security` (2.233) e `api-security-audit` (818)
   têm base larga. Trate os primeiros como ponto de partida, não como verdade.

4. **Hooks alteram o comportamento do Claude Code de verdade.** `dangerous-command-blocker`
   e `file-protection` vão bloquear comandos seus. É o objetivo — mas leia o que cada um
   bloqueia antes de instalar em uma máquina onde você trabalha rápido. Todos são
   configuráveis em `.claude/settings.json`.

5. **Componentes vêm de terceiros.** Hooks executam código na sua máquina a cada ação.
   Revise o que instalar, especialmente `--hook`.

6. **Nomes duplicados entre categorias.** `security-audit` existe como skill **e** como
   command; `security-engineer` aparece em duas categorias; `compliance-specialist` e
   `compliance-auditor` são componentes diferentes. Instale sempre com o caminho completo
   `categoria/nome`.

7. **Skill não é garantia.** Uma skill de segurança melhora a chance de a IA lembrar de
   verificar algo — não substitui pentest profissional, revisão humana nem auditoria
   formal em sistema que trata dado sensível ou dinheiro.

---

## 12. Resumo — o que instalar agora

Conjunto completo para um sistema/CRM/site com login, dados de usuário e pagamento:

```bash
# Essencial
npx claude-code-templates@latest --agent security/security-auditor --yes
npx claude-code-templates@latest --skill development/senior-security --yes
npx claude-code-templates@latest --agent security/api-security-audit --yes
npx claude-code-templates@latest --agent devops-infrastructure/security-engineer --yes
npx claude-code-templates@latest --skill security/vulnerability-scanner --yes
npx claude-code-templates@latest --skill security/api-security-best-practices --yes

# Hooks — proteção automática
npx claude-code-templates@latest --hook automation/dependency-checker --yes
npx claude-code-templates@latest --hook security/security-scanner --yes
npx claude-code-templates@latest --hook security/secret-scanner --yes
npx claude-code-templates@latest --hook security/dangerous-command-blocker --yes
npx claude-code-templates@latest --hook security/file-protection --yes
npx claude-code-templates@latest --hook security/env-file-protection --yes

# Construir seguro
npx claude-code-templates@latest --skill security/broken-authentication --yes
npx claude-code-templates@latest --skill security/secrets-management --yes
npx claude-code-templates@latest --skill security/security-threat-model --yes
npx claude-code-templates@latest --skill security/file-uploads --yes
npx claude-code-templates@latest --command security/add-authentication-system --yes
npx claude-code-templates@latest --command setup/setup-rate-limiting --yes

# Testar o próprio sistema
npx claude-code-templates@latest --command security/security-audit --yes
npx claude-code-templates@latest --command security/secrets-scanner --yes
npx claude-code-templates@latest --skill security/web-security-testing --yes
npx claude-code-templates@latest --skill security/idor-testing --yes
npx claude-code-templates@latest --agent security/read-only-auditor --yes

# Dependências e cadeia de suprimentos
npx claude-code-templates@latest --agent expert-advisors/dependency-manager --yes
npx claude-code-templates@latest --command security/dependency-audit --yes
npx claude-code-templates@latest --agent security/github-actions-expert --yes

# Compliance
npx claude-code-templates@latest --agent business-marketing/legal-advisor --yes
npx claude-code-templates@latest --agent security/compliance-specialist --yes
npx claude-code-templates@latest --skill enterprise-communication/data-privacy-compliance --yes

# Incidente
npx claude-code-templates@latest --agent security/incident-responder --yes
```
