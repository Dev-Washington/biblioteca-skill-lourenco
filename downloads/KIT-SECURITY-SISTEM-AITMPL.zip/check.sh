#!/usr/bin/env bash
# Verifica se o kit está completo e quais ferramentas externas faltam.
cd "$(dirname "${BASH_SOURCE[0]}")"
ok=0; fail=0
chk(){ if [ -e "$2" ]; then ok=$((ok+1)); else echo "  FALTA $1"; fail=$((fail+1)); fi; }

echo "== Skills =="
for s in senior-security vulnerability-scanner api-security-best-practices top-web-vulnerabilities \
  security-compliance security-best-practices security-audit security-threat-model threat-modeling-expert \
  secrets-management supply-chain-guard sast-configuration pentest-checklist broken-authentication \
  web-security-testing api-security-testing sql-injection-testing xss-html-injection idor-testing \
  file-path-traversal api-fuzzing-bug-bounty webapp-testing file-uploads nextjs-supabase-auth \
  senior-secops data-privacy-compliance gdpr-dsgvo-expert information-security-manager-iso27001 \
  security-ownership-map; do chk "skill $s" ".claude/skills/$s/SKILL.md"; done
echo "  $(ls .claude/skills 2>/dev/null | wc -l | tr -d ' ') skills presentes"

echo "== Agents =="
for a in security-auditor api-security-audit security-engineer penetration-tester dependency-manager \
  compliance-specialist mcp-security-auditor incident-responder compliance-auditor github-actions-expert \
  se-security-reviewer supply-chain-security wg-code-sentinel legal-advisor read-only-auditor; do
  chk "agent $a" ".claude/agents/$a.md"; done
echo "  $(ls .claude/agents 2>/dev/null | wc -l | tr -d ' ') agents presentes"

echo "== Commands =="
for c in security-audit dependency-audit secrets-scanner security-hardening penetration-test \
  add-authentication-system supabase-security-audit setup-rate-limiting supply-chain-audit \
  kit-security auditar-sistema blindar compliance; do chk "/$c" ".claude/commands/$c.md"; done
echo "  $(ls .claude/commands 2>/dev/null | wc -l | tr -d ' ') commands presentes"

echo "== Hooks =="
for h in dangerous-command-blocker.py secret-scanner.py shell-wrapper-guard.sh; do
  chk "script $h" ".claude/hooks/$h"; done
if [ -f .claude/settings.json ]; then
  n=$(node -e 'const s=JSON.parse(require("fs").readFileSync(".claude/settings.json","utf8"));let n=0;for(const a of Object.values(s.hooks||{}))for(const e of a)n+=(e.hooks||[]).length;console.log(n)' 2>/dev/null || echo 0)
  echo "  $n hook(s) registrados em settings.json"
  node -e 'JSON.parse(require("fs").readFileSync(".claude/settings.json","utf8"))' 2>/dev/null \
    && echo "  settings.json: JSON válido" || { echo "  settings.json: JSON INVÁLIDO"; fail=$((fail+1)); }
else echo "  FALTA .claude/settings.json"; fail=$((fail+1)); fi

echo "== Config =="
chk "CLAUDE.md" "CLAUDE.md"; chk ".mcp.json" ".mcp.json"; chk ".mcp.optional.json" ".mcp.optional.json"

echo
echo "== Ferramentas externas =="
dep(){ if command -v "$1" >/dev/null 2>&1; then echo "  ok       $1 — $2"; else echo "  ausente  $1 — $2 ($3)"; fi; }
dep node     "necessário para tudo"                       "https://nodejs.org"
dep python3  "hooks dangerous-command-blocker e secret-scanner" "vem com o macOS"
dep git      "hooks de commit e force-push"               "xcode-select --install"
echo "  -- usadas pelo hook security-scanner (opcionais, ele passa em silêncio sem elas) --"
dep semgrep  "SAST multi-linguagem"                       "brew install semgrep"
dep gitleaks "varredura de segredos"                      "brew install gitleaks"
dep bandit   "SAST para Python"                           "pipx install bandit"
dep trivy    "scanner de dependência e container"         "brew install trivy"

echo
echo "resumo: $ok presentes, $fail faltando"
[ "$fail" -eq 0 ]
