---
description: Auditoria de segurança completa do sistema atual, priorizada por risco
---

Alvo: $ARGUMENTS  (se vazio, audite o repositório atual)

**Antes de começar:** esta é uma auditoria de código e configuração — leitura e
análise. Ela não ataca nada. Se em algum ponto for necessário teste ativo contra um
alvo em execução, **pare e peça autorização explícita** ao usuário (ver a regra de
autorização em `CLAUDE.md`).

Se o alvo for produção, prefira o agent `read-only-auditor` — ele bloqueia
Write/Edit/Bash por construção.

Conduza nesta ordem, dizendo qual skill/agent está usando em cada etapa:

1. **Mapear a superfície.** skill `vulnerability-scanner` — o que está exposto:
   rotas, endpoints, uploads, integrações, dados sensíveis. Sem mapa, o resto é chute.

2. **Ameaça e prioridade.** skill `security-threat-model` — trust boundaries, ativos,
   caminhos de abuso. Isso define o que auditar primeiro.

3. **Auditoria por camada** — use o que se aplica ao stack:
   - Autenticação e sessão → skill `broken-authentication`
   - API → agent `api-security-audit` + skill `api-security-best-practices`
   - Controle de acesso → skill `idor-testing` (a falha mais comum em CRM)
   - Input do usuário → skills `sql-injection-testing`, `xss-html-injection`
   - Upload e arquivos → skills `file-uploads`, `file-path-traversal`
   - Segredos → command `/secrets-scanner` + skill `secrets-management`
   - Dependências → agent `dependency-manager` + skill `supply-chain-guard`
   - Banco (se Supabase) → command `/supabase-security-audit` (RLS)

4. **Relatório.** Para cada achado, obrigatoriamente:
   - arquivo e linha
   - como reproduzir
   - impacto real e explorabilidade
   - correção concreta
   - **nível de confiança** — confirmado ou suspeita

   Ordene por risco (impacto × explorabilidade), não por quantidade. Um achado
   crítico confirmado vale mais que vinte avisos genéricos.

5. **Feche com o que você NÃO cobriu** e por quê. Uma auditoria que não declara seus
   limites é pior que nenhuma. Se o sistema trata dado pessoal ou dinheiro, diga que
   isso não substitui pentest profissional.
