---
description: Aplica hardening de segurança no sistema — corrige, não só aponta
---

Alvo: $ARGUMENTS  (se vazio, o repositório atual)

Diferente de `/auditar-sistema`, aqui você **implementa** as correções.

1. **Antes de mudar qualquer coisa**, confirme com o usuário: há trabalho não
   commitado? Existe branch? Hardening mexe em config sensível — não faça em cima
   de trabalho não salvo.

2. **Camadas**, na ordem, usando as skills do kit:
   - Segredos fora do código → skill `secrets-management`. Nada de chave hardcoded,
     `.env` no `.gitignore`, rotação do que já vazou.
   - Autenticação → skill `broken-authentication`. Política de senha, expiração de
     sessão, proteção contra credential stuffing.
   - API → skill `api-security-best-practices` + command `/setup-rate-limiting`.
     Validação de input, authz por rota, rate limit.
   - Headers e config → command `/security-hardening`. CSP, HSTS, CORS restritivo,
     cookies `HttpOnly`/`Secure`/`SameSite`.
   - Dependências → command `/dependency-audit`. Atualize o que tem CVE.
   - CI/CD → agent `github-actions-expert`. Action pinning, OIDC, least privilege.
   - SAST no pipeline → skill `sast-configuration`.

3. **Cada mudança precisa ser verificada.** Rode os testes existentes. Se uma
   mudança de CORS ou CSP quebrar o app, você precisa saber agora — não em produção.
   Se não houver como verificar, diga isso explicitamente.

4. **Relate ao final**: o que mudou, o que quebrou, o que ficou pendente e por quê.
   Não afirme que está seguro — diga o que especificamente foi endurecido.
