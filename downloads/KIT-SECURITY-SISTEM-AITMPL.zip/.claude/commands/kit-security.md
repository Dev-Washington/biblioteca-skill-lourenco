---
description: Mostra o que o Kit de Segurança tem instalado e o que se aplica ao seu caso
---

Leia `CLAUDE.md` na raiz e apresente ao usuário, em português:

1. Verifique o que existe **de fato** em disco antes de responder:
   - `ls .claude/skills` · `ls .claude/agents` · `ls .claude/commands`
   - `cat .claude/settings.json` (quais hooks estão ativos)
   - `cat .mcp.json`
   Não liste nada que não esteja lá.

2. Resuma agrupado por finalidade: construir seguro, auditar/testar, dependências,
   compliance, incidente. E destaque **os hooks ativos**, porque eles agem sozinhos
   e podem bloquear comandos do usuário.

3. Se o usuário passou um assunto como argumento ($ARGUMENTS), diga exatamente
   quais skills/agents/commands se aplicam e por quê. Se não passou, pergunte em
   que ponto ele está (construindo, auditando, preparando compliance, respondendo
   incidente) e recomende o caminho.

Seja direto. Não repita a tabela inteira do CLAUDE.md.
