---
description: Avalia o sistema contra GDPR, LGPD, ISO 27001, SOC 2, PCI DSS ou HIPAA
---

Framework alvo: $ARGUMENTS  (se vazio, pergunte qual — e onde os usuários estão)

1. **Descubra o que o sistema realmente coleta** antes de falar de norma. Varra o
   código e o schema: que dado pessoal entra, onde é armazenado, por quanto tempo,
   quem acessa, para onde é enviado (terceiros, analytics, logs). Sem esse
   inventário, avaliação de compliance é teatro.

2. **Aplique o framework** — agent `compliance-specialist` ou `compliance-auditor`:
   - GDPR/CCPA → skills `data-privacy-compliance`, `gdpr-dsgvo-expert`
   - ISO 27001/27002 → skill `information-security-manager-iso27001`
   - Defesa em profundidade → skill `security-compliance`

3. **LGPD — leia antes de responder.** Não existe componente de LGPD neste kit.
   As skills de GDPR cobrem os princípios gerais, porque a LGPD foi modelada sobre
   ele. **Não** cobrem o que é específico do Brasil: papel da ANPD, bases legais do
   art. 7º, prazos e forma de notificação de incidente, encarregado (DPO).
   Diga isso ao usuário de forma explícita e recomende validação com jurídico
   brasileiro. Não apresente análise de GDPR como se fosse de LGPD.

4. **Documentos** — agent `legal-advisor`: política de privacidade, termos de uso,
   avisos. Deixe claro que são minutas para revisão jurídica, não peças finais.

5. **Entregue uma matriz**: requisito → estado atual (atende / atende parcial / não
   atende / não aplicável) → evidência no código → o que fazer. Sem evidência, marque
   como "não verificado" em vez de assumir que atende.

Você não é advogado e esta análise não é parecer jurídico. Diga isso.
