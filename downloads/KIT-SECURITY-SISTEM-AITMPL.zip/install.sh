#!/usr/bin/env bash
# Instala o Kit de Segurança em um projeto existente.
# Uso:  ./install.sh /caminho/do/seu/projeto [--sem-hooks]
set -euo pipefail

KIT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEST="${1:-}"
SKIP_HOOKS=0
[ "${2:-}" = "--sem-hooks" ] && SKIP_HOOKS=1

if [ -z "$DEST" ]; then
  echo "uso: $0 /caminho/do/projeto [--sem-hooks]" >&2
  echo "     --sem-hooks  instala skills/agents/commands, mas NÃO as proteções automáticas" >&2
  exit 1
fi
[ -d "$DEST" ] || { echo "erro: '$DEST' não é um diretório" >&2; exit 1; }
DEST="$(cd "$DEST" && pwd)"
[ "$DEST" != "$KIT" ] || { echo "erro: destino é o próprio kit" >&2; exit 1; }

echo "Kit:     $KIT"
echo "Destino: $DEST"
echo

mkdir -p "$DEST/.claude/skills" "$DEST/.claude/agents" "$DEST/.claude/commands"

copy_dir() {
  local src="$KIT/.claude/$1" name
  [ -d "$src" ] || return 0
  for path in "$src"/*; do
    [ -e "$path" ] || continue
    name="$(basename "$path")"
    if [ -e "$DEST/.claude/$1/$name" ]; then
      echo "  pulado (já existe): .claude/$1/$name"
    else
      cp -R "$path" "$DEST/.claude/$1/$name"; echo "  + .claude/$1/$name"
    fi
  done
}

echo "skills:";   copy_dir skills
echo "agents:";   copy_dir agents
echo "commands:"; copy_dir commands

# hooks + settings.json
echo
if [ "$SKIP_HOOKS" -eq 1 ]; then
  echo "hooks: PULADOS (--sem-hooks)"
else
  mkdir -p "$DEST/.claude/hooks"
  for f in "$KIT"/.claude/hooks/*; do
    [ -e "$f" ] || continue
    n="$(basename "$f")"
    if [ -e "$DEST/.claude/hooks/$n" ]; then echo "  pulado (já existe): .claude/hooks/$n"
    else cp "$f" "$DEST/.claude/hooks/$n"; chmod +x "$DEST/.claude/hooks/$n"; echo "  + .claude/hooks/$n"; fi
  done
  node -e '
    const fs=require("fs"), [dstF,srcF]=process.argv.slice(1);
    const src=JSON.parse(fs.readFileSync(srcF,"utf8"));
    const dst=fs.existsSync(dstF)?JSON.parse(fs.readFileSync(dstF,"utf8")):{};
    dst.hooks=dst.hooks||{};
    let n=0;
    for(const [evt,arr] of Object.entries(src.hooks||{})){
      dst.hooks[evt]=dst.hooks[evt]||[];
      for(const e of arr){
        if(dst.hooks[evt].some(x=>JSON.stringify(x)===JSON.stringify(e))) continue;
        dst.hooks[evt].push(e); n++;
      }
    }
    dst.env=Object.assign({},src.env||{},dst.env||{});
    fs.writeFileSync(dstF,JSON.stringify(dst,null,2)+"\n");
    console.log("  settings.json: "+n+" hook(s) adicionado(s), env mesclado");
  ' "$DEST/.claude/settings.json" "$KIT/.claude/settings.json"
fi

# CLAUDE.md
echo
if [ -f "$DEST/CLAUDE.md" ]; then
  cp "$KIT/CLAUDE.md" "$DEST/.claude/KIT-SECURITY.md"
  if grep -q "KIT-SECURITY.md" "$DEST/CLAUDE.md"; then
    echo "CLAUDE.md: referência ao kit já presente"
  else
    printf '\n@.claude/KIT-SECURITY.md\n' >> "$DEST/CLAUDE.md"
    echo "CLAUDE.md: já existia — kit salvo em .claude/KIT-SECURITY.md e referenciado via @import"
  fi
else
  cp "$KIT/CLAUDE.md" "$DEST/CLAUDE.md"; echo "CLAUDE.md: criado"
fi

# .mcp.json
if [ -f "$DEST/.mcp.json" ]; then
  node -e '
    const fs=require("fs"), [dstF,srcF]=process.argv.slice(1);
    const d=JSON.parse(fs.readFileSync(dstF,"utf8")), s=JSON.parse(fs.readFileSync(srcF,"utf8"));
    d.mcpServers=d.mcpServers||{}; let n=0;
    for(const [k,v] of Object.entries(s.mcpServers||{})){
      if(k in d.mcpServers){ console.log("  pulado (já existe): mcp "+k); }
      else { d.mcpServers[k]=v; n++; console.log("  + mcp "+k); }
    }
    if(n) fs.writeFileSync(dstF,JSON.stringify(d,null,2)+"\n");
  ' "$DEST/.mcp.json" "$KIT/.mcp.json"
  echo ".mcp.json: mesclado"
else
  cp "$KIT/.mcp.json" "$DEST/.mcp.json"; echo ".mcp.json: criado"
fi
cp "$KIT/.mcp.optional.json" "$DEST/.mcp.optional.json" 2>/dev/null || true

echo
if [ "$SKIP_HOOKS" -eq 0 ]; then
  echo "ATENÇÃO: 8 hooks de proteção foram ativados. Eles BLOQUEIAM comandos"
  echo "         (rm -rf, git push --force, escrita em .env, edição de *.production.*)."
  echo "         Veja a tabela em CLAUDE.md. Para desativar: edite .claude/settings.json"
  echo
fi
echo "Pronto. Abra '$DEST' no Claude Code e rode /kit-security."
