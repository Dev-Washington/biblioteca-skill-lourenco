# Kit de Segurança — App, Sistema, CRM e Site

Este projeto tem um kit de segurança instalado em `.claude/`: **29 skills, 15 agents,
9 commands, 8 hooks e 4 MCPs**, voltados a construir, auditar e manter seguro um
app, sistema, CRM ou site.

Fonte: [aitmpl.com](https://aitmpl.com/) (`claude-code-templates`).

---

## Regra de autorização — leia antes de usar

Parte deste kit **testa vulnerabilidades ativamente** (`penetration-tester`,
`sql-injection-testing`, `xss-html-injection`, `idor-testing`,
`api-fuzzing-bug-bounty`, `/penetration-test`).

Use essas ferramentas **somente** contra sistemas que o usuário é dono ou tem
autorização escrita para testar. Antes de executar qualquer teste ativo contra um
alvo que não seja `localhost` ou ambiente próprio do usuário, **pergunte e confirme
a autorização**. Não presuma.

No Brasil, invadir sistema de terceiro sem autorização é crime — Lei 12.737/2012
(art. 154-A do Código Penal).

Para auditar sem risco de alterar nada, use o agent `read-only-auditor`: ele tem
hooks que bloqueiam Write, Edit e Bash por construção.

---

## Proteções automáticas já ativas

`.claude/settings.json` instala 8 hooks que rodam sozinhos, sem depender de você
lembrar. **Se um comando seu for bloqueado, é isso — não é bug:**

| Hook | Quando dispara |
|---|---|
| `dangerous-command-blocker` | Bash — bloqueia `rm -rf /`, `dd`, `mkfs`, e protege `.git/`, `.claude/` |
| `shell-wrapper-guard` | Bash — pega destrutivo escondido em `sh -c`, `python3 -c`, `node -e` |
| `secret-scanner` | Bash — bloqueia commit com chave hardcoded (30+ provedores) |
| `force-push-blocker` | Bash — bloqueia `git push --force` e `-f` |
| `file-protection` | Edit/Write — bloqueia `/etc/*`, `*.production.*`, `*prod*config*`, `node_modules/` |
| `env-file-protection` | Write — bloqueia qualquer escrita em `.env*` |
| `security-scanner` | Após Edit/Write — roda semgrep, bandit, gitleaks se instalados |
| `dependency-checker` | Ao editar `package.json`, `requirements.txt`, `Cargo.toml` — roda audit |

Se um bloqueio atrapalhar legitimamente, **avise o usuário e explique qual hook
bloqueou** em vez de tentar contornar. Editar `.claude/settings.json` para desligar
uma proteção só com pedido explícito do usuário.

---

## Roteamento — qual usar para quê

### Construir seguro (durante o desenvolvimento)
| Assunto da tarefa | Use |
|---|---|
| Base ampla de application security e arquitetura segura | skill `senior-security` |
| Design de API: authn, authz, validação de input, rate limiting | skill `api-security-best-practices` |
| Login, sessão, senha, credential stuffing, fixação de sessão | skill `broken-authentication` |
| Implementar sistema de login do zero | command `/add-authentication-system` |
| Supabase Auth + Next.js App Router | skill `nextjs-supabase-auth` |
| Rate limiting em API | command `/setup-rate-limiting` |
| Upload de arquivo: S3, R2, presigned URLs, multipart | skill `file-uploads` |
| Servir arquivo — risco de path traversal / LFI | skill `file-path-traversal` |
| Segredos: Vault, AWS Secrets Manager, CI/CD | skill `secrets-management` |
| Modelagem de ameaça no repositório: trust boundaries, ativos, abuso | skill `security-threat-model` |
| STRIDE, PASTA, attack trees | skill `threat-modeling-expert` |
| Arquitetura de segurança e controles no CI/CD | agent `security-engineer` |
| SecOps e gestão de vulnerabilidade | skill `senior-secops` |
| CI/CD seguro: action pinning, OIDC, least privilege | agent `github-actions-expert` |
| Servidor MCP: OAuth, RBAC, compliance | agent `mcp-security-auditor` |

### Auditar e testar
| Assunto da tarefa | Use |
|---|---|
| Auditoria geral de segurança, compliance e risco | agent `security-auditor` |
| Auditoria de API REST | agent `api-security-audit` |
| Auditoria **sem alterar nada** (produção) | agent `read-only-auditor` |
| Review de código focado em falha de segurança | agent `wg-code-sentinel`, agent `se-security-reviewer` |
| OWASP 2025, superfície de ataque, priorização de risco | skill `vulnerability-scanner` |
| Categorias de falha web | skill `top-web-vulnerabilities` |
| Boas práticas por linguagem/framework | skill `security-best-practices` |
| Workflow OWASP Top 10 | skill `web-security-testing` |
| Testar REST/GraphQL: authn, authz, rate limit | skill `api-security-testing` |
| SQL injection | skill `sql-injection-testing` |
| XSS e HTML injection | skill `xss-html-injection` |
| IDOR / broken access control — falha nº 1 em CRM | skill `idor-testing` |
| Fuzzing de API | skill `api-fuzzing-bug-bounty` |
| Testar app local com Playwright, screenshot | skill `webapp-testing` |
| Planejar escopo de um teste | skill `pentest-checklist` |
| Executar pentest autorizado | agent `penetration-tester` |
| Auditoria completa / hardening / varredura de segredo | commands `/security-audit`, `/security-hardening`, `/secrets-scanner`, `/penetration-test` |
| RLS e vulnerabilidade no Supabase | command `/supabase-security-audit` |
| Configurar SAST multi-linguagem | skill `sast-configuration` |
| Quem é dono do código sensível, bus factor | skill `security-ownership-map` |

### Dependências e cadeia de suprimentos
| Assunto da tarefa | Use |
|---|---|
| Analisar dependências e vulnerabilidades | agent `dependency-manager`, command `/dependency-audit` |
| Pacote comprometido em npm, PyPI, crates.io, GitHub Actions | skill `supply-chain-guard`, agent `supply-chain-security` |
| Auditoria da cadeia de suprimentos | command `/supply-chain-audit` |

### Compliance, privacidade e jurídico
| Assunto da tarefa | Use |
|---|---|
| Política de privacidade, termos de uso, aviso legal | agent `legal-advisor` |
| Avaliação de compliance e preparação de auditoria | agent `compliance-specialist` |
| GDPR, HIPAA, PCI DSS, SOC 2, ISO | agent `compliance-auditor` |
| Defesa em profundidade + compliance | skill `security-compliance` |
| ISO 27001 / 27002 | skill `information-security-manager-iso27001` |
| GDPR, CCPA, HIPAA, leis de proteção de dados | skill `data-privacy-compliance` |
| GDPR/DSGVO na visão de auditor | skill `gdpr-dsgvo-expert` |

### Incidente
| Assunto da tarefa | Use |
|---|---|
| Incidente em produção: debug, correção, post-mortem | agent `incident-responder` |

---

## Lacunas conhecidas — não invente que existe

- **Não há skill de LGPD.** Só GDPR. As skills de GDPR cobrem os princípios gerais
  (a LGPD foi modelada sobre ele), mas **não** cobrem o que é próprio do Brasil:
  papel da ANPD, bases legais do art. 7º, prazos de notificação. Ao tratar de LGPD,
  diga isso e recomende validação com jurídico brasileiro.
- **Não há MCP de scanner de segurança** — sem Semgrep, Snyk, Trivy ou SonarQube.
  A skill `sast-configuration` ensina a configurar; a ferramenta roda por fora.
  O hook `security-scanner` usa semgrep/bandit/gitleaks **se já estiverem
  instalados** na máquina — se não estiverem, ele passa em silêncio.
- **Não há pentest de infraestrutura** neste kit (Active Directory, Metasploit,
  Shodan, privesc Windows/Linux). Existe no catálogo — ver seção 9 de
  `KIT-SECURITY-SISTEM-AITMPL.md`.

## Convenções

- Declare qual skill/agent está usando antes de aplicar a recomendação.
- Achado de segurança precisa de **evidência**: arquivo, linha e como reproduzir.
  Não reporte suspeita como se fosse confirmada — diga o nível de confiança.
- Priorize por risco real (impacto × explorabilidade), não por quantidade de itens.
- Skill de segurança não substitui pentest profissional nem auditoria formal. Em
  sistema que trata dado sensível ou dinheiro, diga isso ao usuário.
- Não instale novos componentes do aitmpl.com sem o usuário pedir.
