# Kit Dados e IA — pipeline, análise, ML

**4 skills, 9 agents, 2 commands e 2 MCPs** para engenharia de dados, análise e
machine learning.

Origem: [aitmpl.com](https://aitmpl.com/) · **15 componentes, 8.514 downloads somados.**

---

## Como usar

```bash
claude          # dentro desta pasta
```
Rode `/kit-dados`. Ou instale num projeto: `./install.sh /caminho` · `./check.sh`.

## Instalar em outro projeto

### Windows (PowerShell)

```powershell
.\install.ps1 C:\caminho\do\seu\projeto
```

Se o Windows bloquear a execução do script:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

Isso libera só a sessão atual — não altera a política da máquina.

### macOS e Linux

```bash
chmod +x install.sh check.sh    # só na primeira vez
./install.sh /caminho/do/seu/projeto
./check.sh
```

O `install.ps1` também roda no macOS e no Linux, se você tiver PowerShell 7+.

## Comandos

| Comando | O que faz |
|---|---|
| `/kit-dados [assunto]` | Mostra o que tem; pergunta a **pergunta de negócio**, não a técnica |
| `/analisar-dados [dado ou pergunta]` | Inspeciona o dataset antes de concluir, declara incerteza |

O `/analisar-dados` separa desde o início **correlação de efeito** — "quem usa X
compra mais" versus "se eu aumentar X, vendo mais". Exigem desenhos diferentes, e
confundir os dois é o erro mais caro em análise de negócio.

---

## O que está instalado

**Agents** — `ai-engineer` (2.154), `data-scientist` (907), `data-engineer` (859),
`ml-engineer` (556), `computer-vision-engineer` (303), `mlops-engineer` (291),
`nlp-engineer` (252), `data-analyst` (198), `postgresql-dba` (115).

**Skills** — `senior-data-engineer` (629), `senior-data-scientist` (540),
`senior-ml-engineer` (201), `senior-computer-vision` (131).

`senior-data-scientist` cobre **inferência causal** — o que separa análise que
sustenta decisão de análise que engana.

Detalhe: [KIT-DADOS-IA.md](KIT-DADOS-IA.md).

---

## MCPs

`.mcp.json` está **vazio** — os dois MCPs deste kit precisam de credencial e ficam
em `.mcp.optional.json`: `postgresql` (1.299, connection string) e
`elasticsearch` (79).

> Em produção, use usuário **read-only** na connection string. E não versione o
> `.mcp.json` preenchido.

---

## Limitações

1. **A categoria `data-ai` é dominada por nicho Microsoft.** Dos 40 agents, ~15 são
   Power BI, Azure, .NET, MS SQL. Instalei os 9 que servem para qualquer stack. Se
   você usa esse ecossistema, `power-bi-dax-expert` e `ms-sql-dba` valem a instalação.

2. **Sobreposição skill/agent.** `data-scientist`, `data-engineer` e `ml-engineer`
   existem nas duas formas. Instalei ambas — skill para consulta, agent para tarefa
   longa.

3. **Nenhum componente trata LGPD.** Pipeline com dado de cliente precisa de base
   legal, minimização e retenção. Está no `KIT-SECURITY-SISTEM-AITMPL`.

4. **Skill de ML não conserta dado ruim.** Dataset pequeno, enviesado ou mal
   rotulado é onde a maioria dos projetos morre — e nenhuma skill resolve isso.

---

## Arquivos

```
KIT-DADOS-IA/
├── CLAUDE.md · README.md · KIT-DADOS-IA.md
├── install.sh · check.sh
├── .mcp.json · .mcp.optional.json
└── .claude/  skills/ 4 · agents/ 9 · commands/ 2
```
